﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.IO;
using AHP;
using Document;

namespace AHPManager
{
    public partial class CompareForm : Form
    {
        private Label[] lbAlternativeNames = null;      // массив надписей для панели количественных оценок
        private TextBox[] tbAlternativeWeights = null;  // массив полей ввода для панели количественных оценок

        /* Массив строк - описаний оценок. Строка, соответствующая отсутствию оценки, стоит
         * на последнем месте. */
        private string[] appraisalDescriptions = 
        { 
            "эквивалентны",
            "слабое превосходство",
            "сильное превосходство",
            "очевидное превосходство",
            "абсолютное превосходство",
            "оценка не выставлена"
        };

        private Hierarchy hierarchy;
        private Element elem;

        LocalPrioritiesForm lpForm;                 // окно локальных приоритетов
        TransitivityForm trForm;                    // окно исследования транзитивности
        private bool localPrioritiesShown = false;  // показано ли окно локальных приоритетов
        private bool transitivityShown = false;     // показано ли окно исследования транзитивности
        private PreferenceGraphControl prGraph;     // элемент, представляющий граф предпочтений

        // строки для значений в статусной строке
        private string totalComparisons = "Сравнений: ";
        private string completeComparisons = "Выполнено сравнений: ";
        private string equivalentComparisons = "Эквивалентностей: ";

        ArrayList comboBoxText = new ArrayList();

        /* Ставит в соответствие вызываемому окну иерархическую структуру hierarchy и элемент elem,
         * относительно которого производятся попарные сравнения элементов нижнего уровня. */
        public void SetParams(Hierarchy hierarchy, Element elem) 
        {
            this.hierarchy = hierarchy;
            this.elem = elem;
        }

        public CompareForm(Hierarchy compareHierarchy, Element compareElement)
        {
            hierarchy = compareHierarchy;
            elem = compareElement;

            InitializeComponent();
        }

        /* Формируем элементы формы сравнения элементов до ее первоначального отображения. */
        private void Compare_Load(object sender, EventArgs e)
        {
            Text = "Критерий \"" + elem.Name + "\"";
            Level alternativesLevel = elem.Lv.LowerLevel;   // ссылка на уровень альтернатив

            // устанавливаем значения в groupbox'ах справа и настраиваем статусную строку
            if (elem.CriterionType == Criterions.comparative)
            {
                comparativeRadioButton.Checked = true;
                comparativeCriterionPanel.Visible = true;
                quantitativeCriterionPanel.Visible = false;

                switch (elem.ScaleType)
                {
                    case Scales.Bruck:
                        bruckRadioButton.Checked = true;
                        break;
                    case Scales.Saaty:
                        saatyRadioButton.Checked = true;
                        break;
                    case Scales.logistic:
                        logisticRadioButton.Checked = true;
                        break;
                }

                btn_Cycle.Enabled = true;

                // устанавливаем значения в статусной строке
                tsslComparisonsComplete.Visible = tsslComparisonsEquivalent.Visible =
                    tsslComparisonsNumber.Visible = true;
                tsslComparisonsNumber.Text =
                    totalComparisons + " " + elem.PairComparisons.Size * (elem.PairComparisons.Size - 1) / 2;
                tsslComparisonsComplete.Text = 
                    completeComparisons + " " + AuxiliaryClass.GetCompleteComparionsNumber(elem);
                tsslComparisonsEquivalent.Text = 
                    equivalentComparisons + " " + AuxiliaryClass.GetEquivalentComparisonsNumber(elem);
            }
            else
            {
                quantitativeRadioButton.Checked = true;

                comparativeCriterionPanel.Visible = false;
                quantitativeCriterionPanel.Visible = true;

                switch (elem.QuantCriterionType)
                {
                    case QuantCriterions.ascending:
                        ascendingRadioButton.Checked = true;
                        break;
                    case QuantCriterions.descending:
                        descendingRadioButton.Checked = true;
                        break;
                }

                btn_Cycle.Enabled = false;

                tsslComparisonsComplete.Visible =
                    tsslComparisonsEquivalent.Visible =
                    tsslComparisonsNumber.Visible = false;
            }

            /* Формируем две панели слева: для выставления попарных оценок и для
             * ввода численных значений альтернатив. */

            /* Формируем надпись, представляющую заголовок. */
            lbComparativeHeader.Text = "Сравнения по критерию \"" + elem.Name + "\"";
            Size headerSize = TextRenderer.MeasureText(lbComparativeHeader.Text, SystemFonts.DefaultFont);
            // создаем такой же заголовок для панели количественного критерия
            Label lbQuantitativeHeader = new Label();
            lbQuantitativeHeader.AutoSize = true;
            lbQuantitativeHeader.TextAlign = ContentAlignment.MiddleCenter;
            lbQuantitativeHeader.Anchor = (AnchorStyles)(((AnchorStyles.Left | AnchorStyles.Right)
                | AnchorStyles.Bottom)
                | AnchorStyles.Top);
            lbQuantitativeHeader.Text = "Сравнения по критерию \"" + elem.Name + "\"";

            /* Панель для сравнительного критерия. */
            /* Заголовок должен отделяться от тела таблицы, поэтому удвоим высоту первой
             * строки. */
            tlpComparative.RowStyles[0] = new RowStyle(SizeType.Absolute, headerSize.Height * 2);
            tlpComparative.RowStyles[2] = new RowStyle(SizeType.Absolute, headerSize.Height * 2);
            tlpComparative.RowStyles[4] = new RowStyle(SizeType.Absolute, (int)(headerSize.Height * 1.5));
            trComparativeAppraisal.Scroll += new EventHandler(comparativeAppraisal_Scroll);
            cbComparisonsList.SelectedIndexChanged += new EventHandler(comparisonsList_SelectedIndexChanged);
            // Формируем список всевозможных пар сравниваемых элементов.
            for (int i = 0; i < elem.LowerLevelCount(); i++)
                for (int j = i + 1; j < elem.LowerLevelCount(); j++)
                    cbComparisonsList.Items.Add(alternativesLevel.Elements[i].Name + " - "
                        + alternativesLevel.Elements[j].Name);
            // Создаем и выводим граф предпочтений.
            prGraph = new PreferenceGraphControl(elem);
            tlpComparative.Controls.Add(prGraph, 0, 1);
            tlpComparative.SetColumnSpan(prGraph, 3);
            prGraph.Dock = DockStyle.Fill;
            prGraph.BorderStyle = BorderStyle.Fixed3D;
            prGraph.InitializeVertices();
            prGraph.ComparisonSelected += new ComparisonSelectedDelegate(prGraph_ComparisonSelected);
            // Сделаем так, чтобы пары элементов, которые уже сравнили, выделались бы синим цветом.
            cbComparisonsList.SelectedIndex = 0;
            cbComparisonsList.DrawMode = DrawMode.OwnerDrawFixed;
            cbComparisonsList.DrawItem += new DrawItemEventHandler(comparisonsList_DrawItem);
            
            /* Панель для количественного критерия. */

            /* Формируем компонент TableLayoutLabel, который будет содержать элементы
             * управления панели. */
            TableLayoutPanel tlpQuantitative = new TableLayoutPanel();
            tlpQuantitative.CellBorderStyle = TableLayoutPanelCellBorderStyle.None;
            tlpQuantitative.Parent = quantitativeCriterionPanel;
            tlpQuantitative.SuspendLayout();
            tlpQuantitative.ColumnCount = 2;
            tlpQuantitative.Dock = System.Windows.Forms.DockStyle.Fill;
            tlpQuantitative.Location = new System.Drawing.Point(3, 18);
            tlpQuantitative.RowCount = elem.LowerLevelCount() + 2;

            /* Заголовок должен отделяться от тела таблицы, поэтому удвоим высоту первой
             * строки. */
            tlpQuantitative.RowStyles.Add(new RowStyle(SizeType.Absolute, headerSize.Height*2));
            tlpQuantitative.Controls.Add(lbQuantitativeHeader, 0, 0);
            tlpQuantitative.SetColumnSpan(lbQuantitativeHeader, 2);
            // задаем размеры стоблцов
            tlpQuantitative.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 80));
            tlpQuantitative.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));

            // Формируем пары "надпись - поле ввода" для альтернатив
            lbAlternativeNames = new Label[elem.LowerLevelCount() + 1];
            tbAlternativeWeights = new TextBox[elem.LowerLevelCount() + 1];
            for (int i = 0; i < elem.LowerLevelCount(); i++)
            {
                // задаем стиль для строки tlpQuantitative
                tlpQuantitative.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                // формируем надпись, представляющую название альтернативы
                lbAlternativeNames[i] = new Label();
                lbAlternativeNames[i].AutoSize = true;
                lbAlternativeNames[i].TextAlign = ContentAlignment.MiddleLeft;
                lbAlternativeNames[i].Anchor = (AnchorStyles)(((AnchorStyles.Left | AnchorStyles.Right)
                    | AnchorStyles.Bottom)
                    | AnchorStyles.Top);
                lbAlternativeNames[i].Text = elem.Lv.LowerLevel.Elements[i].Name;
                // формируем поле ввода
                tbAlternativeWeights[i] = new TextBox();
                tbAlternativeWeights[i].Anchor = (AnchorStyles)(((AnchorStyles.Left | AnchorStyles.Right)
                    | AnchorStyles.Bottom)
                    | AnchorStyles.Top);
                // если имеется оценка, то ставим ее в поле ввода, иначе оставляем его пустым
                tbAlternativeWeights[i].Text = (elem.IsDefined[i]) ? elem.ElementValues[i].ToString() : "";
                // добавляем обработчик события ввода текста в поле ввода
                tbAlternativeWeights[i].TextChanged += new EventHandler(tbAlternativeWeight_TextChanged);
                // добавляем надпись и поле ввода на форму
                tlpQuantitative.Controls.Add(lbAlternativeNames[i], 0, i + 1);
                tlpQuantitative.Controls.Add(tbAlternativeWeights[i], 1, i + 1);
            }
            // добавляем еще одну, невидимую, строку в tlbQuantitative, чтобы последний пункт "не висел"
            tlpQuantitative.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            Label lbPseudo = new Label();
            lbPseudo.AutoSize = true;
            lbPseudo.Anchor = (AnchorStyles)(((AnchorStyles.Left | AnchorStyles.Right)
                | AnchorStyles.Bottom)
                | AnchorStyles.Top);
            lbPseudo.Text = "Пустая строка";
            lbPseudo.Visible = false;
            tlpQuantitative.Controls.Add(lbPseudo, 0, elem.LowerLevelCount() + 2);

            /* Восстанавливаем обычную логику макетов tlbQuantitative, quantitativeCriterionPanel
             * и формы. */
            tlpQuantitative.ResumeLayout();
            quantitativeCriterionPanel.ResumeLayout();
            this.ResumeLayout();

            /* Добавляем обработчики событий переключения шкалы. */
            this.logisticRadioButton.CheckedChanged += new System.EventHandler(this.logisticRadioButton_CheckedChanged);
            this.saatyRadioButton.CheckedChanged += new System.EventHandler(this.saatyRadioButton_CheckedChanged);
            this.bruckRadioButton.CheckedChanged += new System.EventHandler(this.bruckRadioButton_CheckedChanged);
        }

        /// <summary>
        /// Обработчик события выбора пары вершин на графе предпочтений.
        /// </summary>
        void prGraph_ComparisonSelected(object sender, ComparisonSelectedEventArgs e)
        {
            // вычисляем номер пары по индексам альтернатив (см. соответствующее пояснение)
            int i = e.AlternativeIndices.Min() + 1;
            int j = e.AlternativeIndices.Max() + 1;
            int n = elem.LowerLevelCount();

            cbComparisonsList.SelectedIndex = n * (i - 1) - i * (i + 1) / 2 + j - 1;
        }

        /* Обработчик события ввода текста в одно из полей ввода tbAlternativeWeight. */
        void tbAlternativeWeight_TextChanged(object sender, EventArgs e)
        {
            TextBox tbox = sender as TextBox;
            double value = 0;
            
            /* Проверяем, было ли введено корректное числовое значение. Если нет,
             * то убираем последний введенный символ и выдаем звуковой сигнал. */
            if (!Double.TryParse(tbox.Text, out value) && (tbox.Text != "") && (tbox.Text != "-"))
            {
                tbox.Text = tbox.Text.Substring(0, tbox.Text.Length - 1);
                tbox.SelectionStart = tbox.Text.Length;
                System.Media.SystemSounds.Beep.Play();
            }

            double[] newLocalPriorities = new double[elem.LowerLevelCount()];
            WeightsTransformationMethod elementWTM = null;
            // выбираем способ получения локальных приоритетов из весов
            switch (elem.QuantCriterionType)
            {
                case QuantCriterions.ascending:
                    elementWTM = new AscendingWeightsMethod();
                    break;
                case QuantCriterions.descending:
                    elementWTM = new DescendingWeightsMethod();
                    break;
            }

            /* Если все веса корректно указаны и открыто окно локальных приоритетов,
             * то обновляем его. */
            if (localPrioritiesShown &&
                GetLocalPrioritiesFromWeights(out newLocalPriorities, elementWTM))
                lpForm.UpdateData(newLocalPriorities);
        }

        /* Обработчик события выбора строки в comboBox comparisonsList, содержащем
         * список всевозможных пар сравниваемых альтернатив. */
        void comparisonsList_SelectedIndexChanged(object sender, EventArgs e)
        {
            int leftElementIndex, rightElementIndex;    // индексы левого и правого сравниваемых элементов

            GetElementIndeces(elem.LowerLevelCount(),
                cbComparisonsList.SelectedIndex, 
                out leftElementIndex, 
                out rightElementIndex);
            
            /* Смотрим, не была ли выставлена оценка ранее. Если да, то ставим ползунок
             * tracker'а comparativeAppraisal в соответствующее положение, если нет, то
             * ставим его в нулевое положение. */
            trComparativeAppraisal.Value =
                (elem.PairComparisons[leftElementIndex, rightElementIndex] == Appraisals.undefined) ?
                0 :
                -elem.PairComparisons[leftElementIndex, rightElementIndex];
            /* Примечание: перед оценкой стоит "-", так как у ползунка слева находятся 
             * отрицательные значения, а справа - положительные. */
            // Выводим названия сравниваемых элементов.
            lbLeftAlternative.Text = elem.Lv.LowerLevel.Elements[leftElementIndex].Name;
            lbRightAlternative.Text = elem.Lv.LowerLevel.Elements[rightElementIndex].Name;
            // Выводим комментарий к оценке.
            if (elem.PairComparisons[leftElementIndex, rightElementIndex] == Appraisals.undefined)
                lbAppraisalDescription.Text = appraisalDescriptions[appraisalDescriptions.Length - 1];
            else
                lbAppraisalDescription.Text = appraisalDescriptions[Math.Abs(trComparativeAppraisal.Value)];
            // Выделяем выбранную пару элементов на графе предпочтений.
            prGraph.HighlightComparison(leftElementIndex, rightElementIndex);
        }

        /* Обработчик события изменения положения ползунка comparativeAppraisal,
         * отображающего оценку пары альтернатив в сравнении друг с другом. */
        void comparativeAppraisal_Scroll(object sender, EventArgs e)
        {
            int leftElementIndex, rightElementIndex;    // индексы левого и правого сравниваемых элементов

            GetElementIndeces(elem.LowerLevelCount(), cbComparisonsList.SelectedIndex,
                out leftElementIndex,
                out rightElementIndex);
            // Выделяем на графе предпочтений пару элементов, для которых редактируется суждение.
            prGraph.HighlightComparison(leftElementIndex, rightElementIndex);
            // слева значения со знаком "-", справа - значения со знаком "+" 
            elem.PairComparisons[leftElementIndex, rightElementIndex] = -trComparativeAppraisal.Value;
            elem.PairComparisons[rightElementIndex, leftElementIndex] = trComparativeAppraisal.Value;
            // Выводим комментарий к оценке.
            if (trComparativeAppraisal.Value == Appraisals.undefined)
                lbAppraisalDescription.Text = appraisalDescriptions[appraisalDescriptions.Length - 1];
            else
                lbAppraisalDescription.Text = appraisalDescriptions[Math.Abs(trComparativeAppraisal.Value)];
            /* Вызываем перерисовку списка альтернатив cbComparisonsList, чтобы только что
             * оцененная пара подсветилась синим цветом. */
            cbComparisonsList.Refresh();
            // если открыто окно попарных сравнений, то обновляем его
            if (localPrioritiesShown)
            {
                Scale elementScale = AuxiliaryClass.CreateScale(elem, hierarchy);
                WeightsDerivingMethod elementWDM = new EigenvectorMethod();

                lpForm.UpdateData(
                    GetLocalPrioritiesFromCM(
                    elementScale, elementWDM, elem.PairComparisons));
            }

            // если открыто окно исследования транзитивности, то обновляем его
            if (transitivityShown)
            {
                Scale elementScale = AuxiliaryClass.CreateScale(elem, hierarchy);

                trForm.UpdateData(elem);
            }

            // перерисовываем граф предпочтений
            prGraph.Refresh();

            // обновляем информацию в статусной строке
            tsslComparisonsComplete.Text =
                completeComparisons + " " + AuxiliaryClass.GetCompleteComparionsNumber(elem);
            tsslComparisonsEquivalent.Text =
                equivalentComparisons + " " + AuxiliaryClass.GetEquivalentComparisonsNumber(elem);
        }

        /* Обработчик события отрисовки строк строки в comboBox comparisonsList, содержащем
         * список всевозможных пар сравниваемых альтернатив. */ 
        private void comparisonsList_DrawItem(object sender, DrawItemEventArgs e)
        {
            /* Если паре элементов была поставлена в соответствие некотороая оценка,
             * то соответствующий пункт comparisonsList отображается синим цветом,
             * иначе - черным. */
            e.DrawBackground();     // рисуем фон

            int leftElementIndex, rightElementIndex;    // индексы левого и правого сравниваемых элементов
            Brush elementBrush;                         // кисть, определяющая цвет надписи

            GetElementIndeces(elem.LowerLevelCount(), e.Index, out leftElementIndex, out rightElementIndex);
 
            elementBrush = (elem.PairComparisons[leftElementIndex, rightElementIndex] == Appraisals.undefined) ?
                SystemBrushes.ControlText :
                Brushes.Blue;

            // выводим надпись
            e.Graphics.DrawString(
                cbComparisonsList.Items[e.Index].ToString(), 
                e.Font, 
                elementBrush, 
                e.Bounds, 
                StringFormat.GenericDefault);
            e.DrawFocusRectangle();
        }

        /// <summary>
        /// Выдает индексы пары элементов, попарная оценка сравнения которых 
        /// соответствует i-ой строке в списке comparisonsList.
        /// </summary>
        /// <param name="n">Общее число сравниваемых между собой альтернатив.</param>
        /// <param name="i">Номер строки в списке comparisonList.</param>
        /// <param name="leftElementIndex">Индекс первой (левой) альтернативы.</param>
        /// <param name="rightElementIndex">Индекс второй (правой) альтернативы.</param>
        private void GetElementIndeces(int n, int i, out int leftElementIndex, out int rightElementIndex)
        {
            leftElementIndex = -1;  // если что-то пойдет не так, то индексам присваиваются отрицательные значения
            rightElementIndex = -1;
            i += 1;

            for (int k = 0; k < n; k++)
                for (int m = k + 1; m <= n; m++)
                    if (2*n*(k-1) - k*(k+1) + 2*m == 2*i)
                    {                    
                        leftElementIndex = k - 1;
                        rightElementIndex = m - 1;
                        return;
                    }
            /* Примечание: поправки i, leftElementIndex и rightElementIndex на единицу
             * вызваны тем, что формула в условном операторе рассчитывалась для случая,
             * когда нумерация начинается с 1. */
        }

        private void btn_Calc_Click(object sender, EventArgs e)
        {
            /* Показываем окно локальных приоритетов, если оно еще не показано.
             * Переменная localPrioritiesShown равна true, если окно показано,
             * false - в противном случае. */
            if (!localPrioritiesShown)
            {
                lpForm = new LocalPrioritiesForm();
                lpForm.Owner = this;                // привязываем к окну попарных сравнений

                // формируем массивы подписей и значений столбцов диаграммы
                string[] altNames = new string[elem.LowerLevelCount()];
                double[] altRates = new double[elem.LowerLevelCount()];

                if (elem.CriterionType == Criterions.quantitative)
                {
                    WeightsTransformationMethod wtm = null;
                    // вычисляем локальные приоритеты для количественного критерия
                    switch (elem.QuantCriterionType)
                    {
                        case QuantCriterions.descending:
                            wtm = new DescendingWeightsMethod();
                            break;
                        case QuantCriterions.ascending:
                            wtm = new AscendingWeightsMethod();
                            break;
                    }
                    if (!GetLocalPrioritiesFromWeights(out altRates, wtm))
                    {
                        MessageBox.Show("Некоторые веса не указаны или некорректны.");
                        return;
                    }
                }
                else
                {
                    if (!elem.ComparisonsComplete &&
                        (MessageBox.Show("Попарные сравнения проведены не полностью. Вывести локальные приоритеты?",
                        "",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question) == DialogResult.No))
                        return;

                    AHP.Scale elementScale = AuxiliaryClass.CreateScale(elem, hierarchy);   // ссылка на используемую шкалу
                    WeightsDerivingMethod elementWDM;                                       // ссылка на используемый метод получения локальных приоритетов
        
                    // пока что у нас только один метод получения локальных приоритетов - метод собственного вектора
                    elementWDM = new EigenvectorMethod();

                    altRates = GetLocalPrioritiesFromCM(elementScale, elementWDM, elem.PairComparisons);
                }
                // формируем массив названий альтернатив
                altNames = elem.Lv.LowerLevel.Elements.Select(element => element.Name).ToArray();

                // формируем диаграмму и выводим ее на диалоговое окно
                lpForm.AcceptData(elem.Name, altNames, altRates);
                lpForm.Show();
                localPrioritiesShown = true;
            }
        }

        // Вспомогательный метод для вызова из класса LocalPrioritiesForm.
        public void LocalPrioritiesWindow_Closed()
        {
            localPrioritiesShown = false;
        }

        // вспомогательный метод для вызова из класса TransitivityForm.
        public void TransitivityWindow_Closed()
        {
            transitivityShown = false;
        }

        private void btn_Cycle_Click(object sender, EventArgs e)
        {
            /* Показываем окно исследования транзитивности, если оно еще не показано.
             * Переменная transitivityShown равна true, если окно показано, false - 
             * в противном случае. */
            if (!transitivityShown)
            {
                if (!elem.ComparisonsComplete &&
                        (MessageBox.Show("Попарные сравнения проведены не полностью. Вывести информацию о согласованности?",
                        "",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question) == DialogResult.No))
                    return;

                // создаем форму
                trForm = new TransitivityForm(elem, prGraph);
                trForm.Owner = this;

                trForm.Show();
                transitivityShown = true;
            }
        }
       

        private void btn_CompareCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void comparativeRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (comparativeRadioButton.Checked)
            {
                elem.CriterionType = Criterions.comparative;

                // Приводим форму в соответствующий вид.
                bool b_isSelectedCriterion = true;

                // убираем группу параметров количественного критерия и делаем видимой
                // группу параметров сравнительного критерия
                scaleGroupBox.Visible = b_isSelectedCriterion;
                quantCriterionTypeGroupBox.Visible = !b_isSelectedCriterion;

                // выставляем текущую шкалу в группе переключателей выбора шкалы
                switch (elem.ScaleType)
                {
                    case Scales.Bruck:
                        bruckRadioButton.Checked = true;
                        break;
                    case Scales.Saaty:
                        saatyRadioButton.Checked = true;
                        break;
                    case Scales.logistic:
                        logisticRadioButton.Checked = true;
                        break;
                }

                // делаем видимой панель с компонентами для выставления сравнительных оценок
                comparativeCriterionPanel.Visible = b_isSelectedCriterion;
                quantitativeCriterionPanel.Visible = !b_isSelectedCriterion;

                // делаем видимыми надписи на статусной строке
                tsslComparisonsComplete.Visible = tsslComparisonsEquivalent.Visible =
                    tsslComparisonsNumber.Visible = true;

                // активируем кнопку "Согласованность" и "Параметры шкалы"
                btn_Cycle.Enabled = true;
                btn_setScalesParams.Enabled = true;

                // если были открыты вспомогательные окна: локальных альтернатив и исследования
                // транзитивности, то закрываем их
                if (localPrioritiesShown)
                    lpForm.Close();
                if (transitivityShown)
                    trForm.Close();
            }
        }

        private void quantitativeRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (quantitativeRadioButton.Checked)
            {
                elem.CriterionType = Criterions.quantitative;

                // Приводим форму в соответствующий вид.

                // убираем группу параметров количественного критерия и делаем видимой
                // группу параметров сравнительного критерия
                scaleGroupBox.Visible = false;
                quantCriterionTypeGroupBox.Visible = true;

                // выставляем текущую шкалу в группе переключателей выбора шкалы
                switch (elem.QuantCriterionType)
                {
                    case QuantCriterions.ascending:
                        ascendingRadioButton.Checked = true;
                        break;
                    case QuantCriterions.descending:
                        descendingRadioButton.Checked = true;
                        break;
                }

                // делаем видимой панель с компонентами для выставления количественных оценок
                comparativeCriterionPanel.Visible = false;
                quantitativeCriterionPanel.Visible = true;

                // скрываем надписи на статусной строке
                tsslComparisonsComplete.Visible = tsslComparisonsEquivalent.Visible =
                    tsslComparisonsNumber.Visible = false;

                // блокируем кнопки "Согласованность" и "Параметры шкалы"
                btn_Cycle.Enabled = false;
                btn_setScalesParams.Enabled = false;

                // если было открыты вспомогательные окна: локальных альтернатив и исследования
                // транзитивности, то закрываем их.
                if (localPrioritiesShown)
                    lpForm.Close();
                if (transitivityShown)
                    trForm.Close();
            }
        }

        private void bruckRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            
            if (bruckRadioButton.Checked)
            {
                MessageBox.Show("В демоверсии доступна только шкала Саати.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                saatyRadioButton.Checked = true;
            }
        }

        private void setElementScale()
        {
            // если открыто окно локальных приоритетов, то обновляем его
            if (localPrioritiesShown)
            {
                Scale elementScale = AuxiliaryClass.CreateScale(elem, hierarchy);
                WeightsDerivingMethod elementWDM = new EigenvectorMethod();

                lpForm.UpdateData(
                    GetLocalPrioritiesFromCM(
                    elementScale, elementWDM, elem.PairComparisons));
            }

            //  если открыто окно исследования транзитивности, то обновляем его
            if (transitivityShown)
            {
                Scale elementScale = AuxiliaryClass.CreateScale(elem, hierarchy);

                trForm.UpdateData(elem);
            }
        }

        private void saatyRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (saatyRadioButton.Checked)
            {
            }
        }

        private void logisticRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (logisticRadioButton.Checked)
            {
                MessageBox.Show("В демоверсии доступна только шкала Саати.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                saatyRadioButton.Checked = true;
            }
        }

        private void ascendingRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (ascendingRadioButton.Checked)
            {
                elem.QuantCriterionType = QuantCriterions.ascending;

                // если открыто окно локальных приоритетов, то обновляем его
                if (localPrioritiesShown)
                {
                    WeightsTransformationMethod elementWTM = new AscendingWeightsMethod();
                    lpForm.UpdateData(elementWTM.GetWeights(elem.ElementValues));
                }
            }
        }

        private void descendingRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (descendingRadioButton.Checked)
            {
                elem.QuantCriterionType = QuantCriterions.descending;

                // если открыто окно локальных приоритетов, то обновляем его
                if (localPrioritiesShown)
                {
                    WeightsTransformationMethod elementWTM = new DescendingWeightsMethod();
                    lpForm.UpdateData(elementWTM.GetWeights(elem.ElementValues));
                }
            }
        }

        private void btn_ResetAppraisals_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Очистить оценки?", "", MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question) == DialogResult.Yes)
            {
                elem.ResetAppraisals();

                // если открыты вспомагательные окна: локальных приоритетов и исследования
                // транзитивности, то закрываем их
                if (localPrioritiesShown)
                    lpForm.Close();
                if (transitivityShown)
                    trForm.Close();

                // перерисовываем элементы управления в groupbox'ах слева
                if (elem.CriterionType == Criterions.quantitative)
                {
                    // очищаем поля ввода
                    for (int i = 0; i < elem.LowerLevelCount(); i++)
                        tbAlternativeWeights[i].Text = "";
                }
                else
                {
                    trComparativeAppraisal.Value = 0;       // ставим ползунок на 0
                    cbComparisonsList.SelectedIndex = 0;    // устанавливаем список сравнений на первый элемент
                    cbComparisonsList.Refresh();            // перерисовываем список сравнений, чтобы убрать выделенные синим цветом строки 
                    lbAppraisalDescription.Text
                        = appraisalDescriptions[appraisalDescriptions.Length - 1];  // устанавливаем описание оценки на "оценка отсутствует"
                    prGraph.Invalidate();                   // перерисовываем граф предпочтений
                }
            }
        }

        /// <summary>
        /// Вычисляем локальные приоритеты по матрице пользовательских оценок попарных сравнений
        /// с использованием заданной шкалы и метода получения локальных приоритетов.
        /// </summary>
        /// <param name="elementScale">Используемая шкала.</param>
        /// <param name="elementWDM">Используемый метод получения локальных приоритетов.</param>
        /// <param name="CM">Матрица пользовательских оценок попарных сравнений.</param>
        private double[] GetLocalPrioritiesFromCM(Scale elementScale, WeightsDerivingMethod elementWDM, ComparisonMatrix CM)
        {
            // преобразуем матрицу попарных сравнений в матрицу AHP.Matrix, применяя к ней выбранную шкалу
            AHP.Matrix scaledAppraisals = new Matrix(elem.LowerLevelCount());
            for (int i = 0; i < elem.LowerLevelCount(); i++)
                for (int j = 0; j < elem.LowerLevelCount(); j++)
                    // заменяем отсутствующие оценки оценками эквивалентности
                    scaledAppraisals[i, j] =
                        (elem.PairComparisons[i, j] != Appraisals.undefined) ?
                        elementScale.Convert(elem.PairComparisons[i, j]) :
                        elementScale.Convert(Appraisals.equivalent);

            // получаем локальные приоритеты выбранным методом
            return elementWDM.GetWeights(scaledAppraisals);
        }

        /// <summary>
        /// Вычисляет локальные приоритеты по весам, введенным в поля ввода на панели,
        /// соответствующей количественному критерию (массив tbAlternativeWeights). Если
        /// есть неуказанные или некорректные веса, то функция возвращает значение false, иначе
        /// возвращается значение true. При этом веса записываются в соответствующий им массив
        /// elem.ElementValues.
        /// </summary>
        /// <param name="localPriorities">Массив локальных приоритетов.</param>
        /// <param name="elementWTM">Метод получения локальных приоритетов из пользовательских весов.</param>
        private bool GetLocalPrioritiesFromWeights(out double[] localPriorities, WeightsTransformationMethod elementWTM)
        {
            bool flag = true;   // принимает значение false, если хотя бы одно из значений неверно
            localPriorities = null;
            for (int i = 0; i < elem.LowerLevelCount(); i++)
            {
                elem.IsDefined[i] = Double.TryParse(tbAlternativeWeights[i].Text, out elem.ElementValues[i]);
                flag = flag && elem.IsDefined[i];   // если вес указан некорректно, то он считается неуказанным
            }
            if (!flag)
                return false;
            localPriorities = elementWTM.GetWeights(elem.ElementValues);
            return true;
        }

        private void btn_setScalesParams_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Недоступно в демоверсии.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void CompareForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            /* Если выбран количественный тип критерия, то перед закрытием окна
             * нужно удостовериться, что в полях ввода указаны корректные числовые
             * значения, и если это так, то запомнить указанные веса. Если указано
             * некорректное значение, то нужно предложить пользователю вернуться
             * к редактированию или игнорировать предупреждение (в таком случае
             * оценка будет считаться невыставленной (undefined). */
            if (elem.CriterionType == Criterions.quantitative)
            {
                bool flag = true;   // принимает значение false, если хотя бы одно из значений неверно
                for (int i = 0; i < elem.LowerLevelCount(); i++)
                {
                    elem.IsDefined[i] = Double.TryParse(tbAlternativeWeights[i].Text, out elem.ElementValues[i]);
                    flag = flag && elem.IsDefined[i];
                }
                if (!flag)
                {
                    if (MessageBox.Show(
                        "Некоторые веса не указаны или некорректны. Выйти из режима оценивания?",
                        "",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question) == DialogResult.No)
                        e.Cancel = true;
                }
            }
            else
            {
                /* Если проведены не все попарные сравнения, то выводим предупреждение
                 * и предлагаем пользователю вернуться к проведению сравнений. */
                if (!elem.ComparisonsComplete)
                {
                    if (MessageBox.Show("Выставлены не все попарные оценки. Выйти из режима оценивания?",
                        "",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question) == DialogResult.No)
                        e.Cancel = true;
                }
            }
        }
    }
}
