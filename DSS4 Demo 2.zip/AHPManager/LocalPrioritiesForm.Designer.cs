﻿namespace AHPManager
{
    partial class LocalPrioritiesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.localPrioritiesChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            ((System.ComponentModel.ISupportInitialize)(this.localPrioritiesChart)).BeginInit();
            this.SuspendLayout();
            // 
            // localPrioritiesChart
            // 
            chartArea2.AxisY.LabelStyle.Enabled = false;
            chartArea2.AxisY.MajorGrid.Enabled = false;
            chartArea2.AxisY.MajorTickMark.Enabled = false;
            chartArea2.Name = "MainChartArea";
            this.localPrioritiesChart.ChartAreas.Add(chartArea2);
            this.localPrioritiesChart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.localPrioritiesChart.Location = new System.Drawing.Point(0, 0);
            this.localPrioritiesChart.Margin = new System.Windows.Forms.Padding(2);
            this.localPrioritiesChart.Name = "localPrioritiesChart";
            series2.ChartArea = "MainChartArea";
            series2.Name = "Alternatives";
            this.localPrioritiesChart.Series.Add(series2);
            this.localPrioritiesChart.Size = new System.Drawing.Size(224, 206);
            this.localPrioritiesChart.TabIndex = 0;
            this.localPrioritiesChart.Text = "chart1";
            // 
            // LocalPrioritiesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(224, 206);
            this.Controls.Add(this.localPrioritiesChart);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MinimumSize = new System.Drawing.Size(200, 200);
            this.Name = "LocalPrioritiesForm";
            this.ShowInTaskbar = false;
            this.Text = "Локальные приоритеты";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.LocalPrioritiesForm_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.localPrioritiesChart)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.DataVisualization.Charting.Chart localPrioritiesChart;
    }
}