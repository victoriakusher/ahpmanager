﻿namespace AHPManager
{
    partial class CreateProjectForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.lblComment = new System.Windows.Forms.Label();
            this.tboxComment = new System.Windows.Forms.TextBox();
            this.textboxesLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.lblName = new System.Windows.Forms.Label();
            this.lblLevelsNumber = new System.Windows.Forms.Label();
            this.lblElementsNumber = new System.Windows.Forms.Label();
            this.tboxName = new System.Windows.Forms.TextBox();
            this.tboxLevelsNumber = new System.Windows.Forms.TextBox();
            this.tboxElementsNumber = new System.Windows.Forms.TextBox();
            this.buttonsLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.mainLayoutPanel.SuspendLayout();
            this.textboxesLayoutPanel.SuspendLayout();
            this.buttonsLayoutPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // mainLayoutPanel
            // 
            this.mainLayoutPanel.ColumnCount = 1;
            this.mainLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.mainLayoutPanel.Controls.Add(this.lblComment, 0, 1);
            this.mainLayoutPanel.Controls.Add(this.tboxComment, 0, 2);
            this.mainLayoutPanel.Controls.Add(this.textboxesLayoutPanel, 0, 0);
            this.mainLayoutPanel.Controls.Add(this.buttonsLayoutPanel, 0, 3);
            this.mainLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainLayoutPanel.Location = new System.Drawing.Point(3, 3);
            this.mainLayoutPanel.Margin = new System.Windows.Forms.Padding(2);
            this.mainLayoutPanel.Name = "mainLayoutPanel";
            this.mainLayoutPanel.Padding = new System.Windows.Forms.Padding(3);
            this.mainLayoutPanel.RowCount = 4;
            this.mainLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.mainLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.mainLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.mainLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.mainLayoutPanel.Size = new System.Drawing.Size(437, 256);
            this.mainLayoutPanel.TabIndex = 0;
            // 
            // lblComment
            // 
            this.lblComment.AutoSize = true;
            this.lblComment.Location = new System.Drawing.Point(5, 79);
            this.lblComment.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblComment.Name = "lblComment";
            this.lblComment.Size = new System.Drawing.Size(80, 13);
            this.lblComment.TabIndex = 0;
            this.lblComment.Text = "Комментарий:";
            // 
            // tboxComment
            // 
            this.tboxComment.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tboxComment.Location = new System.Drawing.Point(5, 94);
            this.tboxComment.Margin = new System.Windows.Forms.Padding(2);
            this.tboxComment.Multiline = true;
            this.tboxComment.Name = "tboxComment";
            this.tboxComment.Size = new System.Drawing.Size(427, 126);
            this.tboxComment.TabIndex = 3;
            // 
            // textboxesLayoutPanel
            // 
            this.textboxesLayoutPanel.AutoSize = true;
            this.textboxesLayoutPanel.ColumnCount = 2;
            this.textboxesLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.textboxesLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.textboxesLayoutPanel.Controls.Add(this.lblName, 0, 0);
            this.textboxesLayoutPanel.Controls.Add(this.lblLevelsNumber, 0, 1);
            this.textboxesLayoutPanel.Controls.Add(this.lblElementsNumber, 0, 2);
            this.textboxesLayoutPanel.Controls.Add(this.tboxName, 1, 0);
            this.textboxesLayoutPanel.Controls.Add(this.tboxLevelsNumber, 1, 1);
            this.textboxesLayoutPanel.Controls.Add(this.tboxElementsNumber, 1, 2);
            this.textboxesLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textboxesLayoutPanel.Location = new System.Drawing.Point(5, 5);
            this.textboxesLayoutPanel.Margin = new System.Windows.Forms.Padding(2);
            this.textboxesLayoutPanel.Name = "textboxesLayoutPanel";
            this.textboxesLayoutPanel.RowCount = 3;
            this.textboxesLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.textboxesLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.textboxesLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.textboxesLayoutPanel.Size = new System.Drawing.Size(427, 72);
            this.textboxesLayoutPanel.TabIndex = 2;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(2, 0);
            this.lblName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(60, 13);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Название:";
            // 
            // lblLevelsNumber
            // 
            this.lblLevelsNumber.AutoSize = true;
            this.lblLevelsNumber.Location = new System.Drawing.Point(2, 24);
            this.lblLevelsNumber.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblLevelsNumber.Name = "lblLevelsNumber";
            this.lblLevelsNumber.Size = new System.Drawing.Size(113, 13);
            this.lblLevelsNumber.TabIndex = 1;
            this.lblLevelsNumber.Text = "Количество уровней:";
            // 
            // lblElementsNumber
            // 
            this.lblElementsNumber.AutoSize = true;
            this.lblElementsNumber.Location = new System.Drawing.Point(2, 48);
            this.lblElementsNumber.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblElementsNumber.Name = "lblElementsNumber";
            this.lblElementsNumber.Size = new System.Drawing.Size(127, 13);
            this.lblElementsNumber.TabIndex = 2;
            this.lblElementsNumber.Text = "Количество элементов:";
            // 
            // tboxName
            // 
            this.tboxName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tboxName.Location = new System.Drawing.Point(133, 2);
            this.tboxName.Margin = new System.Windows.Forms.Padding(2);
            this.tboxName.Name = "tboxName";
            this.tboxName.Size = new System.Drawing.Size(292, 20);
            this.tboxName.TabIndex = 0;
            // 
            // tboxLevelsNumber
            // 
            this.tboxLevelsNumber.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tboxLevelsNumber.Location = new System.Drawing.Point(133, 26);
            this.tboxLevelsNumber.Margin = new System.Windows.Forms.Padding(2);
            this.tboxLevelsNumber.Name = "tboxLevelsNumber";
            this.tboxLevelsNumber.Size = new System.Drawing.Size(292, 20);
            this.tboxLevelsNumber.TabIndex = 1;
            // 
            // tboxElementsNumber
            // 
            this.tboxElementsNumber.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tboxElementsNumber.Location = new System.Drawing.Point(133, 50);
            this.tboxElementsNumber.Margin = new System.Windows.Forms.Padding(2);
            this.tboxElementsNumber.Name = "tboxElementsNumber";
            this.tboxElementsNumber.Size = new System.Drawing.Size(292, 20);
            this.tboxElementsNumber.TabIndex = 2;
            // 
            // buttonsLayoutPanel
            // 
            this.buttonsLayoutPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonsLayoutPanel.AutoSize = true;
            this.buttonsLayoutPanel.ColumnCount = 2;
            this.buttonsLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.buttonsLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.buttonsLayoutPanel.Controls.Add(this.btnOK, 0, 0);
            this.buttonsLayoutPanel.Controls.Add(this.btnCancel, 1, 0);
            this.buttonsLayoutPanel.Location = new System.Drawing.Point(282, 224);
            this.buttonsLayoutPanel.Margin = new System.Windows.Forms.Padding(2);
            this.buttonsLayoutPanel.Name = "buttonsLayoutPanel";
            this.buttonsLayoutPanel.RowCount = 1;
            this.buttonsLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.buttonsLayoutPanel.Size = new System.Drawing.Size(150, 27);
            this.buttonsLayoutPanel.TabIndex = 3;
            // 
            // btnOK
            // 
            this.btnOK.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOK.AutoSize = true;
            this.btnOK.Location = new System.Drawing.Point(2, 2);
            this.btnOK.Margin = new System.Windows.Forms.Padding(2);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(71, 23);
            this.btnOK.TabIndex = 4;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.AutoSize = true;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(77, 2);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(2);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(71, 23);
            this.btnCancel.TabIndex = 5;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // CreateProjectForm
            // 
            this.AcceptButton = this.btnOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(443, 262);
            this.Controls.Add(this.mainLayoutPanel);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(244, 202);
            this.Name = "CreateProjectForm";
            this.Padding = new System.Windows.Forms.Padding(3);
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Создание нового проекта";
            this.mainLayoutPanel.ResumeLayout(false);
            this.mainLayoutPanel.PerformLayout();
            this.textboxesLayoutPanel.ResumeLayout(false);
            this.textboxesLayoutPanel.PerformLayout();
            this.buttonsLayoutPanel.ResumeLayout(false);
            this.buttonsLayoutPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel mainLayoutPanel;
        private System.Windows.Forms.Label lblComment;
        private System.Windows.Forms.TextBox tboxComment;
        private System.Windows.Forms.TableLayoutPanel textboxesLayoutPanel;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblLevelsNumber;
        private System.Windows.Forms.Label lblElementsNumber;
        private System.Windows.Forms.TextBox tboxName;
        private System.Windows.Forms.TextBox tboxLevelsNumber;
        private System.Windows.Forms.TextBox tboxElementsNumber;
        private System.Windows.Forms.TableLayoutPanel buttonsLayoutPanel;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;

    }
}