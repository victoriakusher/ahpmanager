﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace AHPManager
{
    /// <summary>
    /// Класс, представляющий кнопку-элемент иерархии.
    /// </summary>
    class ElementButton : Button
    {
        /// <summary>
        /// Таймер для отрисовки "затухания" кнопки.
        /// </summary>
        private Timer fadeInTimer = new Timer();
        /// <summary>
        /// Таймер для отрисовки "засвечивания" кнопки.
        /// </summary>
        private Timer fadeOutTimer = new Timer();
        /// <summary>
        /// "Засвеченность" кнопки.
        /// </summary>
        private int glowAlphaValue = 0;
        /// <summary>
        /// Цвет границы кнопки.
        /// </summary>
        private Color borderColor = Color.DarkBlue;
        /// <summary>
        /// Толщина границы кнопки.
        /// </summary>
        private int borderWidth = 2;
        /// <summary>
        /// Цвет основной части кнопки.
        /// </summary>
        private Color baseColor = Color.Green;
        /// <summary>
        /// Цвет верхней (как правило, осветленной) части кнопки.
        /// </summary>
        private Color highlightColor = Color.LightGreen;

        /// <summary>
        /// Величина, на которую изменяется степень "подсвечивания" кнопки
        /// </summary>
        private int glowAlphaValueSpeed = 30;
        private int maxGlowAlphaValue = 150;

        public ElementButton()
        {
            InitializeComponent();
  
            /* Настраиваем таймеры. */
            fadeInTimer.Interval = fadeOutTimer.Interval = 30;
        }

        /// <summary>
        /// Цвет границы кнопки.
        /// </summary>
        public Color BorderColor
        {
            get { return borderColor; }
            set
            {
                borderColor = value;
                Invalidate();
            }
        }

        /// <summary>
        /// Толщина границы вокруг кнопки.
        /// </summary>
        public int BorderWidth
        {
            get { return borderWidth; }
            set
            {
                borderWidth = value;
                Invalidate();
            }
        }

        /// <summary>
        /// Цвет основной части кнопки.
        /// </summary>
        public Color BaseColor
        {
            get { return baseColor; }
            set
            {
                baseColor = value;
                Invalidate();
            }
        }

        /// <summary>
        /// Цвет верхней части кнопки.
        /// </summary>
        public Color HighlightColor
        {
            get { return highlightColor; }
            set
            {
                highlightColor = value;
                Invalidate();
            }
        }

        private void InitializeComponent()
        {
            this.Size = new Size(144, 34);  // взято из проекта AHPManager
            
            /* Подключаем обработчики событий. */
            this.MouseEnter += new EventHandler(ElementButtonNew_MouseEnter);
            this.MouseLeave += new EventHandler(ElementButtonNew_MouseLeave);
            this.MouseUp += new MouseEventHandler(ElementButtonNew_MouseUp);
            this.MouseDown += new MouseEventHandler(ElementButtonNew_MouseDown);
            this.GotFocus += new EventHandler(ElementButtonNew_MouseEnter);
            this.LostFocus += new EventHandler(ElementButtonNew_MouseLeave);
            this.fadeInTimer.Tick += new EventHandler(fadeInTimer_Tick);
            this.fadeOutTimer.Tick += new EventHandler(fadeOutTimer_Tick);
        }

        private void fadeInTimer_Tick(object sender, EventArgs e)
        {
            if (glowAlphaValue + glowAlphaValueSpeed >= maxGlowAlphaValue)
            {
                glowAlphaValue = maxGlowAlphaValue;
                fadeInTimer.Stop();
            }
            else
                glowAlphaValue += glowAlphaValueSpeed;
            Invalidate();
        }

        private void fadeOutTimer_Tick(object sender, EventArgs e)
        {
            if (glowAlphaValue - glowAlphaValueSpeed <= 0)
            {
                glowAlphaValue = 0;
                fadeOutTimer.Stop();
            }
            else
                glowAlphaValue -= glowAlphaValueSpeed;
            Invalidate();
        }

        void ElementButtonNew_MouseEnter(object sender, EventArgs e)
        {
            // проверяем, находится ли курсор на кнопке
            if (!this.ClientRectangle.Contains(PointToClient(Cursor.Position)))
                return;

            fadeOutTimer.Stop();
            fadeInTimer.Start();
        }

        void ElementButtonNew_MouseLeave(object sender, EventArgs e)
        {
            fadeInTimer.Stop();
            fadeOutTimer.Start();
        }

        void ElementButtonNew_MouseUp(object sender, MouseEventArgs e)
        {
            fadeInTimer.Stop();
            fadeOutTimer.Stop();
            Invalidate();
        }

        void ElementButtonNew_MouseDown(object sender, MouseEventArgs e)
        {
            fadeInTimer.Stop();
            fadeOutTimer.Stop();
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs pevent)
        {
            pevent.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            OnPaintBackground(pevent);

            DrawButton(pevent.Graphics);
            DrawText(pevent.Graphics);
            DrawBorder(pevent.Graphics);
        }

        private void DrawText(Graphics gr)
        {
            Rectangle textRectangle = ClientRectangle;
            textRectangle.Inflate(-BorderWidth, -BorderWidth);
            TextRenderer.DrawText(gr, Text, Font, textRectangle, ForeColor,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter
                | TextFormatFlags.EndEllipsis);
        }

        private void DrawButton(Graphics gr)
        {
            int alpha = 255 - glowAlphaValue;
            LinearGradientBrush lg = new LinearGradientBrush(
                new Point(Width / 2, Height),
                new Point(Width / 2, 0), 
                Color.FromArgb(alpha, BaseColor), 
                Color.FromArgb(alpha, HighlightColor));
            gr.FillRectangle(lg, ClientRectangle);
        }

        private void DrawBorder(Graphics gr)
        {
            gr.DrawRectangle(new Pen(BorderColor, BorderWidth), 0, 0, ClientRectangle.Width - BorderWidth / 2, ClientRectangle.Height - BorderWidth / 2);
        }
    }
}
