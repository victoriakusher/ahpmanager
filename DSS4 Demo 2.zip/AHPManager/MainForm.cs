﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Windows.Forms;
using System.Xml;
using Document;
using AHP;
using System.Runtime.Serialization.Formatters.Binary;

namespace AHPManager
{
    public partial class MainForm : Form
    {
        private Hierarchy hierarchy;
        private const int buttonHeight = 34;
        private const int buttonWidth = 144;//120;

        ProjectStates projectState; // состояние загруженного проекта
        string projectFilename;     // имя файла, в который сохранен загруженный проект
                                    // если проект несохранен, то равно ""

        HierarchialStructure projectHierarchialStructure;   // иерархическая структура для расчетов МАИ
        bool rebuildHierarchialStructure;                   // флаг, указывает на необходимость перестройки
                                                            // иерархической структуры проекта

        /* Тип-перечисление, представляет всевозможные состояния проекта. */
        private enum ProjectStates
        {
            initial,            // начальное состояние (сразу после запуска программы)
            unsaved,            // проект загружен, но не сохранен в файл
            savedUnchanged,     // проект сохранен в файл и не изменен
            savedChanged        // проект сохранен в файл и изменен
        }

        ProjectStates ProjectState
        {
            get { return projectState; }
            set
            {
                switch (value)
                {
                    case ProjectStates.initial:
                        CreateProject_ToolStripMenuItem.Enabled = OpenProject_ToolStripMenuItem.Enabled
                            = newToolStripButton.Enabled = openToolStripButton.Enabled = true;
                        SaveProject_ToolStripMenuItem.Enabled = SaveAs_ToolStripMenuItem.Enabled
                            = saveToolStripButton.Enabled = toolStripBtn_VesEdit.Enabled = false;
                        Text = Application.ProductName;
                        break;
                    case ProjectStates.unsaved:
                        CreateProject_ToolStripMenuItem.Enabled = OpenProject_ToolStripMenuItem.Enabled
                            = newToolStripButton.Enabled = openToolStripButton.Enabled
                            = SaveProject_ToolStripMenuItem.Enabled = SaveAs_ToolStripMenuItem.Enabled
                            = saveToolStripButton.Enabled = toolStripBtn_VesEdit.Enabled = true;
                        Text = "Безымянный - " + Application.ProductName;
                        break;
                    case ProjectStates.savedUnchanged:
                        CreateProject_ToolStripMenuItem.Enabled = OpenProject_ToolStripMenuItem.Enabled
                            = newToolStripButton.Enabled = openToolStripButton.Enabled 
                            = SaveAs_ToolStripMenuItem.Enabled = toolStripBtn_VesEdit.Enabled = true;
                        SaveProject_ToolStripMenuItem.Enabled = saveToolStripButton.Enabled = false;
                        Text = Path.GetFileNameWithoutExtension(projectFilename) + " - " + Application.ProductName;
                        break;
                    case ProjectStates.savedChanged:
                        CreateProject_ToolStripMenuItem.Enabled = OpenProject_ToolStripMenuItem.Enabled
                            = newToolStripButton.Enabled = openToolStripButton.Enabled
                            = SaveProject_ToolStripMenuItem.Enabled = SaveAs_ToolStripMenuItem.Enabled
                            = saveToolStripButton.Enabled = toolStripBtn_VesEdit.Enabled = true;
                        break;
                }
                projectState = value;
            }
        }

        /// <summary>
        /// Класс для хранения настроек программы.
        /// </summary>
        private class ProjectParameters
        {
            /* Цвета для кнопок иерархии в различных состояниях. */
            public Color noComparisonsBaseColor = Color.FromArgb(78, 195, 88);
            public Color anyComparisonsBaseColor = Color.FromArgb(50, 154, 249);
            public Color allComparisonsBaseColor = Color.FromArgb(13, 102, 196);

            public Color noComparisonsHightlightColor = Color.White;
            public Color anyComparisonsHightlightColor = Color.White;
            public Color allComparisonsHightlightColor = Color.White;

            public Color borderColor = Color.DarkBlue;
        }

        /// <summary>
        /// Экземпляр класса ProjectParameters, хранит настроки программы.
        /// </summary>
        private ProjectParameters projectParameters = new ProjectParameters();

        /* Иерархическая структура проекта (представлена экземпляром класса AHP.HierarchialStructure)
         * должна перестраиваться после изменений в иерархии, а именно: добавлении или
         * удалении элемента иерархии или ее уровня. */

        public MainForm()
        {
            InitializeComponent();

            this.pnlHierarchy.Paint += new PaintEventHandler(pnlHierarchy_Paint);

            ProjectState = ProjectStates.initial;
            projectFilename = "";
            projectHierarchialStructure = null;
            rebuildHierarchialStructure = false;

            OpenNewPrj();
        }

        /* Обработчик выбора пункта главного меню "Создать проект". */
        private void CreateProject_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Недоступно в демоверсии.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /* Создание кнопки, представляющей элемент иерархии. */
        public void CreateElementButton(Element element)
        {
            // 
            // btn_element
            //
            int W = pnlHierarchy.Width;
            int H = pnlHierarchy.Height;
            int level = element.Lv.LevelNumber + 1;
            int ni = element.Lv.Count;

            int k = element.Lv.Elements.IndexOf(element) + 1;
            ElementButton btn_element = new ElementButton();
            btn_element.Tag = element;

            ColorElementButton(btn_element);

            btn_element.Font = new System.Drawing.Font("Microsoft Sans Serif",
                10F, System.Drawing.FontStyle.Regular,
                System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            btn_element.Location = new System.Drawing.Point(
                -buttonWidth / 2 + W / (2 * ni) + W / ni * (k-1),
                -buttonHeight / 2 + H / (2 * hierarchy.LevelsCount) + H / hierarchy.LevelsCount * (level - 1));
            btn_element.Name = "btn_element_" + element.Tag;
            btn_element.Text = element.Name;
            btn_element.Tag = element;

            System.Windows.Forms.ContextMenuStrip contextMenuStrip1 = new ContextMenuStrip();
            bool isBoss = (level == 1);

            CreateStripMenu4Buttons(contextMenuStrip1, isBoss);

            btn_element.ContextMenuStrip = contextMenuStrip1;
            btn_element.ContextMenuStrip.Tag = btn_element;
            btn_element.Click += new EventHandler(btn_element_Click);

            pnlHierarchy.Controls.Add(btn_element);

            btn_element.MouseEnter += new EventHandler(btn_element_MouseEnter);
            btn_element.MouseLeave += new EventHandler(btn_element_MouseLeave);
        }

        /* Обработчик события ухода указателя мыши с кнопки, представляющей элемент иерархии. */
        void btn_element_MouseLeave(object sender, EventArgs e)
        {
            pnlHierarchy_Paint(sender, null);
        }

        /* Обработчик события наведения указателя мыши на кнопку-элемент иерархии (отрисовка линий,
         * соединяющих кнопку-элемент с кнопками-элементами нижнего уровня. */
        void btn_element_MouseEnter(object sender, EventArgs e) // стрелочки
        {
            Button btn = sender as Button;
            Element element = btn.Tag as Element;
            Point point = btn.Location;
            point.X += buttonWidth / 2;
            point.Y += buttonHeight;
            Graphics G;
            Pen pen = new Pen(Color.DarkMagenta, 2);
            int level = element.Lv.LevelNumber + 1;

            if (hierarchy.LevelsCount != level)
            {
                G = this.pnlHierarchy.CreateGraphics();
                int elementCount = hierarchy.Levels[level].Count;
                int W = pnlHierarchy.Width;
                int H = pnlHierarchy.Height;
               G.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                 
                for (int i = 1; i <= elementCount; i++)
                {
                    Point pointEnd = new System.Drawing.Point(
                        W / (2 * elementCount) + W / elementCount * (i - 1),
                        -buttonHeight / 2 + H / (2 * hierarchy.LevelsCount) + H / hierarchy.LevelsCount * (level));
                    G.DrawLine(pen, point.X, point.Y, pointEnd.X, pointEnd.Y);
                }
                G.Dispose();
            }
        }

        /* Вызов окна попарного сравнения элементов. */
        void btn_element_Click(object sender, EventArgs e)
        {
            ElementButton btn_element = sender as ElementButton;
            Element element = btn_element.Tag as Element;
            if (element.CriterionType != Criterions.noncriterion)
            {
                CompareForm compare = new CompareForm(hierarchy, element);
                compare.ShowDialog();

                ColorElementButton(btn_element);

                // указываем, что проект изменился
                if (ProjectState == ProjectStates.savedUnchanged)
                    ProjectState = ProjectStates.savedChanged;
                // если создана иерархическая структура задачи, не требующая обновления,
                // то обновляем в ней данные об оценках
                if (projectHierarchialStructure != null && !rebuildHierarchialStructure)
                {
                    int LevelNumber = 0;        // номер уровня, в котором содержится элемент
                    int elementNumber = 0;      // номер элемента в уровне
                    GetElementLocation(element, out LevelNumber, out elementNumber);
                    // создаем новый узел, отвечающий обновленному элементу иерархии
                    Node updatedNode = null;
                    switch (element.CriterionType)
                    {
                        case Criterions.comparative:
                            updatedNode = new Node(element.LowerLevelCount(),
                                Node.NodeTypes.comparative,
                                new EigenvectorMethod(),
                                AuxiliaryClass.CreateScale(element, hierarchy));
                            updatedNode.comparisonsMatrix = AuxiliaryClass.CMToAHPMatrix(element.PairComparisons);
                            break;
                        case Criterions.quantitative:
                            updatedNode = new Node(element.LowerLevelCount(),
                                Node.NodeTypes.quantitative,
                                AuxiliaryClass.GetWTM(element.QuantCriterionType));
                            updatedNode.weights = element.ElementValues;
                            break;
                    }
                    // оценки изменились, следовательно, нужно пересчитать локальные приоритеты
                    updatedNode.recalculationRequired = true;
                    // обновляем узел в иерархической структуре
                    projectHierarchialStructure.nodes[LevelNumber][elementNumber] = updatedNode;
                }
            }
        }

        /* Формирование контексного меню кнопки-элемента иерархии. */
        private void CreateStripMenu4Buttons(System.Windows.Forms.ContextMenuStrip contextMenuStrip1, bool isBoss)
        {
            System.Windows.Forms.ToolStripMenuItem EditElement_ToolStripMenuItem = new ToolStripMenuItem();
            System.Windows.Forms.ToolStripMenuItem AddElement_ToolStripMenuItem = new ToolStripMenuItem();
            System.Windows.Forms.ToolStripMenuItem DeleteElement_ToolStripMenuItem = new ToolStripMenuItem();
            System.Windows.Forms.ToolStripSeparator toolStripSeparator1 = new ToolStripSeparator();
            System.Windows.Forms.ToolStripSeparator toolStripSeparator2 = new ToolStripSeparator();
            System.Windows.Forms.ToolStripMenuItem AddLayer_ToolStripMenuItem = new ToolStripMenuItem();
            System.Windows.Forms.ToolStripMenuItem EditLayer_ToolStripMenuItem = new ToolStripMenuItem();
            System.Windows.Forms.ToolStripMenuItem DeleteLayer_ToolStripMenuItem = new ToolStripMenuItem();

            // 
            // contextMenuStrip1
            // 
            if (!isBoss)
            {
                contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
                EditElement_ToolStripMenuItem,
                toolStripSeparator1,
                AddElement_ToolStripMenuItem,
                DeleteElement_ToolStripMenuItem,
                toolStripSeparator2,
                AddLayer_ToolStripMenuItem,
                EditLayer_ToolStripMenuItem,
                DeleteLayer_ToolStripMenuItem
                });
            }
            else
            {
                contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
                    EditElement_ToolStripMenuItem,
                    toolStripSeparator1,
                    AddLayer_ToolStripMenuItem
                });
            }
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.ShowImageMargin = false;
            contextMenuStrip1.Size = new System.Drawing.Size(151, 120);
            // 
            // EditElement_ToolStripMenuItem
            // 
            EditElement_ToolStripMenuItem.Name = "EditElement_ToolStripMenuItem";
            EditElement_ToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
            EditElement_ToolStripMenuItem.Text = "Редактировать элемент";
            EditElement_ToolStripMenuItem.Click += new EventHandler(EditElement_ToolStripMenuItem_Click);
            // 
            // AddElement_ToolStripMenuItem
            // 
            AddElement_ToolStripMenuItem.Name = "AddElement_ToolStripMenuItem";
            AddElement_ToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
            AddElement_ToolStripMenuItem.Text = "Добавить элемент";
            AddElement_ToolStripMenuItem.Click += new EventHandler(AddElement_ToolStripMenuItem_Click);
            // 
            // DeleteElement_ToolStripMenuItem
            // 
            DeleteElement_ToolStripMenuItem.Name = "DeleteElement_ToolStripMenuItem";
            DeleteElement_ToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
            DeleteElement_ToolStripMenuItem.Text = "Удалить элемент";
            DeleteElement_ToolStripMenuItem.Click += new System.EventHandler(this.DeleteElement_ToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            toolStripSeparator1.Name = "toolStripSeparator1";
            toolStripSeparator1.Size = new System.Drawing.Size(147, 6);

            // toolStripSeparator2 
            toolStripSeparator2.Name = "toolStripSeparator2";
            toolStripSeparator2.Size = new System.Drawing.Size(147, 6);             
            
            // AddLayer_ToolStripMenuItem
             
            AddLayer_ToolStripMenuItem.Name = "AddLayer_ToolStripMenuItem";
            AddLayer_ToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
            AddLayer_ToolStripMenuItem.Text = "Добавить уровень";
            AddLayer_ToolStripMenuItem.Click += new EventHandler(AddLayer_ToolStripMenuItem_Click);

            // EditLayer_ToolStripMenuItem

            EditLayer_ToolStripMenuItem.Name = "EditLayer_ToolStripMenuItem";
            EditLayer_ToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
            EditLayer_ToolStripMenuItem.Text = "Редактировать уровень";
            EditLayer_ToolStripMenuItem.Click += new EventHandler(EditLayer_ToolStripMenuItem_Click);
             
            // DeleteLayer_ToolStripMenuItem
             
            DeleteLayer_ToolStripMenuItem.Name = "DeleteLayer_ToolStripMenuItem";
            DeleteLayer_ToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
            DeleteLayer_ToolStripMenuItem.Text = "Удалить уровень";
            DeleteLayer_ToolStripMenuItem.Click += new EventHandler(DeleteLayer_ToolStripMenuItem_Click);
        }

        /* Добавление элемента в уровень иерархии */
        void AddElement_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Недоступно в демоверсии.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /* Редактирование имени и описания элемента иерархии. */
        void EditElement_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem menuItem = sender as ToolStripMenuItem;
            Button btn = menuItem.Owner.Tag as Button;
            Element element = btn.Tag as Element;

            PropertiesForm propertiesForm = new PropertiesForm("Редактирование элемента", element);
            if (propertiesForm.ShowDialog() == DialogResult.OK)
            {
                element.Name = propertiesForm.GetName();
                element.Description = propertiesForm.GetDescription();
                btn.Text = element.Name;

                if (ProjectState == ProjectStates.savedUnchanged)
                    ProjectState = ProjectStates.savedChanged;
            }
        }

        /* Добавление нового уровня иерархии. */
        void AddLayer_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Недоступно в демоверсии.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /* Редактирование имени и описания уровня иерархии. */
        void EditLayer_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem menuItem = sender as ToolStripMenuItem;
            Button btn = menuItem.Owner.Tag as Button;
            Element element = btn.Tag as Element;

            PropertiesForm propertiesForm = new PropertiesForm("Редактирование уровня", element.Lv);
            if (propertiesForm.ShowDialog() == DialogResult.OK)
            {
                element.Lv.Name = Name = propertiesForm.GetName();
                element.Lv.Description = propertiesForm.GetDescription();

                if (ProjectState == ProjectStates.savedUnchanged)
                    ProjectState = ProjectStates.savedChanged;
            }
        }

        /* Удаление уровня иерархии. */
        void DeleteLayer_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Недоступно в демоверсии.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /* Выбор пункта "Сохранить проект" в главном меню. */
        private void SaveProject_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Недоступно в демоверсии.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Button newBtn = new Button();
            //newBtn.Location = new System.Drawing.Point(500, 30);
            //newBtn.Name = "btn_Run" + num.ToString();
            //newBtn.Size = new System.Drawing.Size(75, 23);
            //newBtn.Text = "Тест";
            //newBtn.UseVisualStyleBackColor = true;
            //newBtn.MouseDoubleClick += new MouseEventHandler(newBtn_MouseDoubleClick);
            ////newBtn.
            //this.Controls.Add(newBtn);
            //pnlHierarchy.Controls.Add(newBtn);
            pnlHierarchy.Width = pnlHierarchy.Width / 2;
        }

        /* Обработчик события выхода формы из режима изменения размеров. */
        protected override void OnResizeEnd(EventArgs e)
        {
            base.OnResizeEnd(e);
            pnlHierarchy.Width = this.Width - 40;
            pnlHierarchy.Height = this.Height - 100;
            ReDrawHierarchy();
        }

        /* Перерисовка иерархической структуры задачи. */
        private void ReDrawHierarchy()
        {
            foreach (Control control in pnlHierarchy.Controls)
            {
                if (control is Button)
                {
                    Button btn = control as Button;
                    if (btn.Tag is Hierarchy)
                    {
                        btn.Location = new System.Drawing.Point(
                            -buttonWidth / 2 + pnlHierarchy.Width / 2,
                            -buttonHeight / 2 + pnlHierarchy.Height /
                            (2 * hierarchy.LevelsCount));

                    }
                    else if (btn.Tag is Element)
                    {
                        Element element = btn.Tag as Element;
                        int W = pnlHierarchy.Width;
                        int H = pnlHierarchy.Height;
                        int level = element.Lv.LevelNumber + 1;
                        int ni = hierarchy.Levels[level - 1].Count;
                        int k = element.Lv.Elements.IndexOf(element) + 1;
                        btn.Location = new System.Drawing.Point(
                            -buttonWidth / 2 + W / (2 * ni) + W / ni * (k - 1),
                            -buttonHeight / 2 + H / (2 * hierarchy.LevelsCount) + H / hierarchy.LevelsCount * (level - 1));
                    }
                }
            }
        }

        /* Убирает все кнопки-элементы иерархии. */
        private void ClearAllButtons()
        {
            List<Button> listOfButtons2Delete = new List<Button>();
            foreach (Control control in pnlHierarchy.Controls)
            {
                if (control is Button)
                {
                    Button btn = control as Button;
                    listOfButtons2Delete.Add(btn);
                }
            }

            for (int i = 0; i < listOfButtons2Delete.Count; ++i)
            {
                pnlHierarchy.Controls.Remove(listOfButtons2Delete[i]);
            }
        }

        /* Обработка выбора пункта "Удалить элемент" из контексного меню кнопки-элемента иерархии. */
        private void DeleteElement_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Недоступно в демоверсии.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /* Обработка нажатия на кнопку подсчета весов на панели программы: вывод результатов. */
        private void toolStripBtn_VesEdit_Click(object sender, EventArgs e) // посчитать
        {
            if(hierarchy != null)
            {
                tsmiResults_Click(sender, e);
            }
        }

        /* Процедура загрузки проекта из файла. */
        private void OpenNewPrj()
        {
            OpenFileDialog openPrjDialog = new OpenFileDialog();

            openPrjDialog.InitialDirectory = System.IO.Path.GetDirectoryName(
                System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase) + @"\Примеры";
            openPrjDialog.Filter = "Файлы проектов (*.prj)|*.prj";
            openPrjDialog.FilterIndex = 1;
            openPrjDialog.RestoreDirectory = true;

            if (openPrjDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    Stream stream = openPrjDialog.OpenFile();
                    BinaryFormatter formatter = new BinaryFormatter();
                    hierarchy = (Hierarchy)formatter.Deserialize(stream);
                    
                    // инициализируем значения по умолчанию для классов шкал
                    SaatyScale.DefaultScaleParameters = hierarchy.defaultScaleParameters[2].ToArray();

                    /* После успешной загрузки проекта приводим в порядок главную форму. */
                    ClearAllButtons();
                    foreach (Level level in hierarchy.Levels)
                    {
                        foreach (Element element in level.Elements)
                        {
                            CreateElementButton(element);
                        }
                    }

                    projectFilename = openPrjDialog.FileName;       // запоминаем имя открытого файла
                    ProjectState = ProjectStates.savedUnchanged;    // меняем состояние проекта
                    tsmiProject.Enabled = true;                     // разблокируем пукнт меню "Проект"
                    tsmiAnalysis.Enabled = true;                    // разблокируем пункт меню "Анализ"
                }
                catch (XmlException xmlEx)
                {
                    MessageBox.Show("XML error: " + xmlEx.Message);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                }
            }
        }

        /* Procedures to paint an area for hierarchial structure of the problem. */
        void pnlHierarchy_Paint(object sender, PaintEventArgs e)
        {
            Graphics gr = pnlHierarchy.CreateGraphics();

            LinearGradientBrush lg = new LinearGradientBrush(
                new Point(ClientSize.Width / 2, 0),
                new Point(ClientSize.Width / 2, ClientSize.Height),
                Color.FromArgb(203, 234, 252), 
                Color.FromArgb(117, 205, 243));
            gr.FillRectangle(lg, ClientRectangle);
        }

        /* Выбор пункта "Открыть проект" в главном меню программы. */
        private void OpenProject_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
             OpenNewPrj(); 
        }

        /* Выбор пункта "Сохранить проект" в главном меню программы. */
        private void saveToolStripButton_Click(object sender, EventArgs e)
        {
            SaveProject_ToolStripMenuItem_Click(sender, e);
        }

        /* Нажатие на кнопку "Создать проект" на панели программы. */
        private void newToolStripButton_Click(object sender, EventArgs e)
        {
            CreateProject_ToolStripMenuItem_Click(sender, e);
        }

        /* Нажатие на кнопку "Открыть проект" на панели программы. */
        private void openToolStripButton_Click(object sender, EventArgs e)
        {
            OpenProject_ToolStripMenuItem_Click(sender, e);
        }

        /* Выбор пункта "Выход" главного меню программы. */
        private void Exit_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /* Процедура изменения размеров иерархической структуры программы. */
        private void pnlHierarchy_Resize(object sender, EventArgs e)
        {
            /* Проверяем, нужно ли перерисовывать компоненты. */
            if (hierarchy != null)
            {
                /* Удаляем старые кнопки и создаем новые. */
                ClearAllButtons();
                foreach (Level level in hierarchy.Levels)
                {
                    foreach (Element element in level.Elements)
                    {
                        CreateElementButton(element);
                    }
                }
            }
        }

        /* Выбор пункта "О программе" главного меню программы. */
        private void AboutProgToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox myAboutBox = new AboutBox();
            myAboutBox.Show();
        }

        /* Нажатие на кнопку "Справка" панели программы. */
        private void Help_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Недоступно в демоверсии.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /* Выбор пункта "О программе" главного меню программы. */
        private void AboutProgToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            AboutBox box = new AboutBox();
            box.ShowDialog();
        }

        /* Выбор пункта "Вызов справки" главного меню программы. */
        private void ShowHelpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Недоступно в демоверсии.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        
        private void tsmiProjectProperties_Click(object sender, EventArgs e)
        {
            PropertiesForm propertiesForm = new PropertiesForm("Свойства проекта", hierarchy);
            if (propertiesForm.ShowDialog() == DialogResult.OK)
            {
                hierarchy.Name = propertiesForm.GetName();
                hierarchy.Description = propertiesForm.GetDescription();

                if (ProjectState == ProjectStates.savedUnchanged)
                    ProjectState = ProjectStates.savedChanged;
            }
        }

        private void tsmiProjectStatistics_Click(object sender, EventArgs e)
        {
            ProjectStatisticsForm statisticsForm = new ProjectStatisticsForm(hierarchy);
            statisticsForm.ShowDialog();
        }

        /// <summary>
        /// Возвращает номер уровня и номер места в уровне, на котором находиться
        /// элемент element. Если указанный элемент не был найден в иерархии,
        /// то LevelNumber и elementNumber присваиваются значения -1.
        /// </summary>
        /// <param name="element">Элемент, место которого ищется.</param>
        /// <param name="LevelNumber">Номер уровня иерархии, в котором находится элемент.</param>
        /// <param name="elementNumber">Номер элемента в уровне иерархии.</param>
        private void GetElementLocation(Element element, out int LevelNumber, 
            out int elementNumber)
        {
            LevelNumber = elementNumber = -1;
            for (int i = 0; i < hierarchy.LevelsCount; i++)
                for (int j = 0; j < hierarchy.Levels[i].Count; j++)
                    if (element == hierarchy.Levels[i].Elements[j])
                    {
                        LevelNumber = i;
                        elementNumber = j;
                        return;
                    }
        }

        private void tsmiResults_Click(object sender, EventArgs e)
        {
            /* Проверяем, выставлены ли все оценки и суждения, если нет, то выводим предупреждение. */
            if (AuxiliaryClass.CheckForMissingAppraisals(hierarchy))
            {
                if (MessageBox.Show("Выставлены не все оценки в иерархии. Вы действительно хотите вывести результаты?",
                    "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                    return;
            }

            /* Если иерархическая структура не построена или ее нужно перестроить,
             * то перестраиваем ее. */
            if (rebuildHierarchialStructure || projectHierarchialStructure == null)
                projectHierarchialStructure = AuxiliaryClass.ConvertHierarchy(hierarchy);

            double[] priorities = projectHierarchialStructure.GetPriorities();

            // формируем массив из названий альтернатив
            string[] names = new string[hierarchy.Levels[hierarchy.LevelsCount - 1].Count];
            for (int i = 0; i < hierarchy.Levels[hierarchy.LevelsCount - 1].Count; i++)
                names[i] = hierarchy.Levels[hierarchy.LevelsCount - 1].Elements[i].Name;
            //ResultsForm resForm = new ResultsForm(names, priorities);
            ResultsForm zedGraphResults = new ResultsForm(this.hierarchy.Name, this, hierarchy);
            //zedGraphResults.Parent = this;
            zedGraphResults.SetParams(priorities, names);
            //resForm.ShowDialog();
            zedGraphResults.ShowDialog();
        }

        /// <summary>
        /// Обновляет расцветку кнопок, представдяющих элементы иерархии.
        /// </summary>
        private void UpdateElementButtonColors()
        {
            foreach (Control control in pnlHierarchy.Controls)
                if (control is ElementButton)
                    ColorElementButton(control as ElementButton);
        }

        private void tsmiDefaultScaleParameters_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Недоступно в демоверсии.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void SaveAs_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Недоступно в демоверсии.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /// <summary>
        /// Окрашивает кнопку-элемент иерархии в зависимости от ее состояния как критерия.
        /// </summary>
        /// <param name="elementButton">Кнопка-элемент иерархии.</param>
        private void ColorElementButton(ElementButton elementButton)
        {
            Element element = elementButton.Tag as Element;

            elementButton.BorderColor = projectParameters.borderColor;
            /* Проверяем, как обстоят дела с оценками альтернатив относительно
             * критерия, представленного element: были ли выставлены оценки, и если да,
             * то все или нет? */
            if (element.ComparisonsComplete)
            {
                // все попарные сравнения проведены
                elementButton.BaseColor = projectParameters.allComparisonsBaseColor;
                elementButton.HighlightColor = projectParameters.allComparisonsHightlightColor;
            }
            else if (element.AnyComparisons)
            {
                // попарные сравнения проведены не полностью
                elementButton.BaseColor = projectParameters.anyComparisonsBaseColor;
                elementButton.HighlightColor = projectParameters.anyComparisonsHightlightColor;
            }
            else
            {
                // попарные сравнения не проводились
                elementButton.BaseColor = projectParameters.noComparisonsBaseColor;
                elementButton.HighlightColor = projectParameters.noComparisonsHightlightColor;
            }
        }

        private void tsmiReport_Click(object sender, EventArgs e)
        {
            /* Проверяем, выставлены ли все оценки и суждения, если нет, то выводим предупреждение. */
            if (AuxiliaryClass.CheckForMissingAppraisals(hierarchy))
            {
                if (MessageBox.Show("Выставлены не все оценки в иерархии. Вы действительно хотите вывести отчет?",
                    "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                    return;
            }

            ReportForm reportForm = new ReportForm(hierarchy);
            reportForm.ShowDialog();
        }
    }
}
