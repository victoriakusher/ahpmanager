﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace AHPManager
{
    public partial class CreateProjectForm : Form
    {
        private string goalPrj;         // конечная цель
        private int numberHierarch;     // количество уровней 
        private string comment;         // комментарий к иерархии
        private int initialElements;    // начальное число элементов

        public int NumberHierarch
        {
            get { return numberHierarch; }
            set { numberHierarch = value; }
        }

        public int MaxNumElements
        {
            get { return initialElements; }
            set { initialElements = value; }
        }

        public string GoalPrj
        {
            get { return goalPrj; }
            set { goalPrj = value; }
        }

        public string Comment
        {
            get { return comment; }
            set { comment = value; }
        }

        public CreateProjectForm()
        {
            InitializeComponent();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            /* Проверка корректности значений в полях ввода. "Цель проекта"
             * должна содержать непустую строку, "число уровней иерархии" - 
             * натуральное число >= 2, "начальное количество элементов" - 
             * натуральное число >= 2. */

            try
            {
                // Проверяем, введено ли что-нибудь в поле ввода цели проекта.
                if (tboxName.Text.Length > 0)
                {

                    goalPrj = tboxName.Text;
                    comment = this.tboxComment.Text;
                    numberHierarch = int.Parse(tboxLevelsNumber.Text);
                    initialElements = int.Parse(tboxElementsNumber.Text);

                    // проверяем корректность числа уровней и начального количества элементов
                    if (numberHierarch < 2) throw new Exception("Количество уровней иерархии должно быть больше 2");
                    else if (initialElements < 2 || initialElements > 15) throw new Exception("Количество элементов в иерархии должно быть в пределах от 2 до 15.");
                    this.DialogResult = DialogResult.OK;
                }
                else
                {
                    MessageBox.Show("Введите название цели проекта.");
                    tboxName.Focus();
                }
            }
            catch (FormatException)
            {
                // обработка ввода некорректных числовых данных
                MessageBox.Show("Введите корректные числовые данные.");
            }
            catch (Exception exc)
            {
                // обработка ввода неправильных значений
                MessageBox.Show(exc.Message);
            }
        }
    }
}
