﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Document;
using AHP;

namespace AHPManager
{
    namespace ReportClasses
    {
        /// <summary>
        /// Представляет отображамые в отчете данные об иерархии.
        /// </summary>
        class HierarchySummary
        {
            /// <summary>
            /// Закрытое поле класса - отображаемая иерархия.
            /// </summary>
            private Hierarchy hr;

            /* Массив строк - описаний оценок. */
            private string[] appraisalDescriptions = 
        { 
            "эквивалентно",
            "слабо превосходит",
            "сильно превосходит",
            "очевидно превосходит",
            "абсолютно превосходит"
        };

            /// <summary>
            /// Конструктор класса, параметр - иерархия, представляемая
            /// в отчете.
            /// </summary>
            /// <param name="hierarchy">Представляемая в отчете иерархия.</param>
            public HierarchySummary(Hierarchy hierarchy)
            {
                hr = hierarchy;
            }

            /// <summary>
            /// Название иерархии (свойство только для чтения).
            /// </summary>
            public string HierarchyName
            {
                get { return hr.Name; }
            }

            /// <summary>
            /// Описание иерархии (свойство только для чтения).
            /// </summary>
            public string HierarchyDescription
            {
                get { return hr.Description; }
            }

            /// <summary>
            /// Возвращает список экземпляров класса LevelSummary,
            /// представляющих отображаемые в отчете свойства уровней
            /// иерархии.
            /// </summary>
            public List<LevelSummary> GetLevelSummaries()
            {
                // уровень цели не включаем в отчет
                List<LevelSummary> levelSummaries = new List<LevelSummary>();

                for (int i = 1; i < hr.LevelsCount; i++)
                    levelSummaries.Add(new LevelSummary(hr.Levels[i]));

                return levelSummaries;
            }

            /// <summary>
            /// Возвращает список экземпляров класса ElementSummary,
            /// представляющих отображаемые в отчете свойства элементов
            /// иерархии.
            /// </summary>
            public List<ElementSummary> GetElementSummaries()
            {
                List<ElementSummary> elementSummaries = new List<ElementSummary>();
                foreach (Level level in hr.Levels)
                    foreach (Element element in level.Elements)
                        elementSummaries.Add(new ElementSummary(element));

                return elementSummaries;
            }

            /// <summary>
            /// Возвращает список экземпляров класса AlternativeSummary,
            /// представляющих отображаемые в отчете результаты решения
            /// задачи (название альтернатив и их веса).
            /// </summary>
            public List<AlternativeSummary> GetResults()
            {
                List<AlternativeSummary> alternativeSummaries = new List<AlternativeSummary>();

                double[] priorities = AuxiliaryClass.ConvertHierarchy(hr).GetPriorities();
                for (int i = 0; i < hr.Levels.Last().Count; i++)
                    alternativeSummaries.Add(new AlternativeSummary(hr.Levels.Last().Elements[i].Name, priorities[i]));

                return alternativeSummaries;
            }

            /// <summary>
            /// Равняется true, если были выставлены оценки для всех элементов иерархии.
            /// </summary>
            public bool HierarchyAreAppraisalsIncomplete
            {
                get
                {
                    foreach (Level level in hr.Levels)
                        foreach (Element element in level.Elements)
                            if (!element.ComparisonsComplete && element.CriterionType != Criterions.noncriterion)
                                return true;
                    return false;
                }
            }

            /// <summary>
            /// Возвращает список экземпляров класса ElementValueSummary,
            /// представляющих отображаемые в отчете суждения относительно
            /// количественных критериев.
            /// </summary>
            public List<ElementValueSummary> GetElementValueSummaries()
            {
                List<ElementValueSummary> result = new List<ElementValueSummary>(); ;

                for (int i = 0; i < hr.LevelsCount; i++)
                    for (int j = 0; j < hr.Levels[i].Count; j++)
                        if (hr.Levels[i].Elements[j].CriterionType == Criterions.quantitative)
                        {
                            for (int k = 0; k < hr.Levels[i].Elements[j].LowerLevelCount(); k++)
                                result.Add(new ElementValueSummary(
                                    String.Concat(i + 1, "-", j + 1),
                                    hr.Levels[i].LowerLevel.Elements[k].Name,
                                    hr.Levels[i].Elements[j].IsDefined[k] ?
                                    hr.Levels[i].Elements[j].ElementValues[k].ToString() : "?"));
                        }
                return result;
            }

            public List<PairComparisonSummary> GetPairComparisonSummaries()
            {
                List<PairComparisonSummary> result = new List<PairComparisonSummary>();

                Element element;
                for (int i = 0; i < hr.LevelsCount; i++)
                    for (int j = 0; j < hr.Levels[i].Count; j++)
                    {
                        element = hr.Levels[i].Elements[j];
                        if (element.CriterionType == Criterions.comparative)
                        {
                            for (int k = 0; k < element.LowerLevelCount(); k++)
                                for (int l = k + 1; l < element.LowerLevelCount(); l++)
                                    if (element.PairComparisons[k, l] >= 0)
                                        result.Add(new PairComparisonSummary(
                                            String.Concat(i + 1, "-", j + 1),
                                            element.Lv.LowerLevel.Elements[k].Name,
                                            element.PairComparisons[k, l] != Appraisals.undefined ?
                                            appraisalDescriptions[Math.Abs(element.PairComparisons[k, l])] :
                                            "?",
                                            element.Lv.LowerLevel.Elements[l].Name));
                                    else
                                        result.Add(new PairComparisonSummary(
                                            String.Concat(i + 1, "-", j + 1),
                                            element.Lv.LowerLevel.Elements[l].Name,
                                            element.PairComparisons[k, l] != Appraisals.undefined ?
                                            appraisalDescriptions[Math.Abs(element.PairComparisons[k, l])] :
                                            "?",
                                            element.Lv.LowerLevel.Elements[k].Name));
                        }
                    }
                return result;
            }

            public List<LocalAlternativeSummary> GetLocalAlternativeSummaries()
            {
                List<LocalAlternativeSummary> result = new List<LocalAlternativeSummary>();

                Element element;
                double[] localPriorities;
                for (int i = 0; i < hr.LevelsCount - 1; i++)
                    for (int j = 0; j < hr.Levels[i].Count; j++)
                    {
                        element = hr.Levels[i].Elements[j];
                        localPriorities = AuxiliaryClass.GetLocalPriorities(element);

                        for (int k = 0; k < element.LowerLevelCount(); k++)
                            result.Add(new LocalAlternativeSummary(
                                String.Concat(i + 1, "-", j + 1),
                                element.Lv.LowerLevel.Elements[k].Name,
                                localPriorities[k], GetProblemCode(element)));
                    }
                return result;
            }

            /// <summary>
            /// Возвращает целое число, означающие присутствие или отсутствие проблем
            /// с оценками относительно данного элемента иерархии.
            /// </summary>
            /// <returns>Возможные значения:
            /// 0 - все в порядке,
            /// 1 - сравнительный критерий, есть отсутствующие оценки,
            /// 2 - количественный критерий, есть отсутствующие оценки (но не все),
            /// 3 - количественный критерий, оценки полностью отсутствуют.
            /// </returns>
            private int GetProblemCode(Element element)
            {
                switch (element.CriterionType)
                {
                    case Criterions.comparative:
                        for (int i = 0; i < element.PairComparisons.Size; i++)
                            for (int j = 0; j < element.PairComparisons.Size; j++)
                                if (element.PairComparisons[i, j] == Appraisals.undefined)
                                    return 1;
                        break;
                    case Criterions.quantitative:
                        if (element.IsDefined.All(p => p == false))
                            return 3;
                        else if (element.IsDefined.Any(p => p == false))
                            return 2;
                        break;
                    case Criterions.noncriterion:
                        // у альтернатив проблем со сравнениями не может быть
                        break;
                }
                return 0;
            }
        }

        /// <summary>
        /// Представляет отображаемые в отчете данные об уровне иерархии.
        /// </summary>
        public class LevelSummary
        {
            /// <summary>
            /// Закрытое поле класса - отображаемый уровень иерархии.
            /// </summary>
            private Level level;

            /// <summary>
            /// Название уровня иерархии (свойство только для чтения).
            /// </summary>
            public string LevelName
            {
                get { return level.Name; }
            }

            /// <summary>
            /// Описание уровня иерархии (свойство только для чтения).
            /// </summary>
            public string LevelDescription
            {
                get { return level.Description; }
            }

            /// <summary>
            /// Количество элементов в уровне иерархии (свойство только для чтения).
            /// </summary>
            public int LevelElementsNumber
            {
                get { return level.Count; }
            }

            /// <summary>
            /// Конструктор класса, принимает представляемый в отчете уровень иерархии.
            /// </summary>
            /// <param name="level">Представляемый в отчете уровень иерархии.</param>
            public LevelSummary(Level level)
            {
                this.level = level;
            }
        }

        /// <summary>
        /// Представляет отображаемые в отчете данные об элементе иерархии.
        /// </summary>
        public class ElementSummary
        {
            private static string[] appraisalDescriptions = 
        { 
            "эквивалентно",
            "слабо превосходит",
            "сильно превосходит",
            "очевидно превосходит",
            "абсолютно превосходит",
        };

            /// <summary>
            /// Закрытое поле класса - отображаемый элемент иерархии.
            /// </summary>
            private Element element;

            /// <summary>
            /// Название элемента иерархии (свойство только для чтения).
            /// </summary>
            public string ElementName
            {
                get { return element.Name; }
            }

            /// <summary>
            /// Описание элемента иерархии (свойство только для чтения).
            /// </summary>
            public string ElementDescription
            {
                get { return element.Description; }
            }

            /// <summary>
            /// Возвращает true, если для данного элемента как критерия
            /// были выставлены все оценки.
            /// </summary>
            public bool ElementAreAppraisalsComplete
            {
                get
                {
                    return (element.ComparisonsComplete ||
                        element.CriterionType == Criterions.noncriterion);
                }
            }

            /// <summary>
            /// Строка, описывающая тип элемента иерархии как критерия.
            /// </summary>
            public string ElementCriterionType
            {
                get
                {
                    string result = "";

                    switch (element.CriterionType)
                    {
                        case Criterions.comparative:
                            result = "сравнительный";
                            break;
                        case Criterions.noncriterion:
                            result = "альтернатива";
                            break;
                        case Criterions.quantitative:
                            result = "количественный";
                            break;
                    }

                    return result;
                }
            }

            /// <summary>
            /// Конструктор класса, параметр - элемент иерархии, представляемый
            /// в отчете.
            /// </summary>
            /// <param name="element"></param>
            public ElementSummary(Element element)
            {
                this.element = element;
            }

            /// <summary>
            /// Строка, описывающая параметры элемента иерархии как критерия.
            /// </summary>
            public string ElementParameters
            {
                get
                {
                    string result = "";

                    switch (element.CriterionType)
                    {
                        case Criterions.comparative:
                            // записываем в параметры элемента тип шкалы
                            // и ее параметры
                            switch (element.ScaleType)
                            {
                                case Scales.Bruck:
                                    result = "шкала Брука, ";
                                    if (element.UseDefaultScaleParameters)
                                        result += "параметры по умолчанию";
                                    else if (element.UseClassicScaleParameters)
                                        result += "классические параметры";
                                    else
                                        result += String.Concat("центр: ", element.CustomScaleParameters[0], ", масштаб: " + element.CustomScaleParameters[1]);
                                    break;
                                case Scales.logistic:
                                    result = "логистическая шкала, ";
                                    if (element.UseDefaultScaleParameters)
                                        result += "параметр по умолчанию";
                                    else if (element.UseClassicScaleParameters)
                                        result += "классический параметр";
                                    else
                                        result += String.Concat("резкость: ", element.CustomScaleParameters[0]);
                                    break;
                                case Scales.Saaty:
                                    result = "шкала Саати, ";
                                    if (element.UseDefaultScaleParameters)
                                        result += "параметр по умолчанию";
                                    else if (element.UseClassicScaleParameters)
                                        result += "классический параметр";
                                    else
                                        result += String.Concat("масштаб: ", element.CustomScaleParameters[0]);
                                    break;
                            }
                            break;
                        case Criterions.quantitative:
                            switch (element.QuantCriterionType)
                            {
                                case QuantCriterions.ascending:
                                    result = "возрастающий";
                                    break;
                                case QuantCriterions.descending:
                                    result = "убывающий";
                                    break;
                            }
                            break;
                        case Criterions.noncriterion:
                            result = "-";
                            break;
                    }
                    return result;
                }
            }

            /// <summary>
            /// Номер уровня, в котором содержится элемент иерархии.
            /// </summary>
            public int ElementLevelNumber
            {
                get { return element.Lv.LevelNumber; }
            }

            /// <summary>
            /// Название уровня, в котором содержится элемент иерархии.
            /// </summary>
            public string ElementLevelName
            {
                get { return element.Lv.Name; }
            }

            /// <summary>
            /// Количество циклов, которые образуются попарные суждения
            /// относительно элемента иерархии как критерия.
            /// </summary>
            /// <remarks>Если элемент иерархии не является сравнительным 
            /// критерием, то это свойство равно 0.</remarks>
            public int ElementCyclesNumber
            {
                get
                {
                    return AuxiliaryClass.SearchForCyclicTriads(element).Count;
                }
            }

            /// <summary>
            /// Возвращает матрицу попарных сравнений для элемента иерархии
            /// как сравнительного критерия.
            /// </summary>
            public string[,] ElementPairComparisons
            {
                get
                {
                    string[,] pairComparisons = new string[element.LowerLevelCount(), element.LowerLevelCount()];
                    for (int i = 0; i < element.LowerLevelCount(); i++)
                        for (int j = 0; j < element.LowerLevelCount(); j++)
                            pairComparisons[i, j] = (element.PairComparisons[i, j] != Appraisals.undefined) ?
                                element.PairComparisons[i, j].ToString() : "NA";
                    return pairComparisons;
                }
            }

            /// <summary>
            /// Возвращает массив численных значений элементов уровнем ниже
            /// рассматриваемого элемента иерархии.
            /// </summary>
            public string[] ElementPriorities
            {
                get
                {
                    string[] elementPriorities = new string[element.LowerLevelCount()];
                    for (int i = 0; i < element.LowerLevelCount(); i++)
                        elementPriorities[i] = (element.IsDefined[i]) ? element.ElementValues[i].ToString() : "NA";
                    return elementPriorities;
                }
            }

            /// <summary>
            /// Код элемента, представляет собой номер уровня и номер элемента в уровне,
            /// записанные через дефис. Для удобства пользователя уровни нумеруюются,
            /// начиная с 1.
            /// </summary>
            public string ElementCode
            {
                get { return (element.Lv.LevelNumber + 1) + "-" + (element.Lv.Elements.LastIndexOf(element) + 1); }
            }
        }

        /// <summary>
        /// Представляет запись об альтернативе как результате решения
        /// задачи.
        /// </summary>
        public struct AlternativeSummary
        {
            /// <summary>
            /// Закрытое поле - название альтернативы.
            /// </summary>
            private string name;
            /// <summary>
            /// Закрытое поле - приоритет альтернативы.
            /// </summary>
            private double priority;

            /// <summary>
            /// Конструктор класса, параметры: название альтернативы и ее
            /// приоритет.
            /// </summary>
            /// <param name="name">Название альтернативы.</param>
            /// <param name="priority">Приоритет альтернативы.</param>
            public AlternativeSummary(string name, double priority)
            {
                this.name = name;
                this.priority = priority;
            }

            /// <summary>
            /// Название альтернативы (свойство только для чтения).
            /// </summary>
            public string AlternativeName
            {
                get { return name; }
            }

            /// <summary>
            /// Приоритет альтернативы (свойство только для чтения).
            /// </summary>
            public double AlternativePriority
            {
                get { return priority; }
            }
        }

        /// <summary>
        /// Представляет запись об элементе иерархии как альтернативе
        /// относительно количественного критерия.
        /// </summary>
        public struct ElementValueSummary
        {
            private string code;        // код элемента, относительно которого выносится оценка
            private string name;        // название оцениваемого элемента
            private string value;       // количественное значение, приписанное оцениваемому элементу

            /// <summary>
            /// Конструктор класса, параметры: код элемента,
            /// его название и количественное значение.
            /// </summary>
            /// <param name="code">Код элемента, относительно которого
            /// выносится суждение.</param>
            /// <param name="name">Название оцениваемого элемента.</param>
            /// <param name="value">Количественное значение, приписанное
            /// оцениваемому элементу.</param>
            /// <remarks>Если количественное значение отсутствует (не выставлено),
            /// то следует передавать в качестве параметра value строку "?".</remarks>
            public ElementValueSummary(string code, string name, string value)
            {
                this.code = code;
                this.name = name;
                this.value = value;
            }

            /// <summary>
            /// Код элемента, относительно которого выносится суждение.
            /// </summary>
            /// <remarks>Код элемента представляет собой номер уровня, в
            /// котором он содержится, и его номер в уровне, записанные
            /// через дефис. Уровни нумеруются, начиная с 0 (нулевой уровень
            /// - уровень цели), элементы - начиная с 1.</remarks>
            public string ElementValueCode
            {
                get { return code; }
            }

            /// <summary>
            /// Название оцениваемого элемента.
            /// </summary>
            public string ElementValueName
            {
                get { return name; }
            }

            /// <summary>
            /// Количественное значение, приписываемое оцениваемому элементу.
            /// </summary>
            public string ElementValuePriority
            {
                get { return value; }
            }
        }

        /// <summary>
        /// Представляет запись об элементе иерархии как альтернативе
        /// относительно сравнительного критерия.
        /// </summary>
        public struct PairComparisonSummary
        {
            private string code;        // код элемента, относительно которого выносится суждение
            private string left;        // левая часть (превосходящий в паре элемент)
            private string middle;      // суждение
            private string right;       // правая часть (уступающий в паре элемент)

            /// <summary>
            /// Конструктор класса, параметры: код элемента, названия сравниваемых альтернатив
            /// и суждения о паре альтернатив.
            /// </summary>
            /// <param name="code">Код элемента, относительно которого выносится суждение.</param>
            /// <param name="left">Элемент, превосходящий в паре. </param>
            /// <param name="middle">Суждение о паре элементов.</param>
            /// <param name="right">Элемент, уступающий в паре.</param>
            /// <remarks>Если суждение о паре элементов отсутствует, то следует передавать
            /// в качестве параметра middle строку "?".</remarks>
            public PairComparisonSummary(string code, string left, string middle, string right)
            {
                this.code = code;
                this.left = left;
                this.middle = middle;
                this.right = right;
            }

            /// <summary>
            /// Код элемента, относительно которого выносится суждение.
            /// </summary>
            public string PairComparisonCode
            {
                get { return code; }
            }

            /// <summary>
            /// Название элемента, который превосходит в паре.
            /// </summary>
            public string PairComparisonLeft
            {
                get { return left; }
            }

            /// <summary>
            /// Суждение о паре элементов.
            /// </summary>
            public string PairComparisonMiddle
            {
                get { return middle; }
            }

            /// <summary>
            /// Название элемента, который уступает в паре.
            /// </summary>
            public string PairComparisonRight
            {
                get { return right; }
            }
        }

        /// <summary>
        /// Представляет запись об элементе иерархии как альтернативе
        /// относительно элемента иерархии уровнем выше.
        /// </summary>
        public struct LocalAlternativeSummary
        {
            private string code;        // код элемента-критерия
            private string name;        // название элемента-альтернативы
            private double priority;    // приоритет элемента-альтернативы
            private int problemCode;    // код ошибки (см. комментарий к свойству)

            /// <summary>
            /// Конструктор, принимает параметры: код элемента-критерия, название
            /// элемента-альтернативы и ее приоритет.
            /// </summary>
            /// <param name="code">Код элемента-критерия.</param>
            /// <param name="name">Название элемента-альтернативы.</param>
            /// <param name="priority">Приоритет элемента-альтернативы.</param>
            /// <param name="problemCode">Код, описывающий состояние сравнений относительно данного элемента иерархии.</param>
            public LocalAlternativeSummary(string code, string name, double priority, int problemCode)
            {
                this.code = code;
                this.name = name;
                this.priority = priority;
                this.problemCode = problemCode;
            }

            /// <summary>
            /// Код элемента-иерархии.
            /// </summary>
            public string LocalAlternativeCode
            {
                get { return code; }
            }

            /// <summary>
            /// Название элемента-альтернативы.
            /// </summary>
            public string LocalAlternativeName
            {
                get { return name; }
            }

            /// <summary>
            /// Приоритет элемента-альтернативы.
            /// </summary>
            public double LocalAlternativePriority
            {
                get { return priority; }
            }

            /// <summary>
            /// Возвращает код, описывающий состояние сравнений относительно данного
            /// элемента иерархии. Это поле одинаково для всех записей
            /// об альтернативах относительно одного элемента иерархии.
            /// </summary>
            /// <remarks>Возможные значения:
            /// 0 - все в порядке,
            /// 1 - сравнительный критерий, есть отсутствующие оценки,
            /// 2 - количественный критерий, есть отсутствующие оценки (но не все),
            /// 3 - количественный критерий, оценки полностью отсутствуют.
            /// </remarks>
            public int LocalAlternativeProblemCode
            {
                get { return problemCode; }
            }
        }
    }
}
