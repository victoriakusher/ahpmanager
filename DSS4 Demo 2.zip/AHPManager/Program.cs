﻿using System;
using System.Windows.Forms;

namespace AHPManager
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {

            //.CurrentThread.CurrentCulture = CultureInfo.GetCultureInfo("ru-RU");
            //Thread.CurrentThread.CurrentUICulture = CultureInfo.GetCultureInfo("ru-RU");
            //Application.CurrentCulture = CultureInfo.GetCultureInfo("ru-RU");

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
