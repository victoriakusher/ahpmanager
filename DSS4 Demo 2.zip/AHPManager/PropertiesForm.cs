﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Document;

namespace AHPManager
{
    public partial class PropertiesForm : Form
    {
        /* Параметры: title - заголовок формы, documentObject - ссылка на
         * эземпляр класса - наследника HDO, свойства которого (название и
         * комментарии) редактируются в окне. */
        public PropertiesForm(string title, HDO documentObject)
        {
            InitializeComponent();

            tbName.Text = documentObject.Name;
            tbDescription.Text = documentObject.Description;

            Text = title;
        }

        /// <summary>
        /// Возвращает данные, введенные в поле "Название".
        /// </summary>
        public string GetName()
        {
            return tbName.Text;
        }

        /// <summary>
        /// Возвращает данные, введенные в поле "Комментарии".
        /// </summary>
        public string GetDescription()
        {
            return tbDescription.Text;
        }
    }
}
