﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Document;

namespace AHPManager
{
    public partial class ProjectStatisticsForm : Form
    {
        private Hierarchy projectHierarchy;     // ссылка на иерархическую структуру

        /// <summary>
        /// Структура для хранения собранной по проекту статистики.
        /// </summary>
        private struct ProjectStatistics
        {
            public int levelsCount;                 // количество уровней
            public int elementsCount;               // количество элементов иерархии
            public int alternativesCount;           // количество альтернатив

            public int comparativeCriteriaCount;    // количество сравнительных критериев
            public int quantitativeCriteriaCount;   // количество количественных критериев

            // статистика по сравнительным критериям
            public int compCritAppraisalsCompleteCount;     // количество критериев с полностью выполненными (поставленным) сравнениями (весами)
            public int compCritAnyAppraisalsCount;          // количество критериев с частично выполненными (поставленными) сравнениями (весами)
            public int compCritNoAppraisalsCount;           // количество критериев, у которых отсутствуют сравнения (веса)

            // статистика по количественным критериям
            public int quantCritAppraisalsCompleteCount;    // количество критериев с полностью выполненными (поставленным) сравнениями (весами)
            public int quantCritAnyAppraisalsCount;         // количество критериев с частично выполненными (поставленными) сравнениями (весами)
            public int quantCritNoAppraisalsCount;          // количество критериев, у которых отсутствуют сравнения (веса)
        }

        // ссылка на структуру для хранения статистики по проекту
        private ProjectStatistics stats;    

        /// <summary>
        /// Создает форму, отображающую статистику по проекту.
        /// </summary>
        /// <param name="hierarchy">Ссылка на иерархическую структуру.</param>
        public ProjectStatisticsForm(Hierarchy hierarchy)
        {
            InitializeComponent();

            projectHierarchy = hierarchy;
        }

        private void ProjectStatisticsForm_Load(object sender, EventArgs e)
        {
            stats = new ProjectStatistics();  
            stats = CollectStatistics(projectHierarchy);     // собираем статистику по проекту

            // приводим в порядок внешний вид формы
            ClientSize = new Size(tlpStatistics.Width + Padding.Right + Padding.Left,
                tlpStatistics.Height + Padding.Top + Padding.Bottom);

            // заполняем текстовые поля
            lbLevelsCount.Text = stats.levelsCount.ToString();
            lbElementsCount.Text = stats.elementsCount.ToString();
            lbAlternativesCount.Text = stats.alternativesCount.ToString();
            lbComparativeCriteriaCount.Text = stats.comparativeCriteriaCount.ToString();
            lbQuantitativeCriteriaCount.Text = stats.quantitativeCriteriaCount.ToString();

            cbCriteriaType.SelectedIndex = 0;
        }

        /* Обработчик события изменения выбранного элемента в cbCriteriaType. */
        void cbCriteriaType_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox cbox = sender as ComboBox;

            switch (cbox.SelectedIndex)
            {
                case 0:
                    // рассматриваем оба типа критериев
                    lbAppraisalsCompleteCount.Text =
                        (stats.compCritAppraisalsCompleteCount +
                        stats.quantCritAppraisalsCompleteCount).ToString();
                    lbAnyAppraisalsCount.Text =
                        (stats.compCritAnyAppraisalsCount +
                        stats.quantCritAnyAppraisalsCount).ToString();
                    lbNoAppraisalsCount.Text =
                        (stats.compCritNoAppraisalsCount +
                        stats.quantCritNoAppraisalsCount).ToString();
                    break;
                case 1:
                    // рассматриваем сравнительные критерии
                    lbAppraisalsCompleteCount.Text =
                        stats.compCritAppraisalsCompleteCount.ToString();
                    lbAnyAppraisalsCount.Text =
                        stats.compCritAnyAppraisalsCount.ToString();
                    lbNoAppraisalsCount.Text =
                        stats.compCritNoAppraisalsCount.ToString();
                    break;
                case 2:
                    // рассматриваем количественные критерии
                    lbAppraisalsCompleteCount.Text =
                        stats.quantCritAppraisalsCompleteCount.ToString();
                    lbAnyAppraisalsCount.Text =
                        stats.quantCritAnyAppraisalsCount.ToString();
                    lbNoAppraisalsCount.Text =
                        stats.quantCritNoAppraisalsCount.ToString();
                    break;
            }
        }

        private ProjectStatistics CollectStatistics(Hierarchy hierarchy)
        {
            ProjectStatistics statistics = new ProjectStatistics();

            // количество уровней
            statistics.levelsCount = hierarchy.LevelsCount; 
            // количество альтернатив
            statistics.alternativesCount = hierarchy.Levels[hierarchy.LevelsCount - 1].Count;
            /* Вычисляем количество элементов, количества сравнительных и количественных
             * критериев и количества критериев с полностью выставленными, частично 
             * выставленными и вообще не выставленными оценками (весами). */
            foreach (Level level in hierarchy.Levels)
            {
                statistics.elementsCount += level.Count;
                foreach (Element element in level.Elements)
                    if (element.CriterionType != Criterions.noncriterion)
                    {
                        switch (element.CriterionType)
                        {
                            case Criterions.comparative:
                                statistics.comparativeCriteriaCount++;
                                if (element.ComparisonsComplete)
                                    statistics.compCritAppraisalsCompleteCount++;
                                else if (element.AnyComparisons)
                                    statistics.compCritAnyAppraisalsCount++;
                                else
                                    statistics.compCritNoAppraisalsCount++;
                                break;
                            case Criterions.quantitative:
                                statistics.quantitativeCriteriaCount++;
                                if (element.ComparisonsComplete)
                                    statistics.quantCritAppraisalsCompleteCount++;
                                else if (element.AnyComparisons)
                                    statistics.quantCritAnyAppraisalsCount++;
                                else
                                    statistics.quantCritNoAppraisalsCount++;
                                break;
                        }
                    }
            }

            return statistics;
        }

        private void btClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
