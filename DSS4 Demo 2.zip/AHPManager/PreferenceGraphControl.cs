﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Document;

namespace AHPManager
{
    public class PreferenceGraphControl : Panel
    {
        /// <summary>
        /// Количество вершин в графе.
        /// </summary>
        private int n;
        /// <summary>
        /// Список выделенных вершин.
        /// </summary>
        private List<int> selectedVertices;
        /// <summary>
        /// Массив вершин - экземпляров класса Vertex.
        /// </summary>
        private Vertex[] vertices;
        /// <summary>
        /// Массив центров вершин.
        /// </summary>
        private Point[] verticesCenters;
        /// <summary>
        /// Цвет вершины в нормальном состоянии.
        /// </summary>
        private Color normalVertexColor;
        /// <summary>
        /// Цвет выделенной вершины.
        /// </summary>
        private Color highlightedVertexColor;
        /// <summary>
        /// Цвет дуги в нормальном состоянии.
        /// </summary>
        private Color normalEdgeColor;
        /// <summary>
        /// Цвет выделенной дуги.
        /// </summary>
        private Color highlightedEdgeColor;
        /// <summary>
        /// Элемент иерархии, для альтернатив которого строится граф.
        /// </summary>
        private Element element;
        /// <summary>
        /// Наконечник для отрисовки дуг.
        /// </summary>
        private CustomLineCap arrowCap;
        /// <summary>
        /// Последовательность вершин, дуги между которыми нужно подсветить.
        /// </summary>
        private int[] cycleVertices;

        /// <summary>
        /// Свойство для чтения и задания последовательности вершин, образующих
        /// цикл, который нужно подсветить.
        /// </summary>
        public int[] CycleVertices 
        {
            get { return cycleVertices; }
            set 
            { 
                cycleVertices = value;
                Invalidate();   // принудительная перерисовка
            }
        }

        /// <summary>
        /// Конструктор класса, принимает один аргумент: элемент, для
        /// альтернатив которого строится граф предпочтений.
        /// </summary>
        /// <param name="hierarchyElement">Элемент, для альтернатив
        /// которого строится граф предпочтений.</param>
        public PreferenceGraphControl(Element hierarchyElement)
            : base()
        {
            this.DoubleBuffered = true; // для улучшения перерисовки

            /* Инициализируем поля. */
            element = hierarchyElement;
            n = element.LowerLevelCount();
            selectedVertices = new List<int>();
            vertices = new Vertex[n];
            verticesCenters = new Point[n];
            normalVertexColor = Color.LightSteelBlue;
            highlightedVertexColor = Color.LightBlue;
            normalEdgeColor = Color.Gray;
            highlightedEdgeColor = Color.Black;

            // вводим свой наконечник для отрисовки дуг
            GraphicsPath path = new GraphicsPath();
            Point[] points = 
            {
                new Point(-1, -5),
                new Point(0, 0),
                new Point(1, -5)
            };
            path.AddPolygon(points);
            arrowCap = new CustomLineCap(null, path);
        }

        /// <summary>
        /// Создает и размещает вершины.
        /// </summary>
        /// <remarks>Этот метод следует вызывать после того,
        /// как экземпляр класса размещен на форме (в контейнере)
        /// и для него заданы размеры.</remarks>
        public void InitializeVertices()
        {
            // создаем и настраиваем вершины
            for (int i = 0; i < n; i++)
            {
                vertices[i] = new Vertex();
                vertices[i].Text = element.Lv.LowerLevel.Elements[i].Name;
                vertices[i].ForeColor = normalVertexColor;
                vertices[i].FlatAppearance.BorderColor = Color.Black;
                Controls.Add(vertices[i]);
            }

            // определим размеры для вершины
            Size vertexSize = new Size();
            vertexSize.Width = element.Lv.LowerLevel.Elements.Select(
                e => TextRenderer.MeasureText(e.Name, SystemFonts.DefaultFont).Width).Max();
            vertexSize.Height = element.Lv.LowerLevel.Elements.Select(
                e => TextRenderer.MeasureText(e.Name, SystemFonts.DefaultFont).Height).Max();
            vertexSize.Width = (int)(vertexSize.Width * 1.2);
            vertexSize.Height *= 3;
            // если вдруг оказалось, что кнопка вытянута в длину, то это нужно исправить
            if (vertexSize.Height > vertexSize.Width)
                vertexSize.Width = vertexSize.Height;

            double alpha = 2 * Math.PI / n;
            double beta = 0.5;
            double r = Math.Min((ClientSize.Width - 2 * beta * vertexSize.Width) / 2,
                (ClientSize.Height - 2 * beta * vertexSize.Height) / 2);

            // вычисляем расположения вершин
            for (int i = 0; i < n; i++)
            {
                verticesCenters[i] = new Point((int)(ClientSize.Width / 2 - r * Math.Sin(i * alpha)),
                    (int)(ClientSize.Height / 2 - r * Math.Cos(i * alpha) + (r / 2 * (1 - Math.Cos(alpha / 2))) * (n % 2)));
                vertices[i].Size = vertexSize;
                vertices[i].Location = new Point(verticesCenters[i].X - vertexSize.Width / 2,
                    verticesCenters[i].Y - vertexSize.Height / 2);
                vertices[i].Click += new EventHandler(vertex_Click);
                vertices[i].Tag = i;
            }
        }

        void vertex_Click(object sender, EventArgs e)
        {
            Vertex vertex = sender as Vertex;

            switch (selectedVertices.Count)
            {
                case 0:
                    // ни одна вершина не была выделена, выделяем вершину,
                    // на которую нажали, и подсвечиваем смежные ей дуги
                    vertices[(int) vertex.Tag].ForeColor = highlightedVertexColor;
                    selectedVertices.Add((int) vertex.Tag);
                    DrawEdges(CreateGraphics(), selectedVertices);
                    break;
                case 1:
                    // проверяем: если нажали на уже выделенную вершину, то
                    // снимаем выделение, если нет, то выделяем ее
                    // и дугу между выделенными вершинами + вызываем событие
                    // ComparisonSelected (была выбрана пара вершин)
                    if (selectedVertices.Contains((int)vertex.Tag))
                    {
                        vertices[(int)vertex.Tag].ForeColor = normalVertexColor;
                        selectedVertices.Remove((int)vertex.Tag);
                        DrawEdges(CreateGraphics(), selectedVertices);
                    }
                    else
                    {
                        vertices[(int)vertex.Tag].ForeColor = highlightedVertexColor;
                        selectedVertices.Add((int)vertex.Tag);
                        DrawEdges(CreateGraphics(), selectedVertices);
                        ComparisonSelected(this, new ComparisonSelectedEventArgs(selectedVertices[0],
                            selectedVertices[1]));
                    }
                    break;
                case 2:
                    // проверяем: если мы нажали на выделенную вершину,
                    // то снимаем с нее выделение и оставляем одну выделенную
                    // вершину с подсвеченными смежными дугами, если нет,
                    // то снимаем выделение с обеих вершин и выделяем вершину,
                    // на которую щелкнули + подсвечиваем смежные ей ребра
                    if (selectedVertices.Contains((int)vertex.Tag))
                    {
                        vertices[(int)vertex.Tag].ForeColor = normalVertexColor;
                        selectedVertices.Remove((int)vertex.Tag);
                        DrawEdges(CreateGraphics(), selectedVertices);
                    }
                    else
                    {
                        foreach (int i in selectedVertices)
                            vertices[i].ForeColor = normalVertexColor;
                        selectedVertices.Clear();
                        selectedVertices.Add((int)vertex.Tag);
                        vertices[(int)vertex.Tag].ForeColor = highlightedVertexColor;
                        DrawEdges(CreateGraphics(), selectedVertices);
                    }
                    break;
            }
        }

        protected override void  OnPaint(PaintEventArgs e)
        {
 	        base.OnPaint(e);

            DrawEdges(e.Graphics, null);
        }

        /// <summary>
        /// Рисует дуги (ребра) на графе представлений.
        /// </summary>
        private void DrawEdges(Graphics gr, List<int> hightlightVertices)
        {
            gr.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            // стираем ранее нарисованные ребра, проводя толстые линии цвета формы
            for (int i = 0; i < n; i++)
                for (int j = i + 1; j < n; j++)
                    gr.DrawLine(new Pen(FindForm().BackColor, 9),
                        verticesCenters[i], verticesCenters[j]);

            // выделяем циклы (если они есть)
            if (cycleVertices != null)
            {
                for (int i = 0; i < cycleVertices.Length; i++)
                    for (int j = i + 1; j < cycleVertices.Length; j++)
                        gr.DrawLine(new Pen(Color.Orange, 7),
                            verticesCenters[cycleVertices[i]], verticesCenters[cycleVertices[j]]);
            }

            // отрисовываем ребра
            for (int i = 0; i < n; i++)
                for (int j = i + 1; j < n; j++)
                    DrawEdge(gr, normalEdgeColor, i, j);
            switch (selectedVertices.Count)
            {
                case 1:
                    // выделена одна вершина, подсвечиваем смежные ей ребра
                    for (int j = 0; j < n; j++)
                        DrawEdge(gr, highlightedEdgeColor, selectedVertices[0], j);
                    break;
                case 2:
                    // выделено две вершины, подсвечиваем дугу между ними
                    DrawEdge(gr, highlightedEdgeColor, selectedVertices[0], selectedVertices[1]);
                    break;
            }
        } 

        /// <summary>
        /// Рисует дугу (ребро) между вершинами с индексами i и j заданного цвета.
        /// </summary>
        /// <param name="gr">Экземпляр класса Graphics для рисования.</param>
        /// <param name="color">Цвет, которым рисуется дуга (ребро).</param>
        /// <param name="i">Индекс первой вершины.</param>
        /// <param name="j">Индекс второй вершины.</param>
        private void DrawEdge(Graphics gr, Color color, int i, int j)
        {
            gr.SmoothingMode = SmoothingMode.AntiAlias;

            Point middlePoint;
            Pen regularPen = new Pen(color); regularPen.Width = 2;
            Pen dashedPen;

            if (element.PairComparisons[i, j] != Appraisals.undefined)
                switch (Math.Sign(element.PairComparisons[i, j]))
                {
                    case 0:
                        regularPen.EndCap = System.Drawing.Drawing2D.LineCap.Flat;
                        gr.DrawLine(regularPen, verticesCenters[i], verticesCenters[j]);
                        break;
                    case -1:
                        middlePoint = new Point(
                            (verticesCenters[i].X + verticesCenters[j].X) / 2,
                            (verticesCenters[i].Y + verticesCenters[j].Y) / 2);
                        regularPen.CustomEndCap = arrowCap;
                        gr.DrawLine(regularPen, verticesCenters[j], middlePoint);
                        regularPen.EndCap = System.Drawing.Drawing2D.LineCap.Flat;
                        gr.DrawLine(regularPen, middlePoint, verticesCenters[i]);
                        break;
                    case 1:
                        middlePoint = new Point(
                            (verticesCenters[i].X + verticesCenters[j].X) / 2,
                            (verticesCenters[i].Y + verticesCenters[j].Y) / 2);
                        regularPen.CustomEndCap = arrowCap;
                        gr.DrawLine(regularPen, verticesCenters[i], middlePoint);
                        regularPen.EndCap = System.Drawing.Drawing2D.LineCap.Flat;
                        gr.DrawLine(regularPen, middlePoint, verticesCenters[j]);
                        break;
                }
            else
            {
                dashedPen = new Pen(color); dashedPen.Width = 2;
                dashedPen.DashStyle = DashStyle.Dash;
                gr.DrawLine(dashedPen, verticesCenters[i], verticesCenters[j]);
            }
        }

        /// <summary>
        /// Выделяет сравнение между альтернативами с указанными индексами на графе
        /// предпочтений.
        /// </summary>
        /// <param name="i">Индекс первой альтернативы.</param>
        /// <param name="j">Индекс второй альтернативы.</param>
        public void HighlightComparison(int i, int j)
        {
            foreach (int k in selectedVertices)
                vertices[k].ForeColor = normalVertexColor;
            selectedVertices.Clear();
            selectedVertices.Add(i); selectedVertices.Add(j);
            vertices[i].ForeColor = vertices[j].ForeColor = highlightedVertexColor;
            DrawEdges(CreateGraphics(), null);
            DrawEdge(CreateGraphics(), highlightedEdgeColor, i, j);
        }

        public event ComparisonSelectedDelegate ComparisonSelected;
    }

    public class ComparisonSelectedEventArgs : EventArgs
    {
        /// <summary>
        /// Индексы сравниваемых альтернатив.
        /// </summary>
        private int[] alternativeIndices;

        /// <summary>
        /// Свойство только для чтения: индексы сравниваемых альтернатив.
        /// </summary>
        public int[] AlternativeIndices
        {
            get { return alternativeIndices; }
        }

        /// <summary>
        /// Конструктор класса, принимает индексы альтернатив, участвующих 
        /// в сравнении.
        /// </summary>
        /// <param name="firstIndex">Индекс первой альтернативы.</param>
        /// <param name="secondIndex">Индекс второй альтернативы.</param>
        /// <remarks>Порядок перечисления индексов альтернатив не играет 
        /// роли.</remarks>
        public ComparisonSelectedEventArgs(int firstIndex, int secondIndex)
        {
            alternativeIndices = new int[2];
            alternativeIndices[0] = firstIndex;
            alternativeIndices[1] = secondIndex;
        }
    }

    public delegate void ComparisonSelectedDelegate(object sender, ComparisonSelectedEventArgs e);

    class Vertex : Button
    {
        protected override void OnPaint(PaintEventArgs pevent)
        {
            this.OnPaintBackground(pevent);

            // рисуем кнопку
            Graphics gr = pevent.Graphics;
            gr.SmoothingMode = SmoothingMode.AntiAlias;

            int ellipseWidth = pevent.ClipRectangle.Width - 3;
            int ellipseHeight = pevent.ClipRectangle.Height - 3;

            gr.FillEllipse(new SolidBrush(ForeColor),
                1, 1, ellipseWidth, ellipseHeight);
            gr.DrawEllipse(new Pen(FlatAppearance.BorderColor, FlatAppearance.BorderSize),
                1, 1, ellipseWidth, ellipseHeight);

            // размещаем на ней текст
            Size textSize = TextRenderer.MeasureText(Text, Font);
            TextRenderer.DrawText(gr, Text, Font,
                new Point((ellipseWidth - textSize.Width) / 2 + 1, (ellipseHeight - textSize.Height) / 2 + 1),
                SystemColors.ControlText);

            // делаем клиентскую область эллипсом
            GraphicsPath grPath = new GraphicsPath();
            grPath.AddEllipse(-1, -1, Width + 1, Height + 1); // не знаю почему, но именно с такими координатами клиентской области кнопки отображаются нормально
            this.Region = new Region(grPath);
        }
    }
}
