﻿namespace AHPManager
{
    partial class ProjectStatisticsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tlpStatistics = new System.Windows.Forms.TableLayoutPanel();
            this.grpHierarchy = new System.Windows.Forms.GroupBox();
            this.tlpHierarchy = new System.Windows.Forms.TableLayoutPanel();
            this.lbLevels = new System.Windows.Forms.Label();
            this.lbElements = new System.Windows.Forms.Label();
            this.lbAlternatives = new System.Windows.Forms.Label();
            this.lbLevelsCount = new System.Windows.Forms.Label();
            this.lbElementsCount = new System.Windows.Forms.Label();
            this.lbAlternativesCount = new System.Windows.Forms.Label();
            this.grbCriteria = new System.Windows.Forms.GroupBox();
            this.tlpCriteria = new System.Windows.Forms.TableLayoutPanel();
            this.lbComparativeCriteria = new System.Windows.Forms.Label();
            this.lbQuantitativeCriteria = new System.Windows.Forms.Label();
            this.lbComparativeCriteriaCount = new System.Windows.Forms.Label();
            this.lbQuantitativeCriteriaCount = new System.Windows.Forms.Label();
            this.grbAppraisals = new System.Windows.Forms.GroupBox();
            this.tlpAppraisals = new System.Windows.Forms.TableLayoutPanel();
            this.lbCriteriaType = new System.Windows.Forms.Label();
            this.lbAppraisalsComplete = new System.Windows.Forms.Label();
            this.lbAnyAppraisals = new System.Windows.Forms.Label();
            this.lbNoAppraisals = new System.Windows.Forms.Label();
            this.cbCriteriaType = new System.Windows.Forms.ComboBox();
            this.lbAppraisalsCompleteCount = new System.Windows.Forms.Label();
            this.lbAnyAppraisalsCount = new System.Windows.Forms.Label();
            this.lbNoAppraisalsCount = new System.Windows.Forms.Label();
            this.btClose = new System.Windows.Forms.Button();
            this.buttonsLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.btOK = new System.Windows.Forms.Button();
            this.btCancel = new System.Windows.Forms.Button();
            this.tlpStatistics.SuspendLayout();
            this.grpHierarchy.SuspendLayout();
            this.tlpHierarchy.SuspendLayout();
            this.grbCriteria.SuspendLayout();
            this.tlpCriteria.SuspendLayout();
            this.grbAppraisals.SuspendLayout();
            this.tlpAppraisals.SuspendLayout();
            this.buttonsLayoutPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // tlpStatistics
            // 
            this.tlpStatistics.AutoSize = true;
            this.tlpStatistics.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tlpStatistics.ColumnCount = 1;
            this.tlpStatistics.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpStatistics.Controls.Add(this.grpHierarchy, 0, 0);
            this.tlpStatistics.Controls.Add(this.grbCriteria, 0, 1);
            this.tlpStatistics.Controls.Add(this.grbAppraisals, 0, 2);
            this.tlpStatistics.Controls.Add(this.btClose, 0, 3);
            this.tlpStatistics.Location = new System.Drawing.Point(0, 0);
            this.tlpStatistics.Margin = new System.Windows.Forms.Padding(2);
            this.tlpStatistics.Name = "tlpStatistics";
            this.tlpStatistics.Padding = new System.Windows.Forms.Padding(3);
            this.tlpStatistics.RowCount = 4;
            this.tlpStatistics.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tlpStatistics.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tlpStatistics.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tlpStatistics.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tlpStatistics.Size = new System.Drawing.Size(315, 271);
            this.tlpStatistics.TabIndex = 0;
            // 
            // grpHierarchy
            // 
            this.grpHierarchy.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.grpHierarchy.AutoSize = true;
            this.grpHierarchy.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.grpHierarchy.Controls.Add(this.tlpHierarchy);
            this.grpHierarchy.Location = new System.Drawing.Point(5, 5);
            this.grpHierarchy.Margin = new System.Windows.Forms.Padding(2);
            this.grpHierarchy.Name = "grpHierarchy";
            this.grpHierarchy.Padding = new System.Windows.Forms.Padding(2);
            this.grpHierarchy.Size = new System.Drawing.Size(305, 72);
            this.grpHierarchy.TabIndex = 1;
            this.grpHierarchy.TabStop = false;
            this.grpHierarchy.Text = "Иерархия";
            // 
            // tlpHierarchy
            // 
            this.tlpHierarchy.AutoSize = true;
            this.tlpHierarchy.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tlpHierarchy.ColumnCount = 2;
            this.tlpHierarchy.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tlpHierarchy.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tlpHierarchy.Controls.Add(this.lbLevels, 0, 0);
            this.tlpHierarchy.Controls.Add(this.lbElements, 0, 1);
            this.tlpHierarchy.Controls.Add(this.lbAlternatives, 0, 2);
            this.tlpHierarchy.Controls.Add(this.lbLevelsCount, 1, 0);
            this.tlpHierarchy.Controls.Add(this.lbElementsCount, 1, 1);
            this.tlpHierarchy.Controls.Add(this.lbAlternativesCount, 1, 2);
            this.tlpHierarchy.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpHierarchy.Location = new System.Drawing.Point(2, 15);
            this.tlpHierarchy.Margin = new System.Windows.Forms.Padding(2);
            this.tlpHierarchy.Name = "tlpHierarchy";
            this.tlpHierarchy.Padding = new System.Windows.Forms.Padding(2);
            this.tlpHierarchy.RowCount = 3;
            this.tlpHierarchy.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tlpHierarchy.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tlpHierarchy.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tlpHierarchy.Size = new System.Drawing.Size(301, 55);
            this.tlpHierarchy.TabIndex = 0;
            // 
            // lbLevels
            // 
            this.lbLevels.AutoSize = true;
            this.lbLevels.Location = new System.Drawing.Point(4, 4);
            this.lbLevels.Margin = new System.Windows.Forms.Padding(2);
            this.lbLevels.Name = "lbLevels";
            this.lbLevels.Size = new System.Drawing.Size(163, 13);
            this.lbLevels.TabIndex = 0;
            this.lbLevels.Text = "Количество уровней иерархии:";
            // 
            // lbElements
            // 
            this.lbElements.AutoSize = true;
            this.lbElements.Location = new System.Drawing.Point(4, 21);
            this.lbElements.Margin = new System.Windows.Forms.Padding(2);
            this.lbElements.Name = "lbElements";
            this.lbElements.Size = new System.Drawing.Size(177, 13);
            this.lbElements.TabIndex = 1;
            this.lbElements.Text = "Количество элементов иерархии:";
            // 
            // lbAlternatives
            // 
            this.lbAlternatives.AutoSize = true;
            this.lbAlternatives.Location = new System.Drawing.Point(4, 38);
            this.lbAlternatives.Margin = new System.Windows.Forms.Padding(2);
            this.lbAlternatives.Name = "lbAlternatives";
            this.lbAlternatives.Size = new System.Drawing.Size(136, 13);
            this.lbAlternatives.TabIndex = 2;
            this.lbAlternatives.Text = "Количество альтернатив:";
            // 
            // lbLevelsCount
            // 
            this.lbLevelsCount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbLevelsCount.AutoSize = true;
            this.lbLevelsCount.Location = new System.Drawing.Point(284, 4);
            this.lbLevelsCount.Margin = new System.Windows.Forms.Padding(2);
            this.lbLevelsCount.Name = "lbLevelsCount";
            this.lbLevelsCount.Size = new System.Drawing.Size(13, 13);
            this.lbLevelsCount.TabIndex = 3;
            this.lbLevelsCount.Text = "3";
            // 
            // lbElementsCount
            // 
            this.lbElementsCount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbElementsCount.AutoSize = true;
            this.lbElementsCount.Location = new System.Drawing.Point(284, 21);
            this.lbElementsCount.Margin = new System.Windows.Forms.Padding(2);
            this.lbElementsCount.Name = "lbElementsCount";
            this.lbElementsCount.Size = new System.Drawing.Size(13, 13);
            this.lbElementsCount.TabIndex = 4;
            this.lbElementsCount.Text = "7";
            // 
            // lbAlternativesCount
            // 
            this.lbAlternativesCount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbAlternativesCount.AutoSize = true;
            this.lbAlternativesCount.Location = new System.Drawing.Point(284, 38);
            this.lbAlternativesCount.Margin = new System.Windows.Forms.Padding(2);
            this.lbAlternativesCount.Name = "lbAlternativesCount";
            this.lbAlternativesCount.Size = new System.Drawing.Size(13, 13);
            this.lbAlternativesCount.TabIndex = 5;
            this.lbAlternativesCount.Text = "3";
            // 
            // grbCriteria
            // 
            this.grbCriteria.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.grbCriteria.AutoSize = true;
            this.grbCriteria.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.grbCriteria.Controls.Add(this.tlpCriteria);
            this.grbCriteria.Location = new System.Drawing.Point(5, 81);
            this.grbCriteria.Margin = new System.Windows.Forms.Padding(2);
            this.grbCriteria.Name = "grbCriteria";
            this.grbCriteria.Padding = new System.Windows.Forms.Padding(2);
            this.grbCriteria.Size = new System.Drawing.Size(305, 55);
            this.grbCriteria.TabIndex = 2;
            this.grbCriteria.TabStop = false;
            this.grbCriteria.Text = "Критерии";
            // 
            // tlpCriteria
            // 
            this.tlpCriteria.AutoSize = true;
            this.tlpCriteria.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tlpCriteria.ColumnCount = 2;
            this.tlpCriteria.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tlpCriteria.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tlpCriteria.Controls.Add(this.lbComparativeCriteria, 0, 0);
            this.tlpCriteria.Controls.Add(this.lbQuantitativeCriteria, 0, 1);
            this.tlpCriteria.Controls.Add(this.lbComparativeCriteriaCount, 1, 0);
            this.tlpCriteria.Controls.Add(this.lbQuantitativeCriteriaCount, 1, 1);
            this.tlpCriteria.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpCriteria.Location = new System.Drawing.Point(2, 15);
            this.tlpCriteria.Margin = new System.Windows.Forms.Padding(2);
            this.tlpCriteria.Name = "tlpCriteria";
            this.tlpCriteria.Padding = new System.Windows.Forms.Padding(2);
            this.tlpCriteria.RowCount = 2;
            this.tlpCriteria.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tlpCriteria.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tlpCriteria.Size = new System.Drawing.Size(301, 38);
            this.tlpCriteria.TabIndex = 0;
            // 
            // lbComparativeCriteria
            // 
            this.lbComparativeCriteria.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lbComparativeCriteria.AutoSize = true;
            this.lbComparativeCriteria.Location = new System.Drawing.Point(4, 4);
            this.lbComparativeCriteria.Margin = new System.Windows.Forms.Padding(2);
            this.lbComparativeCriteria.Name = "lbComparativeCriteria";
            this.lbComparativeCriteria.Size = new System.Drawing.Size(150, 13);
            this.lbComparativeCriteria.TabIndex = 0;
            this.lbComparativeCriteria.Text = "Сравнительных критериев:";
            // 
            // lbQuantitativeCriteria
            // 
            this.lbQuantitativeCriteria.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lbQuantitativeCriteria.AutoSize = true;
            this.lbQuantitativeCriteria.Location = new System.Drawing.Point(4, 21);
            this.lbQuantitativeCriteria.Margin = new System.Windows.Forms.Padding(2);
            this.lbQuantitativeCriteria.Name = "lbQuantitativeCriteria";
            this.lbQuantitativeCriteria.Size = new System.Drawing.Size(150, 13);
            this.lbQuantitativeCriteria.TabIndex = 1;
            this.lbQuantitativeCriteria.Text = "Количественных критериев:";
            // 
            // lbComparativeCriteriaCount
            // 
            this.lbComparativeCriteriaCount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbComparativeCriteriaCount.AutoSize = true;
            this.lbComparativeCriteriaCount.Location = new System.Drawing.Point(284, 4);
            this.lbComparativeCriteriaCount.Margin = new System.Windows.Forms.Padding(2);
            this.lbComparativeCriteriaCount.Name = "lbComparativeCriteriaCount";
            this.lbComparativeCriteriaCount.Size = new System.Drawing.Size(13, 13);
            this.lbComparativeCriteriaCount.TabIndex = 2;
            this.lbComparativeCriteriaCount.Text = "4";
            // 
            // lbQuantitativeCriteriaCount
            // 
            this.lbQuantitativeCriteriaCount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbQuantitativeCriteriaCount.AutoSize = true;
            this.lbQuantitativeCriteriaCount.Location = new System.Drawing.Point(284, 21);
            this.lbQuantitativeCriteriaCount.Margin = new System.Windows.Forms.Padding(2);
            this.lbQuantitativeCriteriaCount.Name = "lbQuantitativeCriteriaCount";
            this.lbQuantitativeCriteriaCount.Size = new System.Drawing.Size(13, 13);
            this.lbQuantitativeCriteriaCount.TabIndex = 3;
            this.lbQuantitativeCriteriaCount.Text = "0";
            // 
            // grbAppraisals
            // 
            this.grbAppraisals.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.grbAppraisals.AutoSize = true;
            this.grbAppraisals.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.grbAppraisals.Controls.Add(this.tlpAppraisals);
            this.grbAppraisals.Location = new System.Drawing.Point(5, 140);
            this.grbAppraisals.Margin = new System.Windows.Forms.Padding(2);
            this.grbAppraisals.Name = "grbAppraisals";
            this.grbAppraisals.Padding = new System.Windows.Forms.Padding(2);
            this.grbAppraisals.Size = new System.Drawing.Size(305, 97);
            this.grbAppraisals.TabIndex = 3;
            this.grbAppraisals.TabStop = false;
            this.grbAppraisals.Text = "Оценки";
            // 
            // tlpAppraisals
            // 
            this.tlpAppraisals.AutoSize = true;
            this.tlpAppraisals.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tlpAppraisals.ColumnCount = 2;
            this.tlpAppraisals.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tlpAppraisals.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpAppraisals.Controls.Add(this.lbCriteriaType, 0, 0);
            this.tlpAppraisals.Controls.Add(this.lbAppraisalsComplete, 0, 1);
            this.tlpAppraisals.Controls.Add(this.lbAnyAppraisals, 0, 2);
            this.tlpAppraisals.Controls.Add(this.lbNoAppraisals, 0, 3);
            this.tlpAppraisals.Controls.Add(this.cbCriteriaType, 1, 0);
            this.tlpAppraisals.Controls.Add(this.lbAppraisalsCompleteCount, 1, 1);
            this.tlpAppraisals.Controls.Add(this.lbAnyAppraisalsCount, 1, 2);
            this.tlpAppraisals.Controls.Add(this.lbNoAppraisalsCount, 1, 3);
            this.tlpAppraisals.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpAppraisals.Location = new System.Drawing.Point(2, 15);
            this.tlpAppraisals.Margin = new System.Windows.Forms.Padding(2);
            this.tlpAppraisals.Name = "tlpAppraisals";
            this.tlpAppraisals.Padding = new System.Windows.Forms.Padding(2);
            this.tlpAppraisals.RowCount = 4;
            this.tlpAppraisals.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tlpAppraisals.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tlpAppraisals.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tlpAppraisals.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tlpAppraisals.Size = new System.Drawing.Size(301, 80);
            this.tlpAppraisals.TabIndex = 0;
            // 
            // lbCriteriaType
            // 
            this.lbCriteriaType.AutoSize = true;
            this.lbCriteriaType.Location = new System.Drawing.Point(4, 2);
            this.lbCriteriaType.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbCriteriaType.Name = "lbCriteriaType";
            this.lbCriteriaType.Size = new System.Drawing.Size(85, 13);
            this.lbCriteriaType.TabIndex = 0;
            this.lbCriteriaType.Text = "Тип критериев:";
            // 
            // lbAppraisalsComplete
            // 
            this.lbAppraisalsComplete.AutoSize = true;
            this.lbAppraisalsComplete.Location = new System.Drawing.Point(4, 29);
            this.lbAppraisalsComplete.Margin = new System.Windows.Forms.Padding(2);
            this.lbAppraisalsComplete.Name = "lbAppraisalsComplete";
            this.lbAppraisalsComplete.Size = new System.Drawing.Size(131, 13);
            this.lbAppraisalsComplete.TabIndex = 1;
            this.lbAppraisalsComplete.Text = "полностью выставлены:";
            // 
            // lbAnyAppraisals
            // 
            this.lbAnyAppraisals.AutoSize = true;
            this.lbAnyAppraisals.Location = new System.Drawing.Point(4, 46);
            this.lbAnyAppraisals.Margin = new System.Windows.Forms.Padding(2);
            this.lbAnyAppraisals.Name = "lbAnyAppraisals";
            this.lbAnyAppraisals.Size = new System.Drawing.Size(121, 13);
            this.lbAnyAppraisals.TabIndex = 2;
            this.lbAnyAppraisals.Text = "частично выставлены:";
            // 
            // lbNoAppraisals
            // 
            this.lbNoAppraisals.AutoSize = true;
            this.lbNoAppraisals.Location = new System.Drawing.Point(4, 63);
            this.lbNoAppraisals.Margin = new System.Windows.Forms.Padding(2);
            this.lbNoAppraisals.Name = "lbNoAppraisals";
            this.lbNoAppraisals.Size = new System.Drawing.Size(88, 13);
            this.lbNoAppraisals.TabIndex = 3;
            this.lbNoAppraisals.Text = "не выставлены:";
            // 
            // cbCriteriaType
            // 
            this.cbCriteriaType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cbCriteriaType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbCriteriaType.FormattingEnabled = true;
            this.cbCriteriaType.Items.AddRange(new object[] {
            "оба типа",
            "сравнительные",
            "количественные"});
            this.cbCriteriaType.Location = new System.Drawing.Point(139, 4);
            this.cbCriteriaType.Margin = new System.Windows.Forms.Padding(2);
            this.cbCriteriaType.Name = "cbCriteriaType";
            this.cbCriteriaType.Size = new System.Drawing.Size(158, 21);
            this.cbCriteriaType.TabIndex = 4;
            this.cbCriteriaType.SelectedIndexChanged += new System.EventHandler(this.cbCriteriaType_SelectedIndexChanged);
            // 
            // lbAppraisalsCompleteCount
            // 
            this.lbAppraisalsCompleteCount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbAppraisalsCompleteCount.AutoSize = true;
            this.lbAppraisalsCompleteCount.Location = new System.Drawing.Point(284, 29);
            this.lbAppraisalsCompleteCount.Margin = new System.Windows.Forms.Padding(2);
            this.lbAppraisalsCompleteCount.Name = "lbAppraisalsCompleteCount";
            this.lbAppraisalsCompleteCount.Size = new System.Drawing.Size(13, 13);
            this.lbAppraisalsCompleteCount.TabIndex = 5;
            this.lbAppraisalsCompleteCount.Text = "0";
            // 
            // lbAnyAppraisalsCount
            // 
            this.lbAnyAppraisalsCount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbAnyAppraisalsCount.AutoSize = true;
            this.lbAnyAppraisalsCount.Location = new System.Drawing.Point(284, 46);
            this.lbAnyAppraisalsCount.Margin = new System.Windows.Forms.Padding(2);
            this.lbAnyAppraisalsCount.Name = "lbAnyAppraisalsCount";
            this.lbAnyAppraisalsCount.Size = new System.Drawing.Size(13, 13);
            this.lbAnyAppraisalsCount.TabIndex = 6;
            this.lbAnyAppraisalsCount.Text = "0";
            // 
            // lbNoAppraisalsCount
            // 
            this.lbNoAppraisalsCount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbNoAppraisalsCount.AutoSize = true;
            this.lbNoAppraisalsCount.Location = new System.Drawing.Point(284, 63);
            this.lbNoAppraisalsCount.Margin = new System.Windows.Forms.Padding(2);
            this.lbNoAppraisalsCount.Name = "lbNoAppraisalsCount";
            this.lbNoAppraisalsCount.Size = new System.Drawing.Size(13, 13);
            this.lbNoAppraisalsCount.TabIndex = 7;
            this.lbNoAppraisalsCount.Text = "4";
            // 
            // btClose
            // 
            this.btClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btClose.Location = new System.Drawing.Point(254, 241);
            this.btClose.Margin = new System.Windows.Forms.Padding(2);
            this.btClose.Name = "btClose";
            this.btClose.Size = new System.Drawing.Size(56, 25);
            this.btClose.TabIndex = 4;
            this.btClose.Text = "OK";
            this.btClose.UseVisualStyleBackColor = true;
            this.btClose.Click += new System.EventHandler(this.btClose_Click);
            // 
            // buttonsLayoutPanel
            // 
            this.buttonsLayoutPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonsLayoutPanel.AutoSize = true;
            this.buttonsLayoutPanel.ColumnCount = 2;
            this.buttonsLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.buttonsLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.buttonsLayoutPanel.Controls.Add(this.btOK, 0, 0);
            this.buttonsLayoutPanel.Location = new System.Drawing.Point(0, 0);
            this.buttonsLayoutPanel.Name = "buttonsLayoutPanel";
            this.buttonsLayoutPanel.RowCount = 1;
            this.buttonsLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.buttonsLayoutPanel.Size = new System.Drawing.Size(200, 100);
            this.buttonsLayoutPanel.TabIndex = 0;
            // 
            // btOK
            // 
            this.btOK.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.btOK.AutoSize = true;
            this.btOK.Location = new System.Drawing.Point(3, 3);
            this.btOK.Name = "btOK";
            this.btOK.Size = new System.Drawing.Size(94, 27);
            this.btOK.TabIndex = 0;
            this.btOK.Text = "OK";
            this.btOK.UseVisualStyleBackColor = true;
            // 
            // btCancel
            // 
            this.btCancel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.btCancel.AutoSize = true;
            this.btCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btCancel.Location = new System.Drawing.Point(78, 3);
            this.btCancel.Name = "btCancel";
            this.btCancel.Size = new System.Drawing.Size(69, 27);
            this.btCancel.TabIndex = 1;
            this.btCancel.Text = "Отмена";
            this.btCancel.UseVisualStyleBackColor = true;
            // 
            // ProjectStatisticsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(315, 293);
            this.Controls.Add(this.tlpStatistics);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(242, 199);
            this.Name = "ProjectStatisticsForm";
            this.Padding = new System.Windows.Forms.Padding(3);
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Статистика проекта";
            this.Load += new System.EventHandler(this.ProjectStatisticsForm_Load);
            this.tlpStatistics.ResumeLayout(false);
            this.tlpStatistics.PerformLayout();
            this.grpHierarchy.ResumeLayout(false);
            this.grpHierarchy.PerformLayout();
            this.tlpHierarchy.ResumeLayout(false);
            this.tlpHierarchy.PerformLayout();
            this.grbCriteria.ResumeLayout(false);
            this.grbCriteria.PerformLayout();
            this.tlpCriteria.ResumeLayout(false);
            this.tlpCriteria.PerformLayout();
            this.grbAppraisals.ResumeLayout(false);
            this.grbAppraisals.PerformLayout();
            this.tlpAppraisals.ResumeLayout(false);
            this.tlpAppraisals.PerformLayout();
            this.buttonsLayoutPanel.ResumeLayout(false);
            this.buttonsLayoutPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tlpStatistics;
        private System.Windows.Forms.GroupBox grpHierarchy;
        private System.Windows.Forms.GroupBox grbCriteria;
        private System.Windows.Forms.TableLayoutPanel tlpHierarchy;
        private System.Windows.Forms.GroupBox grbAppraisals;
        private System.Windows.Forms.Label lbLevels;
        private System.Windows.Forms.Label lbElements;
        private System.Windows.Forms.Label lbAlternatives;
        private System.Windows.Forms.Label lbLevelsCount;
        private System.Windows.Forms.Label lbElementsCount;
        private System.Windows.Forms.Label lbAlternativesCount;
        private System.Windows.Forms.TableLayoutPanel tlpCriteria;
        private System.Windows.Forms.Label lbComparativeCriteria;
        private System.Windows.Forms.Label lbQuantitativeCriteria;
        private System.Windows.Forms.Label lbComparativeCriteriaCount;
        private System.Windows.Forms.Label lbQuantitativeCriteriaCount;
        private System.Windows.Forms.TableLayoutPanel tlpAppraisals;
        private System.Windows.Forms.Label lbCriteriaType;
        private System.Windows.Forms.Label lbAppraisalsComplete;
        private System.Windows.Forms.Label lbAnyAppraisals;
        private System.Windows.Forms.Label lbNoAppraisals;
        private System.Windows.Forms.ComboBox cbCriteriaType;
        private System.Windows.Forms.Label lbAppraisalsCompleteCount;
        private System.Windows.Forms.Label lbAnyAppraisalsCount;
        private System.Windows.Forms.Label lbNoAppraisalsCount;
        private System.Windows.Forms.TableLayoutPanel buttonsLayoutPanel;
        private System.Windows.Forms.Button btOK;
        private System.Windows.Forms.Button btCancel;
        private System.Windows.Forms.Button btClose;
    }
}