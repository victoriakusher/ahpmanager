﻿namespace AHPManager
{
    partial class CompareForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_CompareCancel = new System.Windows.Forms.Button();
            this.btn_Calc = new System.Windows.Forms.Button();
            this.btn_Cycle = new System.Windows.Forms.Button();
            this.criterionTypeGroupBox = new System.Windows.Forms.GroupBox();
            this.comparativeRadioButton = new System.Windows.Forms.RadioButton();
            this.quantitativeRadioButton = new System.Windows.Forms.RadioButton();
            this.scaleGroupBox = new System.Windows.Forms.GroupBox();
            this.btn_setScalesParams = new System.Windows.Forms.Button();
            this.logisticRadioButton = new System.Windows.Forms.RadioButton();
            this.saatyRadioButton = new System.Windows.Forms.RadioButton();
            this.bruckRadioButton = new System.Windows.Forms.RadioButton();
            this.quantCriterionTypeGroupBox = new System.Windows.Forms.GroupBox();
            this.descendingRadioButton = new System.Windows.Forms.RadioButton();
            this.ascendingRadioButton = new System.Windows.Forms.RadioButton();
            this.btn_ResetAppraisals = new System.Windows.Forms.Button();
            this.comparativeCriterionPanel = new System.Windows.Forms.Panel();
            this.tlpComparative = new System.Windows.Forms.TableLayoutPanel();
            this.cbComparisonsList = new System.Windows.Forms.ComboBox();
            this.lbAppraisalDescription = new System.Windows.Forms.Label();
            this.trComparativeAppraisal = new System.Windows.Forms.TrackBar();
            this.lbLeftAlternative = new System.Windows.Forms.Label();
            this.lbRightAlternative = new System.Windows.Forms.Label();
            this.lbComparativeHeader = new System.Windows.Forms.Label();
            this.quantitativeCriterionPanel = new System.Windows.Forms.Panel();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.tsslComparisonsNumber = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsslComparisonsComplete = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsslComparisonsEquivalent = new System.Windows.Forms.ToolStripStatusLabel();
            this.criterionTypeGroupBox.SuspendLayout();
            this.scaleGroupBox.SuspendLayout();
            this.quantCriterionTypeGroupBox.SuspendLayout();
            this.comparativeCriterionPanel.SuspendLayout();
            this.tlpComparative.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trComparativeAppraisal)).BeginInit();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_CompareCancel
            // 
            this.btn_CompareCancel.BackColor = System.Drawing.SystemColors.Control;
            this.btn_CompareCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_CompareCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btn_CompareCancel.Location = new System.Drawing.Point(436, 421);
            this.btn_CompareCancel.Name = "btn_CompareCancel";
            this.btn_CompareCancel.Size = new System.Drawing.Size(149, 32);
            this.btn_CompareCancel.TabIndex = 5;
            this.btn_CompareCancel.Text = "Закрыть";
            this.btn_CompareCancel.UseVisualStyleBackColor = true;
            this.btn_CompareCancel.Click += new System.EventHandler(this.btn_CompareCancel_Click);
            // 
            // btn_Calc
            // 
            this.btn_Calc.BackColor = System.Drawing.SystemColors.Control;
            this.btn_Calc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btn_Calc.Location = new System.Drawing.Point(436, 344);
            this.btn_Calc.Name = "btn_Calc";
            this.btn_Calc.Size = new System.Drawing.Size(149, 32);
            this.btn_Calc.TabIndex = 35;
            this.btn_Calc.Text = "Локальные приоритеты";
            this.btn_Calc.UseVisualStyleBackColor = true;
            this.btn_Calc.Click += new System.EventHandler(this.btn_Calc_Click);
            // 
            // btn_Cycle
            // 
            this.btn_Cycle.BackColor = System.Drawing.SystemColors.Control;
            this.btn_Cycle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btn_Cycle.Location = new System.Drawing.Point(436, 383);
            this.btn_Cycle.Name = "btn_Cycle";
            this.btn_Cycle.Size = new System.Drawing.Size(149, 32);
            this.btn_Cycle.TabIndex = 40;
            this.btn_Cycle.Text = "Согласованность";
            this.btn_Cycle.UseVisualStyleBackColor = true;
            this.btn_Cycle.Click += new System.EventHandler(this.btn_Cycle_Click);
            // 
            // criterionTypeGroupBox
            // 
            this.criterionTypeGroupBox.Controls.Add(this.comparativeRadioButton);
            this.criterionTypeGroupBox.Controls.Add(this.quantitativeRadioButton);
            this.criterionTypeGroupBox.Location = new System.Drawing.Point(435, 10);
            this.criterionTypeGroupBox.Margin = new System.Windows.Forms.Padding(2);
            this.criterionTypeGroupBox.Name = "criterionTypeGroupBox";
            this.criterionTypeGroupBox.Padding = new System.Windows.Forms.Padding(2);
            this.criterionTypeGroupBox.Size = new System.Drawing.Size(150, 67);
            this.criterionTypeGroupBox.TabIndex = 41;
            this.criterionTypeGroupBox.TabStop = false;
            this.criterionTypeGroupBox.Text = "Тип критерия";
            // 
            // comparativeRadioButton
            // 
            this.comparativeRadioButton.AutoSize = true;
            this.comparativeRadioButton.Checked = true;
            this.comparativeRadioButton.Location = new System.Drawing.Point(4, 23);
            this.comparativeRadioButton.Margin = new System.Windows.Forms.Padding(2);
            this.comparativeRadioButton.Name = "comparativeRadioButton";
            this.comparativeRadioButton.Size = new System.Drawing.Size(104, 17);
            this.comparativeRadioButton.TabIndex = 1;
            this.comparativeRadioButton.TabStop = true;
            this.comparativeRadioButton.Text = "сравнительный";
            this.comparativeRadioButton.UseVisualStyleBackColor = true;
            this.comparativeRadioButton.CheckedChanged += new System.EventHandler(this.comparativeRadioButton_CheckedChanged);
            // 
            // quantitativeRadioButton
            // 
            this.quantitativeRadioButton.AutoSize = true;
            this.quantitativeRadioButton.Location = new System.Drawing.Point(4, 45);
            this.quantitativeRadioButton.Margin = new System.Windows.Forms.Padding(2);
            this.quantitativeRadioButton.Name = "quantitativeRadioButton";
            this.quantitativeRadioButton.Size = new System.Drawing.Size(109, 17);
            this.quantitativeRadioButton.TabIndex = 0;
            this.quantitativeRadioButton.Text = "количественный";
            this.quantitativeRadioButton.UseVisualStyleBackColor = true;
            this.quantitativeRadioButton.CheckedChanged += new System.EventHandler(this.quantitativeRadioButton_CheckedChanged);
            // 
            // scaleGroupBox
            // 
            this.scaleGroupBox.Controls.Add(this.btn_setScalesParams);
            this.scaleGroupBox.Controls.Add(this.logisticRadioButton);
            this.scaleGroupBox.Controls.Add(this.saatyRadioButton);
            this.scaleGroupBox.Controls.Add(this.bruckRadioButton);
            this.scaleGroupBox.Location = new System.Drawing.Point(435, 81);
            this.scaleGroupBox.Margin = new System.Windows.Forms.Padding(2);
            this.scaleGroupBox.Name = "scaleGroupBox";
            this.scaleGroupBox.Padding = new System.Windows.Forms.Padding(2);
            this.scaleGroupBox.Size = new System.Drawing.Size(150, 132);
            this.scaleGroupBox.TabIndex = 42;
            this.scaleGroupBox.TabStop = false;
            this.scaleGroupBox.Text = "Шкала";
            // 
            // btn_setScalesParams
            // 
            this.btn_setScalesParams.Location = new System.Drawing.Point(5, 92);
            this.btn_setScalesParams.Name = "btn_setScalesParams";
            this.btn_setScalesParams.Size = new System.Drawing.Size(140, 29);
            this.btn_setScalesParams.TabIndex = 47;
            this.btn_setScalesParams.Text = "Параметры шкалы";
            this.btn_setScalesParams.UseVisualStyleBackColor = true;
            this.btn_setScalesParams.Click += new System.EventHandler(this.btn_setScalesParams_Click);
            // 
            // logisticRadioButton
            // 
            this.logisticRadioButton.AutoSize = true;
            this.logisticRadioButton.Location = new System.Drawing.Point(4, 65);
            this.logisticRadioButton.Margin = new System.Windows.Forms.Padding(2);
            this.logisticRadioButton.Name = "logisticRadioButton";
            this.logisticRadioButton.Size = new System.Drawing.Size(102, 17);
            this.logisticRadioButton.TabIndex = 1;
            this.logisticRadioButton.Text = "Логистическая";
            this.logisticRadioButton.UseVisualStyleBackColor = true;
            // 
            // saatyRadioButton
            // 
            this.saatyRadioButton.AutoSize = true;
            this.saatyRadioButton.Checked = true;
            this.saatyRadioButton.Location = new System.Drawing.Point(4, 43);
            this.saatyRadioButton.Margin = new System.Windows.Forms.Padding(2);
            this.saatyRadioButton.Name = "saatyRadioButton";
            this.saatyRadioButton.Size = new System.Drawing.Size(55, 17);
            this.saatyRadioButton.TabIndex = 2;
            this.saatyRadioButton.TabStop = true;
            this.saatyRadioButton.Text = "Саати";
            this.saatyRadioButton.UseVisualStyleBackColor = true;
            // 
            // bruckRadioButton
            // 
            this.bruckRadioButton.AutoSize = true;
            this.bruckRadioButton.Location = new System.Drawing.Point(4, 21);
            this.bruckRadioButton.Margin = new System.Windows.Forms.Padding(2);
            this.bruckRadioButton.Name = "bruckRadioButton";
            this.bruckRadioButton.Size = new System.Drawing.Size(55, 17);
            this.bruckRadioButton.TabIndex = 0;
            this.bruckRadioButton.Text = "Брука";
            this.bruckRadioButton.UseVisualStyleBackColor = true;
            // 
            // quantCriterionTypeGroupBox
            // 
            this.quantCriterionTypeGroupBox.Controls.Add(this.descendingRadioButton);
            this.quantCriterionTypeGroupBox.Controls.Add(this.ascendingRadioButton);
            this.quantCriterionTypeGroupBox.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.quantCriterionTypeGroupBox.Location = new System.Drawing.Point(435, 81);
            this.quantCriterionTypeGroupBox.Margin = new System.Windows.Forms.Padding(2);
            this.quantCriterionTypeGroupBox.Name = "quantCriterionTypeGroupBox";
            this.quantCriterionTypeGroupBox.Padding = new System.Windows.Forms.Padding(2);
            this.quantCriterionTypeGroupBox.Size = new System.Drawing.Size(150, 87);
            this.quantCriterionTypeGroupBox.TabIndex = 43;
            this.quantCriterionTypeGroupBox.TabStop = false;
            this.quantCriterionTypeGroupBox.Text = "Критерий";
            this.quantCriterionTypeGroupBox.Visible = false;
            // 
            // descendingRadioButton
            // 
            this.descendingRadioButton.AutoSize = true;
            this.descendingRadioButton.Location = new System.Drawing.Point(4, 43);
            this.descendingRadioButton.Margin = new System.Windows.Forms.Padding(2);
            this.descendingRadioButton.Name = "descendingRadioButton";
            this.descendingRadioButton.Size = new System.Drawing.Size(85, 17);
            this.descendingRadioButton.TabIndex = 1;
            this.descendingRadioButton.Text = "убывающий";
            this.descendingRadioButton.UseVisualStyleBackColor = true;
            this.descendingRadioButton.CheckedChanged += new System.EventHandler(this.descendingRadioButton_CheckedChanged);
            // 
            // ascendingRadioButton
            // 
            this.ascendingRadioButton.AutoSize = true;
            this.ascendingRadioButton.Checked = true;
            this.ascendingRadioButton.Location = new System.Drawing.Point(4, 21);
            this.ascendingRadioButton.Margin = new System.Windows.Forms.Padding(2);
            this.ascendingRadioButton.Name = "ascendingRadioButton";
            this.ascendingRadioButton.Size = new System.Drawing.Size(107, 17);
            this.ascendingRadioButton.TabIndex = 0;
            this.ascendingRadioButton.TabStop = true;
            this.ascendingRadioButton.Text = "возврастающий";
            this.ascendingRadioButton.UseVisualStyleBackColor = true;
            this.ascendingRadioButton.CheckedChanged += new System.EventHandler(this.ascendingRadioButton_CheckedChanged);
            // 
            // btn_ResetAppraisals
            // 
            this.btn_ResetAppraisals.Location = new System.Drawing.Point(436, 307);
            this.btn_ResetAppraisals.Margin = new System.Windows.Forms.Padding(2);
            this.btn_ResetAppraisals.Name = "btn_ResetAppraisals";
            this.btn_ResetAppraisals.Size = new System.Drawing.Size(149, 32);
            this.btn_ResetAppraisals.TabIndex = 44;
            this.btn_ResetAppraisals.Text = "Очистить оценки";
            this.btn_ResetAppraisals.UseVisualStyleBackColor = true;
            this.btn_ResetAppraisals.Click += new System.EventHandler(this.btn_ResetAppraisals_Click);
            // 
            // comparativeCriterionPanel
            // 
            this.comparativeCriterionPanel.Controls.Add(this.tlpComparative);
            this.comparativeCriterionPanel.Location = new System.Drawing.Point(9, 10);
            this.comparativeCriterionPanel.Margin = new System.Windows.Forms.Padding(2);
            this.comparativeCriterionPanel.Name = "comparativeCriterionPanel";
            this.comparativeCriterionPanel.Size = new System.Drawing.Size(422, 444);
            this.comparativeCriterionPanel.TabIndex = 45;
            // 
            // tlpComparative
            // 
            this.tlpComparative.ColumnCount = 3;
            this.tlpComparative.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tlpComparative.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tlpComparative.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tlpComparative.Controls.Add(this.cbComparisonsList, 0, 5);
            this.tlpComparative.Controls.Add(this.lbAppraisalDescription, 0, 4);
            this.tlpComparative.Controls.Add(this.trComparativeAppraisal, 1, 2);
            this.tlpComparative.Controls.Add(this.lbLeftAlternative, 0, 2);
            this.tlpComparative.Controls.Add(this.lbRightAlternative, 2, 2);
            this.tlpComparative.Controls.Add(this.lbComparativeHeader, 0, 0);
            this.tlpComparative.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpComparative.Location = new System.Drawing.Point(0, 0);
            this.tlpComparative.Name = "tlpComparative";
            this.tlpComparative.RowCount = 6;
            this.tlpComparative.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tlpComparative.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpComparative.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tlpComparative.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tlpComparative.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tlpComparative.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tlpComparative.Size = new System.Drawing.Size(422, 444);
            this.tlpComparative.TabIndex = 0;
            // 
            // cbComparisonsList
            // 
            this.cbComparisonsList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tlpComparative.SetColumnSpan(this.cbComparisonsList, 3);
            this.cbComparisonsList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbComparisonsList.FormattingEnabled = true;
            this.cbComparisonsList.Location = new System.Drawing.Point(3, 420);
            this.cbComparisonsList.Name = "cbComparisonsList";
            this.cbComparisonsList.Size = new System.Drawing.Size(416, 21);
            this.cbComparisonsList.TabIndex = 0;
            // 
            // lbAppraisalDescription
            // 
            this.lbAppraisalDescription.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lbAppraisalDescription.AutoSize = true;
            this.tlpComparative.SetColumnSpan(this.lbAppraisalDescription, 3);
            this.lbAppraisalDescription.Location = new System.Drawing.Point(3, 404);
            this.lbAppraisalDescription.Name = "lbAppraisalDescription";
            this.lbAppraisalDescription.Size = new System.Drawing.Size(416, 13);
            this.lbAppraisalDescription.TabIndex = 1;
            this.lbAppraisalDescription.Text = "описание оценки";
            this.lbAppraisalDescription.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // trComparativeAppraisal
            // 
            this.trComparativeAppraisal.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.trComparativeAppraisal.LargeChange = 1;
            this.trComparativeAppraisal.Location = new System.Drawing.Point(129, 356);
            this.trComparativeAppraisal.Maximum = 4;
            this.trComparativeAppraisal.Minimum = -4;
            this.trComparativeAppraisal.Name = "trComparativeAppraisal";
            this.tlpComparative.SetRowSpan(this.trComparativeAppraisal, 2);
            this.trComparativeAppraisal.Size = new System.Drawing.Size(162, 45);
            this.trComparativeAppraisal.TabIndex = 2;
            // 
            // lbLeftAlternative
            // 
            this.lbLeftAlternative.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lbLeftAlternative.AutoSize = true;
            this.lbLeftAlternative.Location = new System.Drawing.Point(3, 353);
            this.lbLeftAlternative.Name = "lbLeftAlternative";
            this.lbLeftAlternative.Size = new System.Drawing.Size(120, 13);
            this.lbLeftAlternative.TabIndex = 3;
            this.lbLeftAlternative.Text = "элемент 1";
            this.lbLeftAlternative.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbRightAlternative
            // 
            this.lbRightAlternative.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lbRightAlternative.AutoSize = true;
            this.lbRightAlternative.Location = new System.Drawing.Point(297, 353);
            this.lbRightAlternative.Name = "lbRightAlternative";
            this.lbRightAlternative.Size = new System.Drawing.Size(122, 13);
            this.lbRightAlternative.TabIndex = 4;
            this.lbRightAlternative.Text = "элемент 2";
            this.lbRightAlternative.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbComparativeHeader
            // 
            this.lbComparativeHeader.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lbComparativeHeader.AutoSize = true;
            this.tlpComparative.SetColumnSpan(this.lbComparativeHeader, 3);
            this.lbComparativeHeader.Location = new System.Drawing.Point(3, 0);
            this.lbComparativeHeader.Name = "lbComparativeHeader";
            this.lbComparativeHeader.Size = new System.Drawing.Size(416, 13);
            this.lbComparativeHeader.TabIndex = 5;
            this.lbComparativeHeader.Text = "Сравнения по критерию";
            this.lbComparativeHeader.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // quantitativeCriterionPanel
            // 
            this.quantitativeCriterionPanel.Location = new System.Drawing.Point(9, 10);
            this.quantitativeCriterionPanel.Margin = new System.Windows.Forms.Padding(2);
            this.quantitativeCriterionPanel.Name = "quantitativeCriterionPanel";
            this.quantitativeCriterionPanel.Size = new System.Drawing.Size(422, 444);
            this.quantitativeCriterionPanel.TabIndex = 46;
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsslComparisonsNumber,
            this.tsslComparisonsComplete,
            this.tsslComparisonsEquivalent});
            this.statusStrip.Location = new System.Drawing.Point(0, 460);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(596, 22);
            this.statusStrip.SizingGrip = false;
            this.statusStrip.TabIndex = 47;
            this.statusStrip.Text = "statusStrip1";
            // 
            // tsslComparisonsNumber
            // 
            this.tsslComparisonsNumber.Name = "tsslComparisonsNumber";
            this.tsslComparisonsNumber.Size = new System.Drawing.Size(193, 17);
            this.tsslComparisonsNumber.Spring = true;
            this.tsslComparisonsNumber.Text = "Сравнений: ";
            // 
            // tsslComparisonsComplete
            // 
            this.tsslComparisonsComplete.Name = "tsslComparisonsComplete";
            this.tsslComparisonsComplete.Size = new System.Drawing.Size(193, 17);
            this.tsslComparisonsComplete.Spring = true;
            this.tsslComparisonsComplete.Text = "Проведенных сравнений: ";
            // 
            // tsslComparisonsEquivalent
            // 
            this.tsslComparisonsEquivalent.Name = "tsslComparisonsEquivalent";
            this.tsslComparisonsEquivalent.Size = new System.Drawing.Size(193, 17);
            this.tsslComparisonsEquivalent.Spring = true;
            this.tsslComparisonsEquivalent.Text = "Эквивалентностей: ";
            // 
            // CompareForm
            // 
            this.AcceptButton = this.btn_CompareCancel;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.CancelButton = this.btn_CompareCancel;
            this.ClientSize = new System.Drawing.Size(596, 482);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.btn_ResetAppraisals);
            this.Controls.Add(this.criterionTypeGroupBox);
            this.Controls.Add(this.btn_Cycle);
            this.Controls.Add(this.btn_Calc);
            this.Controls.Add(this.btn_CompareCancel);
            this.Controls.Add(this.scaleGroupBox);
            this.Controls.Add(this.comparativeCriterionPanel);
            this.Controls.Add(this.quantitativeCriterionPanel);
            this.Controls.Add(this.quantCriterionTypeGroupBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CompareForm";
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Критерий";
            this.Load += new System.EventHandler(this.Compare_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CompareForm_FormClosing);
            this.criterionTypeGroupBox.ResumeLayout(false);
            this.criterionTypeGroupBox.PerformLayout();
            this.scaleGroupBox.ResumeLayout(false);
            this.scaleGroupBox.PerformLayout();
            this.quantCriterionTypeGroupBox.ResumeLayout(false);
            this.quantCriterionTypeGroupBox.PerformLayout();
            this.comparativeCriterionPanel.ResumeLayout(false);
            this.tlpComparative.ResumeLayout(false);
            this.tlpComparative.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trComparativeAppraisal)).EndInit();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_CompareCancel;
        private System.Windows.Forms.Button btn_Calc;
        private System.Windows.Forms.Button btn_Cycle;
        private System.Windows.Forms.GroupBox criterionTypeGroupBox;
        private System.Windows.Forms.RadioButton comparativeRadioButton;
        private System.Windows.Forms.RadioButton quantitativeRadioButton;
        private System.Windows.Forms.GroupBox scaleGroupBox;
        private System.Windows.Forms.RadioButton logisticRadioButton;
        private System.Windows.Forms.RadioButton saatyRadioButton;
        private System.Windows.Forms.RadioButton bruckRadioButton;
        private System.Windows.Forms.GroupBox quantCriterionTypeGroupBox;
        private System.Windows.Forms.RadioButton descendingRadioButton;
        private System.Windows.Forms.RadioButton ascendingRadioButton;
        private System.Windows.Forms.Button btn_ResetAppraisals;
        private System.Windows.Forms.Panel comparativeCriterionPanel;
        private System.Windows.Forms.Panel quantitativeCriterionPanel;
        private System.Windows.Forms.Button btn_setScalesParams;
        private System.Windows.Forms.TableLayoutPanel tlpComparative;
        private System.Windows.Forms.ComboBox cbComparisonsList;
        private System.Windows.Forms.Label lbAppraisalDescription;
        private System.Windows.Forms.TrackBar trComparativeAppraisal;
        private System.Windows.Forms.Label lbLeftAlternative;
        private System.Windows.Forms.Label lbRightAlternative;
        private System.Windows.Forms.Label lbComparativeHeader;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel tsslComparisonsNumber;
        private System.Windows.Forms.ToolStripStatusLabel tsslComparisonsComplete;
        private System.Windows.Forms.ToolStripStatusLabel tsslComparisonsEquivalent;
    }
}