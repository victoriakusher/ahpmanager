﻿using ZedGraph;
namespace AHPManager
{
    partial class ResultsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.zedGraphCtrl_results = new ZedGraph.ZedGraphControl();
            this.btn_BackToHierarch = new System.Windows.Forms.Button();
            this.btn_CloseWnd = new System.Windows.Forms.Button();
            this.btn_SaveResults_Click = new System.Windows.Forms.Button();
            this.tlpMain = new System.Windows.Forms.TableLayoutPanel();
            this.btn_CreareReport = new System.Windows.Forms.Button();
            this.tlpMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // zedGraphCtrl_results
            // 
            this.tlpMain.SetColumnSpan(this.zedGraphCtrl_results, 4);
            this.zedGraphCtrl_results.Dock = System.Windows.Forms.DockStyle.Fill;
            this.zedGraphCtrl_results.IsEnableHPan = false;
            this.zedGraphCtrl_results.IsEnableHZoom = false;
            this.zedGraphCtrl_results.IsEnableVPan = false;
            this.zedGraphCtrl_results.IsEnableVZoom = false;
            this.zedGraphCtrl_results.IsShowContextMenu = false;
            this.zedGraphCtrl_results.IsShowCopyMessage = false;
            this.zedGraphCtrl_results.Location = new System.Drawing.Point(3, 3);
            this.zedGraphCtrl_results.Name = "zedGraphCtrl_results";
            this.zedGraphCtrl_results.ScrollGrace = 0;
            this.zedGraphCtrl_results.ScrollMaxX = 0;
            this.zedGraphCtrl_results.ScrollMaxY = 0;
            this.zedGraphCtrl_results.ScrollMaxY2 = 0;
            this.zedGraphCtrl_results.ScrollMinX = 0;
            this.zedGraphCtrl_results.ScrollMinY = 0;
            this.zedGraphCtrl_results.ScrollMinY2 = 0;
            this.zedGraphCtrl_results.Size = new System.Drawing.Size(628, 407);
            this.zedGraphCtrl_results.TabIndex = 0;
            // 
            // btn_BackToHierarch
            // 
            this.btn_BackToHierarch.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_BackToHierarch.Location = new System.Drawing.Point(319, 416);
            this.btn_BackToHierarch.Name = "btn_BackToHierarch";
            this.btn_BackToHierarch.Size = new System.Drawing.Size(152, 33);
            this.btn_BackToHierarch.TabIndex = 3;
            this.btn_BackToHierarch.Text = "Изменить диаграмму";
            this.btn_BackToHierarch.UseVisualStyleBackColor = true;
            this.btn_BackToHierarch.Click += new System.EventHandler(this.btn_BackToHierarch_Click);
            // 
            // btn_CloseWnd
            // 
            this.btn_CloseWnd.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_CloseWnd.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_CloseWnd.Location = new System.Drawing.Point(477, 416);
            this.btn_CloseWnd.Name = "btn_CloseWnd";
            this.btn_CloseWnd.Size = new System.Drawing.Size(154, 33);
            this.btn_CloseWnd.TabIndex = 2;
            this.btn_CloseWnd.Text = "Закрыть";
            this.btn_CloseWnd.UseVisualStyleBackColor = true;
            this.btn_CloseWnd.Click += new System.EventHandler(this.btn_CloseWnd_Click);
            // 
            // btn_SaveResults_Click
            // 
            this.btn_SaveResults_Click.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_SaveResults_Click.Location = new System.Drawing.Point(161, 416);
            this.btn_SaveResults_Click.Name = "btn_SaveResults_Click";
            this.btn_SaveResults_Click.Size = new System.Drawing.Size(152, 33);
            this.btn_SaveResults_Click.TabIndex = 4;
            this.btn_SaveResults_Click.Text = "Импорт иерархии";
            this.btn_SaveResults_Click.UseVisualStyleBackColor = true;
            this.btn_SaveResults_Click.Click += new System.EventHandler(this.btn_SaveResults_Click_Click);
            // 
            // tlpMain
            // 
            this.tlpMain.ColumnCount = 4;
            this.tlpMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpMain.Controls.Add(this.btn_SaveResults_Click, 1, 1);
            this.tlpMain.Controls.Add(this.zedGraphCtrl_results, 0, 0);
            this.tlpMain.Controls.Add(this.btn_CloseWnd, 3, 1);
            this.tlpMain.Controls.Add(this.btn_BackToHierarch, 2, 1);
            this.tlpMain.Controls.Add(this.btn_CreareReport, 0, 1);
            this.tlpMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpMain.Location = new System.Drawing.Point(0, 0);
            this.tlpMain.Name = "tlpMain";
            this.tlpMain.RowCount = 2;
            this.tlpMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpMain.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tlpMain.Size = new System.Drawing.Size(634, 452);
            this.tlpMain.TabIndex = 5;
            // 
            // btn_CreareReport
            // 
            this.btn_CreareReport.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_CreareReport.Location = new System.Drawing.Point(3, 416);
            this.btn_CreareReport.Name = "btn_CreareReport";
            this.btn_CreareReport.Size = new System.Drawing.Size(152, 33);
            this.btn_CreareReport.TabIndex = 5;
            this.btn_CreareReport.Text = "Создать отчет";
            this.btn_CreareReport.UseVisualStyleBackColor = true;
            this.btn_CreareReport.Click += new System.EventHandler(this.btn_CreareReport_Click);
            // 
            // ResultsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(634, 452);
            this.Controls.Add(this.tlpMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ResultsForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Результаты";
            this.Load += new System.EventHandler(this.ResultsForm_Load);
            this.tlpMain.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion


        private ZedGraph.ZedGraphControl zedGraphCtrl_results;
        private System.Windows.Forms.Button btn_BackToHierarch;
        private System.Windows.Forms.Button btn_CloseWnd;
        private System.Windows.Forms.Button btn_SaveResults_Click;
        private System.Windows.Forms.TableLayoutPanel tlpMain;
        private System.Windows.Forms.Button btn_CreareReport;
    }
}