﻿namespace AHPManager
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.File_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CreateProject_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.OpenProject_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.SaveProject_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SaveAs_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.Exit_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Spravka_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ShowHelpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AboutProgToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.tsmiProject = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiProjectProperties = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiProjectStatistics = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiDefaultScaleParameters = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiAnalysis = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiResults = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiReport = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip = new System.Windows.Forms.ToolStrip();
            this.newToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.openToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.saveToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripBtn_VesEdit = new System.Windows.Forms.ToolStripButton();
            this.toolStripBtn_Help = new System.Windows.Forms.ToolStripButton();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.pnlHierarchy = new System.Windows.Forms.Panel();
            this.menuStrip.SuspendLayout();
            this.toolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // File_ToolStripMenuItem
            // 
            this.File_ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CreateProject_ToolStripMenuItem,
            this.OpenProject_ToolStripMenuItem,
            this.toolStripSeparator2,
            this.SaveProject_ToolStripMenuItem,
            this.SaveAs_ToolStripMenuItem,
            this.toolStripSeparator1,
            this.Exit_ToolStripMenuItem});
            this.File_ToolStripMenuItem.Name = "File_ToolStripMenuItem";
            this.File_ToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.File_ToolStripMenuItem.Text = "&Файл";
            // 
            // CreateProject_ToolStripMenuItem
            // 
            this.CreateProject_ToolStripMenuItem.Image = global::AHPManager.Properties.Resources.Document;
            this.CreateProject_ToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Fuchsia;
            this.CreateProject_ToolStripMenuItem.Name = "CreateProject_ToolStripMenuItem";
            this.CreateProject_ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.CreateProject_ToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.CreateProject_ToolStripMenuItem.Text = "&Создать";
            this.CreateProject_ToolStripMenuItem.Click += new System.EventHandler(this.CreateProject_ToolStripMenuItem_Click);
            // 
            // OpenProject_ToolStripMenuItem
            // 
            this.OpenProject_ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("OpenProject_ToolStripMenuItem.Image")));
            this.OpenProject_ToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Fuchsia;
            this.OpenProject_ToolStripMenuItem.Name = "OpenProject_ToolStripMenuItem";
            this.OpenProject_ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.OpenProject_ToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.OpenProject_ToolStripMenuItem.Text = "&Открыть...";
            this.OpenProject_ToolStripMenuItem.Click += new System.EventHandler(this.OpenProject_ToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(160, 6);
            // 
            // SaveProject_ToolStripMenuItem
            // 
            this.SaveProject_ToolStripMenuItem.Image = global::AHPManager.Properties.Resources.Save;
            this.SaveProject_ToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Fuchsia;
            this.SaveProject_ToolStripMenuItem.Name = "SaveProject_ToolStripMenuItem";
            this.SaveProject_ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.SaveProject_ToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.SaveProject_ToolStripMenuItem.Text = "&Сохранить";
            this.SaveProject_ToolStripMenuItem.Click += new System.EventHandler(this.SaveProject_ToolStripMenuItem_Click);
            // 
            // SaveAs_ToolStripMenuItem
            // 
            this.SaveAs_ToolStripMenuItem.Name = "SaveAs_ToolStripMenuItem";
            this.SaveAs_ToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.SaveAs_ToolStripMenuItem.Text = "Сохранить &как...";
            this.SaveAs_ToolStripMenuItem.Click += new System.EventHandler(this.SaveAs_ToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(160, 6);
            // 
            // Exit_ToolStripMenuItem
            // 
            this.Exit_ToolStripMenuItem.Name = "Exit_ToolStripMenuItem";
            this.Exit_ToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.Exit_ToolStripMenuItem.Text = "Вы&ход";
            this.Exit_ToolStripMenuItem.Click += new System.EventHandler(this.Exit_ToolStripMenuItem_Click);
            // 
            // Spravka_ToolStripMenuItem
            // 
            this.Spravka_ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ShowHelpToolStripMenuItem,
            this.AboutProgToolStripMenuItem});
            this.Spravka_ToolStripMenuItem.Name = "Spravka_ToolStripMenuItem";
            this.Spravka_ToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.Spravka_ToolStripMenuItem.Text = "&Справка";
            // 
            // ShowHelpToolStripMenuItem
            // 
            this.ShowHelpToolStripMenuItem.Image = global::AHPManager.Properties.Resources.Help;
            this.ShowHelpToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Fuchsia;
            this.ShowHelpToolStripMenuItem.Name = "ShowHelpToolStripMenuItem";
            this.ShowHelpToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ShowHelpToolStripMenuItem.Text = "&Вызов справки";
            this.ShowHelpToolStripMenuItem.Click += new System.EventHandler(this.ShowHelpToolStripMenuItem_Click);
            // 
            // AboutProgToolStripMenuItem
            // 
            this.AboutProgToolStripMenuItem.Name = "AboutProgToolStripMenuItem";
            this.AboutProgToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.AboutProgToolStripMenuItem.Text = "&О программе...";
            this.AboutProgToolStripMenuItem.Click += new System.EventHandler(this.AboutProgToolStripMenuItem_Click_1);
            // 
            // menuStrip
            // 
            this.menuStrip.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.File_ToolStripMenuItem,
            this.tsmiProject,
            this.tsmiAnalysis,
            this.Spravka_ToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(784, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "menuStrip_MainMenu";
            // 
            // tsmiProject
            // 
            this.tsmiProject.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiProjectProperties,
            this.tsmiProjectStatistics,
            this.tsmiDefaultScaleParameters});
            this.tsmiProject.Enabled = false;
            this.tsmiProject.Name = "tsmiProject";
            this.tsmiProject.Size = new System.Drawing.Size(56, 20);
            this.tsmiProject.Text = "&Проект";
            // 
            // tsmiProjectProperties
            // 
            this.tsmiProjectProperties.Name = "tsmiProjectProperties";
            this.tsmiProjectProperties.Size = new System.Drawing.Size(207, 22);
            this.tsmiProjectProperties.Text = "&Свойства";
            this.tsmiProjectProperties.Click += new System.EventHandler(this.tsmiProjectProperties_Click);
            // 
            // tsmiProjectStatistics
            // 
            this.tsmiProjectStatistics.Name = "tsmiProjectStatistics";
            this.tsmiProjectStatistics.Size = new System.Drawing.Size(207, 22);
            this.tsmiProjectStatistics.Text = "С&татистика";
            this.tsmiProjectStatistics.Click += new System.EventHandler(this.tsmiProjectStatistics_Click);
            // 
            // tsmiDefaultScaleParameters
            // 
            this.tsmiDefaultScaleParameters.Name = "tsmiDefaultScaleParameters";
            this.tsmiDefaultScaleParameters.Size = new System.Drawing.Size(207, 22);
            this.tsmiDefaultScaleParameters.Text = "&Параметры по умолчанию";
            this.tsmiDefaultScaleParameters.Click += new System.EventHandler(this.tsmiDefaultScaleParameters_Click);
            // 
            // tsmiAnalysis
            // 
            this.tsmiAnalysis.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiResults,
            this.tsmiReport});
            this.tsmiAnalysis.Enabled = false;
            this.tsmiAnalysis.Name = "tsmiAnalysis";
            this.tsmiAnalysis.Size = new System.Drawing.Size(56, 20);
            this.tsmiAnalysis.Text = "&Анализ";
            // 
            // tsmiResults
            // 
            this.tsmiResults.Image = global::AHPManager.Properties.Resources.Graph;
            this.tsmiResults.ImageTransparentColor = System.Drawing.Color.Fuchsia;
            this.tsmiResults.Name = "tsmiResults";
            this.tsmiResults.Size = new System.Drawing.Size(134, 22);
            this.tsmiResults.Text = "&Результаты";
            this.tsmiResults.Click += new System.EventHandler(this.tsmiResults_Click);
            // 
            // tsmiReport
            // 
            this.tsmiReport.Name = "tsmiReport";
            this.tsmiReport.Size = new System.Drawing.Size(134, 22);
            this.tsmiReport.Text = "&Отчет";
            this.tsmiReport.Click += new System.EventHandler(this.tsmiReport_Click);
            // 
            // toolStrip
            // 
            this.toolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripButton,
            this.openToolStripButton,
            this.saveToolStripButton,
            this.toolStripSeparator,
            this.toolStripBtn_VesEdit,
            this.toolStripBtn_Help});
            this.toolStrip.Location = new System.Drawing.Point(0, 24);
            this.toolStrip.Name = "toolStrip";
            this.toolStrip.Size = new System.Drawing.Size(784, 25);
            this.toolStrip.TabIndex = 3;
            this.toolStrip.Text = "toolStrip1";
            // 
            // newToolStripButton
            // 
            this.newToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.newToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("newToolStripButton.Image")));
            this.newToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.newToolStripButton.Name = "newToolStripButton";
            this.newToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.newToolStripButton.Text = "Новый проект";
            this.newToolStripButton.Click += new System.EventHandler(this.newToolStripButton_Click);
            // 
            // openToolStripButton
            // 
            this.openToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.openToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("openToolStripButton.Image")));
            this.openToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.openToolStripButton.Name = "openToolStripButton";
            this.openToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.openToolStripButton.Text = "Открыть";
            this.openToolStripButton.Click += new System.EventHandler(this.openToolStripButton_Click);
            // 
            // saveToolStripButton
            // 
            this.saveToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.saveToolStripButton.Enabled = false;
            this.saveToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("saveToolStripButton.Image")));
            this.saveToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saveToolStripButton.Name = "saveToolStripButton";
            this.saveToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.saveToolStripButton.Text = "Сохранить";
            this.saveToolStripButton.Click += new System.EventHandler(this.saveToolStripButton_Click);
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripBtn_VesEdit
            // 
            this.toolStripBtn_VesEdit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripBtn_VesEdit.Enabled = false;
            this.toolStripBtn_VesEdit.Image = global::AHPManager.Properties.Resources.Graph;
            this.toolStripBtn_VesEdit.ImageTransparentColor = System.Drawing.Color.Fuchsia;
            this.toolStripBtn_VesEdit.Name = "toolStripBtn_VesEdit";
            this.toolStripBtn_VesEdit.Size = new System.Drawing.Size(23, 22);
            this.toolStripBtn_VesEdit.Text = "Результаты";
            this.toolStripBtn_VesEdit.Click += new System.EventHandler(this.toolStripBtn_VesEdit_Click);
            // 
            // toolStripBtn_Help
            // 
            this.toolStripBtn_Help.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripBtn_Help.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripBtn_Help.Image = ((System.Drawing.Image)(resources.GetObject("toolStripBtn_Help.Image")));
            this.toolStripBtn_Help.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripBtn_Help.Name = "toolStripBtn_Help";
            this.toolStripBtn_Help.Size = new System.Drawing.Size(23, 22);
            this.toolStripBtn_Help.Text = "Вызов справки";
            this.toolStripBtn_Help.ToolTipText = "Вызов справки";
            this.toolStripBtn_Help.Click += new System.EventHandler(this.Help_Click_1);
            // 
            // statusStrip
            // 
            this.statusStrip.Location = new System.Drawing.Point(0, 540);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(784, 22);
            this.statusStrip.TabIndex = 4;
            this.statusStrip.Text = "statusStrip1";
            // 
            // pnlHierarchy
            // 
            this.pnlHierarchy.BackColor = System.Drawing.Color.LightBlue;
            this.pnlHierarchy.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlHierarchy.Location = new System.Drawing.Point(0, 49);
            this.pnlHierarchy.Name = "pnlHierarchy";
            this.pnlHierarchy.Size = new System.Drawing.Size(784, 491);
            this.pnlHierarchy.TabIndex = 5;
            this.pnlHierarchy.Resize += new System.EventHandler(this.pnlHierarchy_Resize);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 562);
            this.Controls.Add(this.pnlHierarchy);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.toolStrip);
            this.Controls.Add(this.menuStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip;
            this.MinimumSize = new System.Drawing.Size(640, 480);
            this.Name = "MainForm";
            this.Text = "Система поддержки принятия решений";
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.toolStrip.ResumeLayout(false);
            this.toolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem File_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem CreateProject_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem OpenProject_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SaveProject_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Exit_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Spravka_ToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStrip toolStrip;
        private System.Windows.Forms.ToolStripButton newToolStripButton;
        private System.Windows.Forms.ToolStripButton openToolStripButton;
        private System.Windows.Forms.ToolStripButton saveToolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.ToolStripButton toolStripBtn_VesEdit;
        private System.Windows.Forms.ToolStripMenuItem AboutProgToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripBtn_Help;
        private System.Windows.Forms.ToolStripMenuItem ShowHelpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsmiProject;
        private System.Windows.Forms.ToolStripMenuItem tsmiProjectProperties;
        private System.Windows.Forms.ToolStripMenuItem tsmiProjectStatistics;
        private System.Windows.Forms.ToolStripMenuItem tsmiAnalysis;
        private System.Windows.Forms.ToolStripMenuItem tsmiResults;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem tsmiDefaultScaleParameters;
        private System.Windows.Forms.ToolStripMenuItem SaveAs_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.Panel pnlHierarchy;
        private System.Windows.Forms.ToolStripMenuItem tsmiReport;
    }
}