﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Document;
using AHPManager.ReportClasses;
using Microsoft.Reporting.WinForms;

namespace AHPManager
{
    public partial class ReportForm : Form
    {
        /// <summary>
        /// Иерархия, по которой строится отчет.
        /// </summary>
        private Hierarchy hierarchy;

        /// <summary>
        /// Экзепляр класса HierarchySummary, хранящий отображаемые в
        /// отчете сведения об иерархии.
        /// </summary>
        private HierarchySummary hierarchySummary;

        /// <summary>
        /// Конструктор экземпляра класса ReportForm, принимает иерархию,
        /// по которой строится отчет.
        /// </summary>
        /// <param name="hierarchy">Иерархия, по которой строится отчет.</param>
        public ReportForm(Hierarchy hierarchy)
        {
            InitializeComponent();
            this.hierarchy = hierarchy;
            // ставим обработчик события SubreportProcessing для загрузки необходимой информации
            // в подотчеты об элементах иерархии
            this.reportViewer.LocalReport.SubreportProcessing += new SubreportProcessingEventHandler(LocalReport_SubreportProcessing);
        }

        void LocalReport_SubreportProcessing(object sender, SubreportProcessingEventArgs e)
        {
            e.DataSources.Add(new ReportDataSource("ReportDemo_ElementSummary", hierarchySummary.GetElementSummaries()));
            e.DataSources.Add(new ReportDataSource("ReportDemo_ElementValueSummary", hierarchySummary.GetElementValueSummaries()));
            e.DataSources.Add(new ReportDataSource("ReportDemo_PairComparisonSummary", hierarchySummary.GetPairComparisonSummaries()));
            e.DataSources.Add(new ReportDataSource("ReportDemo_LocalAlternativeSummary", hierarchySummary.GetLocalAlternativeSummaries()));
        }

        private void ReportForm_Load(object sender, EventArgs e)
        {
            /* Создаем  и привязываем наборы данных для отчета. */

            hierarchySummary = new HierarchySummary(hierarchy);

            HierarchySummaryBindingSource.DataSource = hierarchySummary;
            LevelSummaryBindingSource.DataSource = hierarchySummary.GetLevelSummaries();
            ElementSummaryBindingSource.DataSource = hierarchySummary.GetElementSummaries();
            AlternativeSummaryBindingSource.DataSource = hierarchySummary.GetResults();
            ElementValueSummaryBindingSource.DataSource = hierarchySummary.GetElementValueSummaries();
            PairComparisonSummaryBindingSource.DataSource = hierarchySummary.GetPairComparisonSummaries();
            LocalAlternativeSummaryBindingSource.DataSource = hierarchySummary.GetLocalAlternativeSummaries();

            /* Задаем параметры отчета. */
            ReportParameter showTransitivityInformation = new ReportParameter("showTransitivityInformation", "True");

            ReportParameter discriminateIncompleteAppraisals = new ReportParameter(
                "discriminateIncompleteAppraisals", "True");
            reportViewer.LocalReport.SetParameters(new ReportParameter[] { showTransitivityInformation, discriminateIncompleteAppraisals });

            this.reportViewer.RefreshReport();
        }
    }
}
