﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AHP;
using Document;

namespace AHPManager
{
    internal static class AuxiliaryClass
    {
        /// <summary>
        /// Возвращает шкалу (экземпляр класса, производного от AHP.Scale), 
        /// построенную для указанного элемента в иерархии.
        /// </summary>
        /// <param name="element">Элемент, для которого строится шкала.</param>
        /// <param name="hierarchy">Иерархия, в которой содержится элемент.</param>
        /// <returns>Экземпляр класса, производного от AHP.Scale.</returns>
        /// <remarks>Если элемент не является критерием, то возвращается null.</remarks>
        internal static Scale CreateScale(Element element, Hierarchy hierarchy)
        {
            // используем шкалу Саати с классическими параметрами
            Scale result = new SaatyScale();
            result.UseDefaultParameters = false;
            result.CustomScaleParameters = new double[] { 2 };

            return result;
        }

        /// <summary>
        /// Возвращает экземпляр класса AHP.Matrix, построенный по указанной матрице
        /// попарных сравнений.
        /// </summary>
        /// <param name="CM">Матрица попарных сравнений.</param>
        internal static AHP.Matrix CMToAHPMatrix(ComparisonMatrix CM)
        {
            AHP.Matrix result = new AHP.Matrix(CM.Size);

            for (int i = 0; i < CM.Size; i++)
                for (int j = 0; j < CM.Size; j++)
                    result[i, j] = (CM[i, j] != Appraisals.undefined) ? CM[i, j] : Appraisals.equivalent;

            return result;
        }

        /// <summary>
        /// Возвращает объект типа WeightsTransformationMethod по значению типа
        /// QuantCriterions.
        /// </summary>
        internal static WeightsTransformationMethod GetWTM(QuantCriterions quantCriterionType)
        {
            WeightsTransformationMethod result = null;

            switch (quantCriterionType)
            {
                case QuantCriterions.ascending:
                    result = new AscendingWeightsMethod();
                    break;
                case QuantCriterions.descending:
                    result = new DescendingWeightsMethod();
                    break;
            }

            return result;
        }

        /// <summary>
        /// Преобразует экземпляр класса Document.Hierarchy в экземпляр класса
        /// AHP.HierarchialStructure.
        /// </summary>
        /// <param name="Hr">Экземпляр класса Document.Hierarchy.</param>
        /// <returns>Экземпляр класса AHP.HierarchialStructure.</returns>
        internal static HierarchialStructure ConvertHierarchy(Hierarchy hierarchy)
        {
            HierarchialStructure hs = new HierarchialStructure();
            List<Node> nodesLevel = null;      // ссылка на добавляемый уровень иерархической структуры
            Node node = null;                  // ссылка на добавляемый в уровень иерархической структуры элемент
            Element element = null;            // ссылка на рассматриваемый элемент иерархии

            // устанавливаем параметры по умолчанию для шкал
            SaatyScale.DefaultScaleParameters = hierarchy.defaultScaleParameters[2].ToArray();

            /* Альтернативы в иерархическую структуру не заносим, поэтому проходим
             * по уровням иерархии с нулевого до предпоследнего. */
            for (int i = 0; i < hierarchy.LevelsCount - 1; i++)
            {
                // формируем уровень и добавляем его в иерархическую структуру
                nodesLevel = new List<Node>();
                for (int j = 0; j < hierarchy.Levels[i].Count; j++)
                {
                    element = hierarchy.Levels[i].Elements[j];
                    switch (element.CriterionType)
                    {
                        case Criterions.comparative:
                            node = new Node(
                                element.LowerLevelCount(),
                                Node.NodeTypes.comparative,
                                new EigenvectorMethod(),
                                AuxiliaryClass.CreateScale(element, hierarchy));
                            node.comparisonsMatrix = AuxiliaryClass.CMToAHPMatrix(element.PairComparisons);
                            break;
                        case Criterions.quantitative:
                            node = new Node(
                                element.LowerLevelCount(),
                                Node.NodeTypes.quantitative,
                                AuxiliaryClass.GetWTM(element.QuantCriterionType));
                            node.weights = element.ElementValues;
                            break;
                    }
                    nodesLevel.Add(node);
                }
                hs.nodes.Add(nodesLevel);
            }
            return hs;
        }

        /// <summary>
        /// Поиск циклов в графе предпочтений, задаваемом альтернативами элемента element.
        /// </summary>
        /// <param name="element">Сравнительный критерий, в матрице попарных сравнений которого
        /// ищутся циклические триады.</param>
        /// <returns>Список циклов в графе предпочтений рассматриваемого элемента.</returns>
        internal static List<int[]> SearchForCyclicTriads(Element element)
        {
            List<int[]> cyclicTriads;   // список циклических триад (представляются массивами)
            int n = element.LowerLevelCount();

            // создаем матрицу смежности, состоящую из 0 и 1 (1 на i-ой строке и j-ом столбце
            // соответствует дуге из i в j, 0 - ее отсутствию)
            int[,] adjacencyMatrix = new int[n, n];
            for (int i = 0; i < n; i++)
                for (int j = i + 1; j < n; j++)
                    if (element.PairComparisons[i, j] != Appraisals.undefined)
                    {
                        switch (Math.Sign(element.PairComparisons[i, j]))
                        {
                            case -1:
                                adjacencyMatrix[j, i] = 1;
                                break;
                            case 0:
                                adjacencyMatrix[i, j] = adjacencyMatrix[j, i] = 1;
                                break;
                            case 1:
                                adjacencyMatrix[i, j] = 1;
                                break;
                        }
                    }
                    else
                        adjacencyMatrix[i, j] = adjacencyMatrix[j, i] = 1;

            /* Запускаем рекурсивный поиск в глубину. */
            List<int> searchHistory = new List<int>();
            cyclicTriads = new List<int[]>();
            int[,] edgeColors = new int[n, n];    // вспомогательная матрица для раскраски ребер графа предпочтений
            for (int i = 0; i < n; i++)
                SearchForCyclicTriadsEngine(element, adjacencyMatrix, edgeColors, cyclicTriads, i, searchHistory);

            /* Правила раскраски графа: 
             * 1) сначала все ребра белые (0)
             * 2) когда мы проходим по белому ребру, то красим его в серый цвет (1),
             * 3) если мы находим цикл, то красим все имеющиеся серые ребра в черный цвет (2),
             * 4) при возвращении в исходную вершину по ребру серого цвета красим его в белый цвет. */

            return cyclicTriads;
        }

        /// <summary>
        /// Рекурсивный метод для нахождения циклов поиском в глубину.
        /// </summary>
        internal static void SearchForCyclicTriadsEngine(Element element, int[,] adjacencyMatrix, int[,] edgeColors, List<int[]> cyclicTriads, int i, List<int> searchHistory)
        {
            searchHistory.Add(i);
            if (searchHistory.Count < 3)
                for (int j = 0; j < element.LowerLevelCount(); j++)
                    if (!searchHistory.Contains(j) && adjacencyMatrix[searchHistory.Last(), j] == 1)
                    {
                        if (edgeColors[i, j] == 0)
                            edgeColors[i, j] = 1;   // правило 2
                        SearchForCyclicTriadsEngine(element, adjacencyMatrix, edgeColors, cyclicTriads, j, searchHistory);
                        if (edgeColors[i, j] == 1)
                            edgeColors[i, j] = 0;    // правило 4
                    }
            if (searchHistory.Count == 3 && adjacencyMatrix[searchHistory.Last(), searchHistory.First()] == 1)
            {
                // если последнее, третье ребро цикла белое, то красим его в серый цвет
                if (edgeColors[searchHistory.Last(), searchHistory.First()] == 0)
                    edgeColors[searchHistory.Last(), searchHistory.First()] = 1;
                // проверяем, не получили ли мы "кольцо" из трех эквивалентных элементов
                if (((adjacencyMatrix[searchHistory[0], searchHistory[1]] != adjacencyMatrix[searchHistory[1], searchHistory[0]]) ||
                    adjacencyMatrix[searchHistory[1], searchHistory[2]] != adjacencyMatrix[searchHistory[2], searchHistory[1]]) ||
                    adjacencyMatrix[searchHistory[0], searchHistory[2]] != adjacencyMatrix[searchHistory[2], searchHistory[0]])
                    /* Нашли цикл. Во-первых проверяем, что он не окрашен целиком в черный цвет (т.е. мы не находили его
                     * ранее). Во-вторых, если мы нашли новый цикл, то окрашиваем все серые ребра в черный цвет. */
                    if ((edgeColors[searchHistory[0], searchHistory[1]] != 2 ||
                        edgeColors[searchHistory[1], searchHistory[2]] != 2) ||
                        edgeColors[searchHistory[2], searchHistory[0]] != 2)
                    {
                        cyclicTriads.Add(searchHistory.ToArray());
                        for (int k = 0; k < element.LowerLevelCount(); k++)
                            for (int l = 0; l < element.LowerLevelCount(); l++)
                                if (edgeColors[k, l] == 1)
                                    edgeColors[k, l] = 2;
                    }
                // если последнее ребро осталось серым, то красим его обратно в белый цвет
                if (edgeColors[searchHistory.Last(), searchHistory.First()] == 1)
                    edgeColors[searchHistory.Last(), searchHistory.First()] = 0;
            }
            searchHistory.RemoveAt(searchHistory.Count - 1);
        }

        /// <summary>
        /// Возвращает локальные приоритеты для элементов, являющихся
        /// альтернативами относительно указанного элемента.
        /// </summary>
        /// <param name="element">Элемент, относительно которого считаются
        /// локальные приоритеты.</param>
        /// <returns>Локальные приоритеты.</returns>
        internal static double[] GetLocalPriorities(Element element)
        {
            if (element.CriterionType == Criterions.noncriterion)
                return null;

            double[] localPriorities = new double[element.LowerLevelCount()];

            if (element.CriterionType == Criterions.comparative)
            {
                // действия для сравнительного критерия
                WeightsDerivingMethod wdm = new EigenvectorMethod();

                AHP.Scale elementScale = AuxiliaryClass.CreateScale(element, element.Hr);
                // преобразуем матрицу попарных сравнений в матрицу AHP.Matrix, применяя к ней выбранную шкалу
                AHP.Matrix scaledAppraisals = new AHP.Matrix(element.LowerLevelCount());
                for (int i = 0; i < element.LowerLevelCount(); i++)
                    for (int j = 0; j < element.LowerLevelCount(); j++)
                        // заменяем отсутствующие оценки оценками эквивалентности
                        scaledAppraisals[i, j] =
                            (element.PairComparisons[i, j] != Appraisals.undefined) ?
                            elementScale.Convert(element.PairComparisons[i, j]) :
                            elementScale.Convert(Appraisals.equivalent);

                localPriorities = wdm.GetWeights(scaledAppraisals);
            }
            else
            {
                // действия для количественного критерия

                WeightsTransformationMethod wtm = AuxiliaryClass.GetWTM(element.QuantCriterionType);
                double[] elementValues = new double[element.LowerLevelCount()];

                for (int i = 0; i < element.LowerLevelCount(); i++)
                    elementValues[i] = element.IsDefined[i] ? element.ElementValues[i] : 0;

                localPriorities = wtm.GetWeights(elementValues);
            }

            return localPriorities;
        }

        /// <summary>
        /// Проверяет, присутствуют ли в иерархии все оценки.
        /// </summary>
        /// <param name="hierarchy">Иерархия, для которой проверяется отсутствие оценок.</param>
        /// <returns>True, если в иерархии есть отсутствующие оценки, false - в противном
        /// случае.</returns>
        internal static bool CheckForMissingAppraisals(Hierarchy hierarchy)
        {
            foreach (Level level in hierarchy.Levels)
                foreach (Element element in level.Elements)
                    if (!element.ComparisonsComplete && element.CriterionType != Criterions.noncriterion)
                        return true;
            return false;
        }

        internal static Bitmap CreateHierarchyBitmap(Hierarchy hierarchy, Font font)
        {
            // параметры создаваемой картинки, см. пояснение
            float alpha = 0.5f;
            float beta = 0.5f;
            float gamma = 0.1f;
            float delta = 0.5f;

            Color elementColor = Color.FromArgb(78, 195, 88);

            SizeF[] levelSizes = new SizeF[hierarchy.LevelsCount];

            for (int i = 0; i < hierarchy.LevelsCount; i++)
            {
                levelSizes[i] = new SizeF(
                    hierarchy.Levels[i].Elements.Select(el => TextRenderer.MeasureText(el.Name, font).Width).Max() * (1 + alpha),
                    hierarchy.Levels[i].Elements.Select(el => TextRenderer.MeasureText(el.Name, font).Height).Max() * (1 + beta));
            }
            // элементы на разных уровнях могут иметь разную ширину, но высота у всех одинаковая
            levelSizes =
                levelSizes.Select(size => new SizeF(size.Width, levelSizes.Select(size2 => size2.Height).Max())).ToArray();

            // вычисляем ширину картинки по самому длинному ряду
            float[] levelWidths = new float[hierarchy.LevelsCount];
            for (int i = 0; i < hierarchy.LevelsCount; i++)
                levelWidths[i] = levelSizes[i].Width * (1 + 2 * gamma) * hierarchy.Levels[i].Count;

            SizeF pictureSize = new SizeF(
                levelWidths.Max(),
                levelSizes.Select(size => size.Height * (1 + 2 * delta)).Sum());

            Bitmap hierarchyBitmap = new Bitmap((int)Math.Round(pictureSize.Width), (int)Math.Round(pictureSize.Height));

            // двумерный список центров элементов иерархии
            List<List<PointF>> elementCenters = new List<List<PointF>>(hierarchy.LevelsCount);
            // отрисовываем элементы по уровням (i - номер отрисовываемого уровня, начиная с 0)
            for (int i = 0; i < hierarchy.LevelsCount; i++)
            {
                elementCenters.Add(new List<PointF>(hierarchy.Levels[i].Count));

                for (int j = 0; j < hierarchy.Levels[i].Count; j++)
                    elementCenters[i].Add(new PointF(
                        pictureSize.Width / hierarchy.Levels[i].Count * (j + 0.5f),
                        levelSizes[i].Height * (2 * delta + 1) * (i + 0.5f)));

            }

            // рисуем иерархию
            using (Graphics g = Graphics.FromImage(hierarchyBitmap))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                for (int i = 0; i < elementCenters.Count; i++)
                {
                    // сначала - горизонтальные соединительные линии
                    if (i > 0)
                        g.DrawLine(Pens.Black,
                            Math.Min(elementCenters[i - 1][0].X, elementCenters[i][0].X),
                            elementCenters[i][0].Y - levelSizes[i].Height * (0.5f + delta),
                            Math.Max(elementCenters[i - 1].Last().X, elementCenters[i].Last().X),
                            elementCenters[i][0].Y - levelSizes[i].Height * (0.5f + delta));

                    for (int j = 0; j < elementCenters[i].Count; j++)
                    {
                        // теперь вертикальные соединительные линии: вверх и вниз
                        if (i > 0)
                        {
                            g.DrawLine(Pens.Black, elementCenters[i][j].X, elementCenters[i][j].Y, elementCenters[i][j].X, elementCenters[i][j].Y - levelSizes[i].Height * (0.5f + delta));
                        }

                        if (i < hierarchy.LevelsCount - 1)
                        {
                            g.DrawLine(Pens.Black, elementCenters[i][j].X, elementCenters[i][j].Y, elementCenters[i][j].X, elementCenters[i][j].Y + levelSizes[i].Height * (0.5f + delta));

                        }

                        // наконец, сами элементы
                        g.FillRectangle(new SolidBrush(elementColor),
                            elementCenters[i][j].X - levelSizes[i].Width / 2,
                            elementCenters[i][j].Y - levelSizes[i].Height / 2,
                            levelSizes[i].Width,
                            levelSizes[i].Height);
                        g.DrawRectangle(Pens.Black, elementCenters[i][j].X - levelSizes[i].Width / 2,
                            elementCenters[i][j].Y - levelSizes[i].Height / 2,
                            levelSizes[i].Width,
                            levelSizes[i].Height);
                        Size textSize = TextRenderer.MeasureText(hierarchy.Levels[i].Elements[j].Name, font);
                        TextRenderer.DrawText(g, hierarchy.Levels[i].Elements[j].Name, font,
                            new Point((int)(elementCenters[i][j].X - textSize.Width / 2),
                            (int)(elementCenters[i][j].Y - textSize.Height / 2)), Color.Black, elementColor);
                    }
                }
            }

            return hierarchyBitmap;
        }

        /// <summary>
        /// Количество выставленных попарных суждений относительно
        /// указанного элемента.
        /// </summary>
        /// <param name="elem">Элемент, относительно которого считается
        /// количество выставленных попарных суждений.</param>
        /// <remarks>Если элемент не является сравнительным критерием, то
        /// возвращается значение -1.</remarks>
        internal static int GetCompleteComparionsNumber(Element elem)
        {
            if (elem.CriterionType != Criterions.comparative)
                return -1;

            int result = 0;

            for (int i = 0; i < elem.PairComparisons.Size; i++)
                for (int j = i + 1; j < elem.PairComparisons.Size; j++)
                    if (elem.PairComparisons[i, j] != Appraisals.undefined)
                        result++;

            return result;
        }

        /// <summary>
        /// Количество эквивалентностей среди выставленных попарных
        /// суждений относительно указанного элемента.
        /// </summary>
        /// <param name="elem">Элемент, относительно которого считается
        /// количество выставленных суждений об эквивалентности.</param>
        /// <remarks>Если элемент не является сравнительным критерием, то
        /// возвращается значение -1.</remarks>
        internal static int GetEquivalentComparisonsNumber(Element elem)
        {
            if (elem.CriterionType != Criterions.comparative)
                return -1;

            int result = 0;

            for (int i = 0; i < elem.PairComparisons.Size; i++)
                for (int j = i + 1; j < elem.PairComparisons.Size; j++)
                    if (elem.PairComparisons[i, j] == Appraisals.equivalent)
                        result++;

            return result;
        }

        /// <summary>
        /// Вычисляет коэффициент Кендалла-Смита по количеству циклических триад
        /// в графе и общему числу его вершин.
        /// </summary>
        /// <param name="c">Количество циклических триад в графе.</param>
        /// <param name="n">Количество вершин в графе.</param>
        internal static double GetKendallSmithCoeff(int c, int n)
        {
            return 1 - 24 * (double) c / (n * (n * n - 4 + 3 * (n % 2)));
        }
    }
}
