﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ZedGraph;
using Document;

namespace AHPManager
{
    public partial class ResultsForm : Form
    {
        private double[] valueVector;
        private string[] namesVector;
        private string projectName;
        private bool isPieChart = false;
        private MainForm form;

        private Hierarchy hierarchy;    // ссылка для иерархию (нужно для отчета)

        internal void SetParams(double[] eigenvector, string[] namesVector0)
        {
            valueVector = new double[eigenvector.Length];
            for (int i = 0; i < valueVector.Length; i++)
                valueVector[i] = eigenvector[i] * 100;
            namesVector = namesVector0;
        }

        public ResultsForm(string projectName0, MainForm form0, Hierarchy hierarchy)
        {
            form = form0;
            InitializeComponent();
            zedGraphCtrl_results.Name = projectName0;
            projectName = projectName0;
            this.hierarchy = hierarchy;
        }

        private void ResultsForm_Load(object sender, EventArgs e)
        {
            CreateGraph(zedGraphCtrl_results); // столбчатая диаграмма
        }

        /// <summary>
        /// Create graph function (construction graph)
        /// </summary>
        /// <param name="zg1"></param>
        private void CreateGraph(ZedGraphControl zg1)
        {
            // get a reference to the GraphPane
            GraphPane myPane = new GraphPane();
            Size size = new Size(zg1.Size.Width + 1, zg1.Size.Height);
            zg1.GraphPane = myPane;
            zg1.Size = size;

            // Set the Titles

            myPane.Title.Text = projectName;
            myPane.XAxis.Title.Text = "Варианты";
            myPane.YAxis.Title.Text = "Значение в %";

            // Make up some random data points

            string[] labels = namesVector;
            double[] y = valueVector;
            //double[] y2 = { 90, 100, 95, 35, 80, 35 };
            //double[] y3 = { 80, 110, 65, 15, 54, 67 };
            //double[] y4 = { 120, 125, 100, 40, 105, 75 };

            // Generate a red bar with "Curve 1" in the legend

            BarItem myBar = myPane.AddBar("", null, y, Color.Red);
            myBar.Bar.Fill = new Fill(Color.Red, Color.White, Color.Red);

            // Draw the X tics between the labels instead of 

            // at the labels

            myPane.XAxis.MajorTic.IsBetweenLabels = true;

            // Set the XAxis labels

            myPane.XAxis.Scale.TextLabels = labels;
            // Set the XAxis to Text type

            myPane.XAxis.Type = AxisType.Text;

            // Fill the Axis and Pane backgrounds

            myPane.Chart.Fill = new Fill(Color.White,
                  Color.FromArgb(255, 255, 166), 90F);
            myPane.Fill = new Fill(Color.FromArgb(250, 250, 255));

            // Tell ZedGraph to refigure the

            // axes since the data have changed

            zg1.AxisChange();
        }

        private void btn_BackToHierarch_Click(object sender, EventArgs e)
        {
            if (isPieChart == false)
            {
                CreatePieChartGraph(zedGraphCtrl_results);
            }
            else
            {
                CreateGraph(zedGraphCtrl_results);
                isPieChart = false;
            }
            zedGraphCtrl_results.Refresh();
        }

        private void btn_CloseWnd_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void SetSize()
        {
            zedGraphCtrl_results.Location = new Point(10, 10);
            // Leave a small margin around the outside of the control
            zedGraphCtrl_results.Size = new Size(this.ClientRectangle.Width - 20, this.ClientRectangle.Height - 80);
        }

        private void CreatePieChartGraph(ZedGraphControl zg1)
        {

            isPieChart = true;
            // get a reference to the GraphPane
            GraphPane myPane = new GraphPane();
            Size size = new Size(zg1.Size.Width + 1, zg1.Size.Height);
            zg1.GraphPane = myPane;
            zg1.Size = size;

            // Set the Titles
            myPane.Title.Text = projectName;

            string[] labels = namesVector;
            double[] y = valueVector;

            //myPane.AddPieSlices(y, labels);
            PieItem[] items = myPane.AddPieSlices(y, labels);

            for (int i = 0; i < items.Length; ++i)
            {
                items[i].Displacement = y[i] / 1000;
                items[i].Fill.Color = Color.FromArgb((i * 100 + 150) % 255, (i * 150) % 255, (i * 200 + 150) % 255);//(255-10*i, 10*i,  100+8*i);
            }

            // Tell ZedGraph to refigure the
            // axes since the data have changed
            zg1.AxisChange();
        }

        private void btn_SaveResults_Click_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);
            saveFileDialog.Filter = "Точечный рисунок (*.bmp)|*.bmp";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                Bitmap hierarchyBitmap = AuxiliaryClass.CreateHierarchyBitmap(hierarchy, 
                    new System.Drawing.Font("Microsoft Sans Serif",
                    10F, System.Drawing.FontStyle.Regular,
                    System.Drawing.GraphicsUnit.Point, ((byte)(204))));
                hierarchyBitmap.Save(saveFileDialog.FileName);
            }
        }

        private void btn_CreareReport_Click(object sender, EventArgs e)
        {
            ReportForm reportForm = new ReportForm(hierarchy);
            reportForm.ShowDialog();
        }
    }
}
