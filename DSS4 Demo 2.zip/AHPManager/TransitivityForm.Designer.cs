﻿namespace AHPManager
{
    partial class TransitivityForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbSaatyCR = new System.Windows.Forms.Label();
            this.lbSaatyCRValue = new System.Windows.Forms.Label();
            this.tlpMain = new System.Windows.Forms.TableLayoutPanel();
            this.grpCyclicTriads = new System.Windows.Forms.GroupBox();
            this.tlpCyclicTriads = new System.Windows.Forms.TableLayoutPanel();
            this.lbCyclicTriadsCount = new System.Windows.Forms.Label();
            this.lbCyclicTriadsCountValue = new System.Windows.Forms.Label();
            this.lbCyclicTriads = new System.Windows.Forms.ListBox();
            this.lbKendallSmithCoeff = new System.Windows.Forms.Label();
            this.lbKendallSmithCoeffValue = new System.Windows.Forms.Label();
            this.grpSaatyCR = new System.Windows.Forms.GroupBox();
            this.tlpMain.SuspendLayout();
            this.grpCyclicTriads.SuspendLayout();
            this.tlpCyclicTriads.SuspendLayout();
            this.grpSaatyCR.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbSaatyCR
            // 
            this.lbSaatyCR.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbSaatyCR.AutoSize = true;
            this.lbSaatyCR.Location = new System.Drawing.Point(6, 22);
            this.lbSaatyCR.Name = "lbSaatyCR";
            this.lbSaatyCR.Size = new System.Drawing.Size(25, 13);
            this.lbSaatyCR.TabIndex = 0;
            this.lbSaatyCR.Text = "ОС:";
            // 
            // lbSaatyCRValue
            // 
            this.lbSaatyCRValue.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lbSaatyCRValue.AutoSize = true;
            this.lbSaatyCRValue.Location = new System.Drawing.Point(261, 22);
            this.lbSaatyCRValue.Name = "lbSaatyCRValue";
            this.lbSaatyCRValue.Size = new System.Drawing.Size(28, 13);
            this.lbSaatyCRValue.TabIndex = 1;
            this.lbSaatyCRValue.Text = "0,00";
            // 
            // tlpMain
            // 
            this.tlpMain.ColumnCount = 1;
            this.tlpMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpMain.Controls.Add(this.grpCyclicTriads, 0, 0);
            this.tlpMain.Controls.Add(this.grpSaatyCR, 0, 1);
            this.tlpMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpMain.Location = new System.Drawing.Point(0, 0);
            this.tlpMain.Name = "tlpMain";
            this.tlpMain.RowCount = 2;
            this.tlpMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpMain.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tlpMain.Size = new System.Drawing.Size(304, 206);
            this.tlpMain.TabIndex = 3;
            // 
            // grpCyclicTriads
            // 
            this.grpCyclicTriads.Controls.Add(this.tlpCyclicTriads);
            this.grpCyclicTriads.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grpCyclicTriads.Location = new System.Drawing.Point(3, 3);
            this.grpCyclicTriads.Name = "grpCyclicTriads";
            this.grpCyclicTriads.Padding = new System.Windows.Forms.Padding(6);
            this.grpCyclicTriads.Size = new System.Drawing.Size(298, 143);
            this.grpCyclicTriads.TabIndex = 0;
            this.grpCyclicTriads.TabStop = false;
            this.grpCyclicTriads.Text = "Циклические триады";
            // 
            // tlpCyclicTriads
            // 
            this.tlpCyclicTriads.ColumnCount = 2;
            this.tlpCyclicTriads.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpCyclicTriads.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tlpCyclicTriads.Controls.Add(this.lbCyclicTriadsCount, 0, 0);
            this.tlpCyclicTriads.Controls.Add(this.lbCyclicTriadsCountValue, 1, 0);
            this.tlpCyclicTriads.Controls.Add(this.lbCyclicTriads, 0, 2);
            this.tlpCyclicTriads.Controls.Add(this.lbKendallSmithCoeff, 0, 1);
            this.tlpCyclicTriads.Controls.Add(this.lbKendallSmithCoeffValue, 1, 1);
            this.tlpCyclicTriads.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpCyclicTriads.Location = new System.Drawing.Point(6, 19);
            this.tlpCyclicTriads.Name = "tlpCyclicTriads";
            this.tlpCyclicTriads.RowCount = 3;
            this.tlpCyclicTriads.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tlpCyclicTriads.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tlpCyclicTriads.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpCyclicTriads.Size = new System.Drawing.Size(286, 118);
            this.tlpCyclicTriads.TabIndex = 0;
            // 
            // lbCyclicTriadsCount
            // 
            this.lbCyclicTriadsCount.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbCyclicTriadsCount.AutoSize = true;
            this.lbCyclicTriadsCount.Location = new System.Drawing.Point(3, 3);
            this.lbCyclicTriadsCount.Margin = new System.Windows.Forms.Padding(3);
            this.lbCyclicTriadsCount.Name = "lbCyclicTriadsCount";
            this.lbCyclicTriadsCount.Size = new System.Drawing.Size(168, 13);
            this.lbCyclicTriadsCount.TabIndex = 0;
            this.lbCyclicTriadsCount.Text = "Количество циклических триад:";
            // 
            // lbCyclicTriadsCountValue
            // 
            this.lbCyclicTriadsCountValue.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lbCyclicTriadsCountValue.AutoSize = true;
            this.lbCyclicTriadsCountValue.Location = new System.Drawing.Point(270, 3);
            this.lbCyclicTriadsCountValue.Margin = new System.Windows.Forms.Padding(3);
            this.lbCyclicTriadsCountValue.Name = "lbCyclicTriadsCountValue";
            this.lbCyclicTriadsCountValue.Size = new System.Drawing.Size(13, 13);
            this.lbCyclicTriadsCountValue.TabIndex = 1;
            this.lbCyclicTriadsCountValue.Text = "0";
            // 
            // lbCyclicTriads
            // 
            this.lbCyclicTriads.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tlpCyclicTriads.SetColumnSpan(this.lbCyclicTriads, 2);
            this.lbCyclicTriads.FormattingEnabled = true;
            this.lbCyclicTriads.HorizontalScrollbar = true;
            this.lbCyclicTriads.Location = new System.Drawing.Point(3, 41);
            this.lbCyclicTriads.Name = "lbCyclicTriads";
            this.lbCyclicTriads.Size = new System.Drawing.Size(280, 69);
            this.lbCyclicTriads.TabIndex = 2;
            this.lbCyclicTriads.SelectedIndexChanged += new System.EventHandler(this.lbCyclicTriads_SelectedIndexChanged);
            // 
            // lbKendallSmithCoeff
            // 
            this.lbKendallSmithCoeff.AutoSize = true;
            this.lbKendallSmithCoeff.Location = new System.Drawing.Point(3, 22);
            this.lbKendallSmithCoeff.Margin = new System.Windows.Forms.Padding(3);
            this.lbKendallSmithCoeff.Name = "lbKendallSmithCoeff";
            this.lbKendallSmithCoeff.Size = new System.Drawing.Size(167, 13);
            this.lbKendallSmithCoeff.TabIndex = 3;
            this.lbKendallSmithCoeff.Text = "Коэффициент Кендалла-Смита:";
            // 
            // lbKendallSmithCoeffValue
            // 
            this.lbKendallSmithCoeffValue.AutoSize = true;
            this.lbKendallSmithCoeffValue.Location = new System.Drawing.Point(270, 22);
            this.lbKendallSmithCoeffValue.Margin = new System.Windows.Forms.Padding(3);
            this.lbKendallSmithCoeffValue.Name = "lbKendallSmithCoeffValue";
            this.lbKendallSmithCoeffValue.Size = new System.Drawing.Size(13, 13);
            this.lbKendallSmithCoeffValue.TabIndex = 4;
            this.lbKendallSmithCoeffValue.Text = "0";
            // 
            // grpSaatyCR
            // 
            this.grpSaatyCR.AutoSize = true;
            this.grpSaatyCR.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.grpSaatyCR.Controls.Add(this.lbSaatyCRValue);
            this.grpSaatyCR.Controls.Add(this.lbSaatyCR);
            this.grpSaatyCR.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grpSaatyCR.Location = new System.Drawing.Point(3, 152);
            this.grpSaatyCR.Name = "grpSaatyCR";
            this.grpSaatyCR.Size = new System.Drawing.Size(298, 51);
            this.grpSaatyCR.TabIndex = 1;
            this.grpSaatyCR.TabStop = false;
            this.grpSaatyCR.Text = "Отношение согласованности";
            // 
            // TransitivityForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(304, 206);
            this.Controls.Add(this.tlpMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.MinimumSize = new System.Drawing.Size(320, 240);
            this.Name = "TransitivityForm";
            this.ShowInTaskbar = false;
            this.Text = "Согласованность";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.TransitivityForm_FormClosed);
            this.tlpMain.ResumeLayout(false);
            this.tlpMain.PerformLayout();
            this.grpCyclicTriads.ResumeLayout(false);
            this.tlpCyclicTriads.ResumeLayout(false);
            this.tlpCyclicTriads.PerformLayout();
            this.grpSaatyCR.ResumeLayout(false);
            this.grpSaatyCR.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbSaatyCR;
        private System.Windows.Forms.Label lbSaatyCRValue;
        private System.Windows.Forms.TableLayoutPanel tlpMain;
        private System.Windows.Forms.GroupBox grpCyclicTriads;
        private System.Windows.Forms.GroupBox grpSaatyCR;
        private System.Windows.Forms.TableLayoutPanel tlpCyclicTriads;
        private System.Windows.Forms.Label lbCyclicTriadsCount;
        private System.Windows.Forms.Label lbCyclicTriadsCountValue;
        private System.Windows.Forms.ListBox lbCyclicTriads;
        private System.Windows.Forms.Label lbKendallSmithCoeff;
        private System.Windows.Forms.Label lbKendallSmithCoeffValue;
    }
}