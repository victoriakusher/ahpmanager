﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace AHPManager
{
    public partial class LocalPrioritiesForm : Form
    {
        public LocalPrioritiesForm()
        {
            InitializeComponent();
        }

        /* Принимает массив данных для постоения диаграммы, отражающей локальные приоритеты
         * альтернатив относительно критерия. criterionName - название критерия, будет
         * отображаться вверху диаграммы, alternativeNames - названия альтернатив, задают
         * подписи у стоблцов, alternativeRanks - численные значения приоритетов. */
        public void AcceptData(string criterionName, string[] alternativeNames, double[] alternativeRanks)
        {
            localPrioritiesChart.Titles.Add("Критерий \"" + criterionName + "\""); // задаем заголовок

            // устанавливаем цвет линий сетки на светло-серый
            localPrioritiesChart.ChartAreas[0].AxisX.MajorGrid.LineColor = SystemColors.ControlLight;
            localPrioritiesChart.ChartAreas[0].AxisY.LineColor = SystemColors.ControlLight;

            // заносим данные на диаграмму
            for (int i = 0; i < alternativeNames.Length; i++)
            {
                localPrioritiesChart.Series[0].Points.Add(alternativeRanks[i]);
                localPrioritiesChart.Series[0].Points[i].AxisLabel = alternativeNames[i];
                localPrioritiesChart.Series[0].Points[i].Label = String.Concat((alternativeRanks[i] * 100).ToString("##"), "%");
            }
        }

        /* Принимает новый массив локальных приоритетов и изменяет в диаграмму в соответствии
         * с новыми данными. Заголовок диаграммы и подписи стоблцов не изменяются. */
        public void UpdateData(double[] newRanks)
        {
            // запоминаем названия стобцов
            string[] columnsNames = new string[newRanks.Length];
            for (int i = 0; i < newRanks.Length; i++)
                columnsNames[i] = localPrioritiesChart.Series[0].Points[i].AxisLabel;

            // удаляем столбцы, отображающие прежние веса
            localPrioritiesChart.Series[0].Points.Clear();

            // добавляем стобцы, отображающие новые веса
            for (int i = 0; i < newRanks.Length; i++)
            {
                localPrioritiesChart.Series[0].Points.Add(newRanks[i]);
                localPrioritiesChart.Series[0].Points[i].AxisLabel = columnsNames[i];
                localPrioritiesChart.Series[0].Points[i].Label = String.Concat((newRanks[i] * 100).ToString("##"), "%");
            }
        }

        private void LocalPrioritiesForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            /* При закрытии окна локальных приоритетов переменная localPrioritiesShown
             * должна принять значение false, иначе мы не сможем заново открыть окно
             * локальных приоритетов. Доступ к окну сравнений, из которого было вызвано
             * данное окно локальных приоритетов, осуществляется через свойство Owner. */
            AHPManager.CompareForm comparisonForm = Owner as AHPManager.CompareForm;
            comparisonForm.LocalPrioritiesWindow_Closed();
        }
    }
}
