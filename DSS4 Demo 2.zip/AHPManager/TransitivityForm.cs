﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Document;
using AHP;

namespace AHPManager
{
    public partial class TransitivityForm : Form
    {
        /// <summary>
        /// Значения случайных индексов согласованности для матриц размеров от 3x3
        /// до 9x9. Взяты из Т.Л. Саати "Принятие решений при зависимостях и обратных
        /// связях", М.: 2009, стр. 66.
        /// </summary>
        private readonly double[] randomIndeces = { 0.52, 0.89, 1.11, 1.25, 1.35, 1.40, 1.45, 1.49 };

        /// <summary>
        /// Критические значения для отношения согласованности. Взяты из Т.Л. Саати
        /// "Принятие решений при зависимостях и обратных связях", М.: 2009, стр. 66.
        /// </summary>
        private readonly double[] criticalValues = { 0.05, 0.08, 0.1, 0.1, 0.1, 0.1, 0.1 };

        /// <summary>
        /// Элемент иерархии, относительно которого рассматривается согласованность суждений.
        /// </summary>
        private Element element;

        /// <summary>
        /// Ссылка на компонент, представляющий граф предпочтений для альтернатив элемента element.
        /// </summary>
        private PreferenceGraphControl prGraph;

        /// <summary>
        /// Список циклических триад.
        /// </summary>
        private List<int[]> cyclicTriads;

        /// <summary>
        /// Выделенная циклическая триада.
        /// </summary>
        private int[] selectedCyclicTriad;

        /// <summary>
        /// Конструктор класса, в качестве параметра принимает элемент иерархии,
        /// относительно которого исследуется согласованность.
        /// </summary>
        /// <param name="el">Элемент, относительно которого исследуется согласованность.</param>
        /// <param name="graph">Ссылка на компонент, представляющий граф предпочтений для альтернатив
        /// элемента el.</param>
        public TransitivityForm(Element el, PreferenceGraphControl graph)
        {
            InitializeComponent();

            element = el;
            prGraph = graph;
            selectedCyclicTriad = null;

            UpdateData(el);
        }

        /// <summary>
        /// Этот метод следует вызывать при изменении исследуемых данных.
        /// </summary>
        /// <param name="el">Элемент иерархии, относительно которого исследуется согласованность.</param>
        public void UpdateData(Element el)
        {
            Scale scale = AuxiliaryClass.CreateScale(el, el.Hr);
            ComparisonMatrix matrix = el.PairComparisons;

            /* Отношение согласованности. */
            if (el.ScaleType == Scales.Saaty && el.UseClassicScaleParameters &&
                el.PairComparisons.Size > 2)
            {
                // для шкалы типа Саати считаем индекс согласованности
                Matrix m = new Matrix(matrix.Size);
                for (int i = 0; i < matrix.Size; i++)
                    for (int j = 0; j < matrix.Size; j++)
                        m[i, j] = (matrix[i, j] != Appraisals.undefined) ?
                            scale.Convert(matrix[i, j]) :
                            scale.Convert(Appraisals.equivalent);
                WeightsDerivingMethod wdm = new AHP.EigenvectorMethod();
                double[] w = wdm.GetWeights(m);
                double[] v = w.Select(x => Math.Pow(x, -1)).ToArray();
                
                // находим первое собственное число следующим образом:
                // A * w = lambda * w => lambda = (v * A * w)/n, где
                // v = (1/w)', n - длина вектора w
                double lambda = ((double[]) ((Matrix)v * m * ((Matrix)w).GetTransposed()))[0];
                lambda /= matrix.Size;
                double CI = (lambda - matrix.Size) / (matrix.Size - 1);
                double CR = CI / randomIndeces[matrix.Size - 3];

                grpSaatyCR.Visible = true;
                lbSaatyCRValue.Text = CR.ToString("0.00");
                lbSaatyCRValue.ForeColor = (CR < criticalValues[matrix.Size - 3]) ?
                    SystemColors.ControlText :
                    Color.Red;
                // эмпирическая рекомендация от Саати: если ОС больше критического значения,
                // но меньше 0.2, то суждения можно с натяжкой принять
                if (CR > criticalValues[matrix.Size - 3] && CR < 0.2)
                    lbSaatyCRValue.ForeColor = Color.DarkRed;
            }
            else
                // скрываем надписи об отношении согласованности
                grpSaatyCR.Visible = false;

            /* Циклические триады. */
            cyclicTriads = AuxiliaryClass.SearchForCyclicTriads(element);
            lbCyclicTriadsCountValue.Text = cyclicTriads.Count.ToString();
            // обновляем lbCyclicTriads
            lbCyclicTriads.Items.Clear();
            for (int i = 0; i < cyclicTriads.Count; i++)
                lbCyclicTriads.Items.Add(String.Join(" - ", 
                    cyclicTriads[i].Reverse().Select(cycleElement => element.Lv.LowerLevel.Elements[cycleElement].Name).ToArray()));
            // если циклических триад не обнаружено, то снимаем выделение цикла в графе представлений
            if (cyclicTriads.Count == 0)
                prGraph.CycleVertices = null;
            else if (selectedCyclicTriad != null)
            {
                /* Была выделена циклическая триада, смотрим, осталась ли она в новом списке. Если осталась,
                 * то ищем ее в новом списке циклических триад и выделяем ее в ListBox'е в окне исследования
                 * согласованности. Если нет, то снимаем выделение с графа предпочтений в окне сравнения
                 * альтернатив. */

                // ищем номер, который занимает наша циклическая триада в новом списке триад
                int i = 0;
                bool flag = false;  // нашли или нет

                while (i < cyclicTriads.Count && !flag)
                    if (selectedCyclicTriad.SequenceEqual(cyclicTriads[i]))
                        flag = true;
                    else
                        i++;

                if (flag)
                    lbCyclicTriads.SelectedIndex = i;
                else
                    prGraph.CycleVertices = null;
            }
            /* Коэффициент Кендалла-Смита. Отображается только в отсутствии
             * невыставленных суждений и суждений-эквивалентностей. */
            if (element.ComparisonsComplete &
                AuxiliaryClass.GetEquivalentComparisonsNumber(element) == 0)
            {
                lbKendallSmithCoeff.Visible = lbKendallSmithCoeffValue.Visible = true;
                lbKendallSmithCoeffValue.Text =
                    AuxiliaryClass.GetKendallSmithCoeff(cyclicTriads.Count, element.PairComparisons.Size).ToString("0.00");
            }
            else
                lbKendallSmithCoeff.Visible = lbKendallSmithCoeffValue.Visible = false;
        }

        private void TransitivityForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            /* При закрытии окна исследования транзитивности переменная transitivityShown
             * должна принять значение false, иначе мы не сможем заново открыть окно
             * исследования транзитивности. Доступ к окну сравнений, из которого было вызвано
             * данное окно исследования транзитивности, осуществляется через свойство Owner. */
            AHPManager.CompareForm comparisonForm = Owner as AHPManager.CompareForm;
            comparisonForm.TransitivityWindow_Closed();

            // снимаем выделение цикла в графе представлений
            prGraph.CycleVertices = null;
        }

        private void lbCyclicTriads_SelectedIndexChanged(object sender, EventArgs e)
        {
            // возможно, это событие вызовется, когда ни один элемент списка не выделен,
            // то есть SelectedIndex = -1
            if (lbCyclicTriads.SelectedIndex >= 0)
            {
                selectedCyclicTriad = cyclicTriads[lbCyclicTriads.SelectedIndex];
                prGraph.CycleVertices = selectedCyclicTriad;
            }
        }
    }
}
