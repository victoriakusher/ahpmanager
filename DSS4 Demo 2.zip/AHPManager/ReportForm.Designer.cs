﻿namespace AHPManager
{
    partial class ReportForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource2 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource3 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource4 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource5 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource6 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.HierarchySummaryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.LevelSummaryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ElementSummaryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.AlternativeSummaryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ElementValueSummaryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.PairComparisonSummaryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.reportViewer = new Microsoft.Reporting.WinForms.ReportViewer();
            this.LocalAlternativeSummaryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.HierarchySummaryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LevelSummaryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ElementSummaryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AlternativeSummaryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ElementValueSummaryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PairComparisonSummaryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LocalAlternativeSummaryBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // HierarchySummaryBindingSource
            // 
            this.HierarchySummaryBindingSource.DataMember = "HierarchySummary";
            // 
            // LevelSummaryBindingSource
            // 
            this.LevelSummaryBindingSource.DataMember = "LevelSummary";
            // 
            // ElementSummaryBindingSource
            // 
            this.ElementSummaryBindingSource.DataMember = "ElementSummary";
            // 
            // AlternativeSummaryBindingSource
            // 
            this.AlternativeSummaryBindingSource.DataMember = "AlternativeSummary";
            // 
            // ElementValueSummaryBindingSource
            // 
            this.ElementValueSummaryBindingSource.DataMember = "ElementValueSummary";
            // 
            // PairComparisonSummaryBindingSource
            // 
            this.PairComparisonSummaryBindingSource.DataMember = "PairComparisonSummary";
            // 
            // reportViewer
            // 
            this.reportViewer.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "ReportDemo_HierarchySummary";
            reportDataSource1.Value = this.HierarchySummaryBindingSource;
            reportDataSource2.Name = "ReportDemo_LevelSummary";
            reportDataSource2.Value = this.LevelSummaryBindingSource;
            reportDataSource3.Name = "ReportDemo_ElementSummary";
            reportDataSource3.Value = this.ElementSummaryBindingSource;
            reportDataSource4.Name = "ReportDemo_AlternativeSummary";
            reportDataSource4.Value = this.AlternativeSummaryBindingSource;
            reportDataSource5.Name = "ReportDemo_ElementValueSummary";
            reportDataSource5.Value = this.ElementValueSummaryBindingSource;
            reportDataSource6.Name = "ReportDemo_PairComparisonSummary";
            reportDataSource6.Value = this.PairComparisonSummaryBindingSource;
            this.reportViewer.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer.LocalReport.DataSources.Add(reportDataSource2);
            this.reportViewer.LocalReport.DataSources.Add(reportDataSource3);
            this.reportViewer.LocalReport.DataSources.Add(reportDataSource4);
            this.reportViewer.LocalReport.DataSources.Add(reportDataSource5);
            this.reportViewer.LocalReport.DataSources.Add(reportDataSource6);
            this.reportViewer.LocalReport.ReportEmbeddedResource = "AHPManager.Report.rdlc";
            this.reportViewer.Location = new System.Drawing.Point(0, 0);
            this.reportViewer.Name = "reportViewer";
            this.reportViewer.ShowBackButton = false;
            this.reportViewer.ShowDocumentMapButton = false;
            this.reportViewer.ShowRefreshButton = false;
            this.reportViewer.ShowStopButton = false;
            this.reportViewer.Size = new System.Drawing.Size(624, 442);
            this.reportViewer.TabIndex = 0;
            // 
            // LocalAlternativeSummaryBindingSource
            // 
            this.LocalAlternativeSummaryBindingSource.DataMember = "LocalAlternativeSummary";
            // 
            // ReportForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(624, 442);
            this.Controls.Add(this.reportViewer);
            this.MinimizeBox = false;
            this.Name = "ReportForm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Отчет";
            this.Load += new System.EventHandler(this.ReportForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.HierarchySummaryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LevelSummaryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ElementSummaryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AlternativeSummaryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ElementValueSummaryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PairComparisonSummaryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LocalAlternativeSummaryBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer;
        private System.Windows.Forms.BindingSource HierarchySummaryBindingSource;
        private System.Windows.Forms.BindingSource LevelSummaryBindingSource;
        private System.Windows.Forms.BindingSource ElementSummaryBindingSource;
        private System.Windows.Forms.BindingSource AlternativeSummaryBindingSource;
        private System.Windows.Forms.BindingSource ElementValueSummaryBindingSource;
        private System.Windows.Forms.BindingSource PairComparisonSummaryBindingSource;
        private System.Windows.Forms.BindingSource LocalAlternativeSummaryBindingSource;
    }
}