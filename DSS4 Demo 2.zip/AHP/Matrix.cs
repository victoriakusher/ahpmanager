﻿namespace AHP
{
    /// <summary>
    /// Класс, описывающий вещественную матрицу.
    /// </summary>
    public class Matrix
    {
        /// <summary>
        /// Содержимое матрицы.
        /// </summary>
        protected double[,] contents;
        /// <summary>
        /// Размерности матрицы.
        /// </summary>
        protected int matrixRows, matrixColumns;

        /// <summary>
        /// Конструктор, позволяющий создать матрицу с указанным количеством
        /// строк и столбцов.
        /// </summary>
        /// <param name="rowsNumber">Количество строк.</param>
        /// <param name="columnsNumber">Количество столбцов.</param>
        public Matrix(int rowsNumber, int columnsNumber)
        {
            contents = new double[rowsNumber, columnsNumber];
            matrixRows = rowsNumber;
            matrixColumns = columnsNumber;
        }

        /// <summary>
        /// Конструктор, позволяющий создать квадратную матрицу заданного размера.
        /// </summary>
        /// <param name="size">Размер создаваемой матрицы.</param>
        public Matrix(int size)
        {
            contents = new double[size, size];
            matrixRows = matrixColumns = size;
        }

        /// <summary>
        /// Конструктор копирования.
        /// </summary>
        public Matrix(Matrix original)
        {
            contents = original.contents;
            matrixColumns = original.matrixColumns;
            matrixRows = original.matrixRows;
        }

        /// <summary>
        /// Количество строк в матрице.
        /// </summary>
        public int Rows
        {
            get { return matrixRows; }
        }

        /// <summary>
        /// Количество столбцов в матрице.
        /// </summary>
        public int Columns
        {
            get { return matrixColumns; }
        }

        /// <summary>
        /// Является ли матрица квадратной.
        /// </summary>
        public bool IsSquared
        {
            get { return (this.Rows == this.Columns); }
        }

        /// <summary>
        /// Индексатор класса, позволяет считывать и записывать элементы
        /// матрицы.
        /// </summary>
        /// <param name="i">Номер строки, содержащей элемент.</param>
        /// <param name="j">Номер столбца, содержащего элемент.</param>
        /// <returns>Значение, содержащееся в заданном элементе матрицы.</returns>
        public virtual double this[int i, int j]
        {
            get { return contents[i, j]; }
            set { contents[i, j] = value; }
        }

        /// <summary>
        /// Перегруженный оператор сложения для вещественных матриц. При
        /// несовпадении размерностей генерируется исключение класса
        /// UnproperMatrixDimensions.
        /// </summary>
        /// <param name="left">Левое слагаемое.</param>
        /// <param name="right">Правое слагаемое.</param>
        /// <returns>Возвращает сумму матриц-слагаемых.</returns>
        public static Matrix operator +(Matrix left, Matrix right)
        {
            if (left.Rows == right.Rows && left.Columns == right.Columns)
            {
                Matrix sum = new Matrix(left.Rows, left.Columns);
                for (int i = 0; i < sum.Rows; i++)
                    for (int j = 0; j < sum.Columns; j++)
                        sum[i, j] = left[i, j] + right[i, j];
                return sum;
            }
            else
            {
                UnproperMatrixDimensions exception = new UnproperMatrixDimensions();
                throw exception;
            }
        }

        /// <summary>
        /// Перегруженный оператор умножения вещественного числа на матрицу.
        /// </summary>
        /// <param name="left">Множитель-число.</param>
        /// <param name="right">Множитель-матрица.</param>
        /// <returns>Покомнонентное произведение числа на элементы матрицы.</returns>
        public static Matrix operator *(double left, Matrix right)
        {
            Matrix product = new Matrix(right.Rows, right.Columns);

            for (int i = 0; i < right.Rows; i++)
                for (int j = 0; j < right.Columns; j++)
                    product[i, j] = left * right[i, j];

            return product;
        }

        /// <summary>
        /// Перегруженный оператор умножения матрицы на вещественное число.
        /// </summary>
        /// <param name="left">Множитель-матрица.</param>
        /// <param name="right">Множитель-число.</param>
        /// <returns>Покомпонентное произведения числа на элементы матрицы.</returns>
        public static Matrix operator *(Matrix left, double right)
        {
            return right * left;
        }

        /// <summary>
        /// Перегруженный оператор умножения матриц друг на друга. При несовпадении
        /// размерностей генерируется исключение класса UnproperMatrixDimensions.
        /// </summary>
        /// <param name="left">Левый множитель-матрица.</param>
        /// <param name="right">Правый множитель-матрица.</param>
        /// <returns>Матрица - результат произведения.</returns>
        public static Matrix operator *(Matrix left, Matrix right)
        {
            if (left.Columns == right.Rows)
            {
                Matrix product = new Matrix(left.Rows, right.Columns);

                for (int i = 0; i < left.Rows; i++)
                    for (int j = 0; j < right.Columns; j++)
                        for (int k = 0; k < left.Columns; k++)
                            product[i, j] += left[i, k] * right[k, j];

                return product;
            }
            else
            {
                UnproperMatrixDimensions exception = new UnproperMatrixDimensions();
                throw exception;
            }
        }

        /// <summary>
        /// Возвращает результат транспонирования данной матрицы.
        /// </summary>
        /// <returns>Транспонированная матрица.</returns>
        public Matrix GetTransposed()
        {
            Matrix transposed = new Matrix(this.Columns, this.Rows);

            for (int i = 0; i < this.Rows; i++)
                for (int j = 0; j < this.Columns; j++)
                    transposed[j, i] = contents[i, j];

            return transposed;
        }

        /// <summary>
        /// Возвращает сумму элементов строки с указанным номером.
        /// </summary>
        /// <param name="rowNumber">Строка, элементы которой 
        /// суммируются.</param>
        public double RowSum(int rowNumber)
        {
            double sum = 0;

            for (int i = 0; i < Columns; i++)
                sum += this[rowNumber, i];

            return sum;
        }

        /// <summary>
        /// Возвращает сумму элементов столбца с указанным номером.
        /// </summary>
        /// <param name="columnNumber">Столбец, элементы которого 
        /// суммируются.</param>
        public double ColumnSum(int columnNumber)
        {
            double sum = 0;

            for (int i = 0; i < Rows; i++)
                sum += this[i, columnNumber];

            return sum;
        }

        /// <summary>
        /// Возвращает матрицу, в которой на заданную позицию добавлены
        /// одна строка и один столбец. Добавленные элементы инициализируются
        /// указанным значением.
        /// </summary>
        /// <param name="index">Номер позиции, в которую добавляются строка и
        /// столбец.</param>
        /// <param name="newElementValue">Значение, которым инициализируются
        /// добавленные элементы.</param>
        public Matrix Expand(int index, double newElementValue)
        {
            Matrix expanded = new Matrix(this.Rows + 1, this.Columns + 1);

            /* Копируем элементы исходной матрицы в расширенную. */
            for (int i = 0; i < index; i++)
                for (int j = 0; j < index; j++)
                    expanded[i, j] = this[i, j];

            for (int i = 0; i < index; i++)
                for (int j = index; j < Columns; j++)
                    expanded[i, j + 1] = this[i, j];

            for (int i = index; i < Rows; i++)
                for (int j = 0; j < index; j++)
                    expanded[i + 1, j] = this[i, j];

            for (int i = index; i < Rows; i++)
                for (int j = index; j < Columns; j++)
                    expanded[i + 1, j + 1] = this[i, j];

            /* Заполняем новый столбец и новую строку элементами 
             * newElementValue. */
            for (int i = 0; i < Rows + 1; i++)
            {
                expanded[i, index] = newElementValue;
            }
            for (int j = 0; j < Columns + 1; j++)
            {
                expanded[index, j] = newElementValue;
            }

            return expanded;
        }

        /// <summary>
        /// Возвращает матрицу без строки и стоблца с заданным номером.
        /// </summary>
        /// <param name="index">Номер убираемых строки и столбца.</param>
        public Matrix Reduce(int index)
        {
            Matrix Reduced = new Matrix(this.Rows - 1, this.Columns - 1);

            for (int i = 0; i < index; i++)
                for (int j = 0; j < index; j++)
                    Reduced[i, j] = this[i, j];

            for (int i = index + 1; i < Rows; i++)
                for (int j = 0; j < index; j++)
                    Reduced[i - 1, j] = this[i, j];

            for (int i = 0; i < index; i++)
                for (int j = index + 1; j < Columns; j++)
                    Reduced[i, j - 1] = this[i, j];

            for (int i = index + 1; i < Rows; i++)
                for (int j = index + 1; j < Columns; j++)
                    Reduced[i - 1, j - 1] = this[i, j];

            return Reduced;
        }

        /// <summary>
        /// Перегруженный оператор явного преобразования одноэлементной 
        /// матрицы в вещественное число. Если преобразуемая матрица не
        /// является одноэлементной, то генерируется исключение класса
        /// UnproperMatrixDimensions.
        /// </summary>
        public static explicit operator double(Matrix matrix)
        {
            if (matrix.Rows == matrix.Columns && matrix.Rows == 1)
            {
                return matrix[0, 0];
            }
            else
            {
                UnproperMatrixDimensions exception = 
                    new UnproperMatrixDimensions();
                throw exception;
            }
        }

        /// <summary>
        /// Перегруженный оператор явного преобразования массива вещественных
        /// чисел в вектор-строку.
        /// </summary>
        public static explicit operator Matrix(double[] array)
        {
            Matrix result = new Matrix(1, array.Length);
            for (int j = 0; j < array.Length; j++)
                result[0, j] = array[j];
            return result;
        }

        /// <summary>
        /// Перегруженный оператор явного преобразования матрицы, состоящей
        /// из одной строки (или столбца) в массив вещественных чисел. Если
        /// обе размерности матрицы отличны от единицы, то генерируется
        /// исключение класса UnproperMatrixDimensions.
        /// </summary>
        public static explicit operator double[](Matrix matrix)
        {
            if (matrix.Rows == 1)
            {
                double[] result = new double[matrix.Columns];
                for (int j = 0; j < matrix.Columns; j++)
                    result[j] = matrix[0, j];
                return result;
            }
            else if (matrix.Columns == 1)
            {
                double[] result = new double[matrix.Rows];
                for (int i = 0; i < matrix.Rows; i++)
                    result[i] = matrix[i, 0];
                return result;
            }
            else
            {
                UnproperMatrixDimensions exception = new UnproperMatrixDimensions();
                throw exception;
            }
        }

        /// <summary>
        /// Возвращает нормализованный собственный вектор. 
        /// </summary>
        /// <param name="iterations">количество итераций</param>
        public double[] GetEigenvector(int iterations)
        {
            double[] eigenvector = null;
            // собственный вектор вычисляется только для квадратной матрицы
            if (IsSquared)
            {
                eigenvector = new double[Rows];
                Matrix temp = new Matrix(this);
                // возводим матрицу в большую степень, складываем строки и нормализуем
                for (int i = 0; i < iterations; i++)
                    temp = temp * this;
                // считаем построчные суммы
                double sum = 0;
                for (int i = 0; i < Rows; i++)
                {
                    eigenvector[i] = temp.RowSum(i);
                    sum += eigenvector[i];
                }
                // нормируем
                for (int i = 0; i < Rows; i++)
                    eigenvector[i] /= sum;
            }
            return eigenvector;
        }
    }
}
