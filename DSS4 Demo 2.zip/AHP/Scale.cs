﻿using System;
using System.Collections.Generic;
using System.Text;
using Document;

namespace AHP
{
    /// <summary>
    /// Абстрактный класс - основа остальных классов-шкал. Содержит
    /// единственный виртуальный метод Convert, который производит
    /// преобразование пользовательской оценки в значение шкалы.
    /// </summary>
    public abstract class Scale
    {
        /// <summary>
        /// Преобразует пользовательскую оценку в значение шкалы.
        /// </summary>
        public abstract double Convert(double userAppraisal);

        /// <summary>
        /// Флаг: использовать ли стандартные параметры для шкалы.
        /// </summary>
        public abstract bool UseDefaultParameters { get; set; }

        /// <summary>
        /// Массив стандартных параметров для шкалы (едины для всех
        /// экземпляров класса).
        /// </summary>
        public static double[] DefaultScaleParameters { get; set; }
        /// <summary>
        /// Массив параметров для данного экземпляра шкалы.
        /// </summary>
        public abstract double[] CustomScaleParameters { get; set; }
    }

    /// <summary>
    /// Определяет шкалу типа шкалы Саати.
    /// </summary>
    public class SaatyScale : Scale
    {
        /// <summary>
        /// Значение по умолчанию параметра масштаба для шкалы Саати.
        /// Инициализируется значением 2.
        /// </summary>
        static private double defaultX = 2;

        /// <summary>
        /// Параметр масштаба.
        /// </summary>
        private double x;
        /// <summary>
        /// Флаг: используется ли параметр по умолчанию?
        /// </summary>
        private bool useDefaultParameter;

        /// <summary>
        /// Свойство для чтения и записи параметра по умолчанию для шкалы типа
        /// Саати.
        /// </summary>
        /// <remarks>В массиве должно быть по крайней мере одно значение, 
        /// которое интерпретируется как параметр масштаба шкалы, остальные
        /// значения игнорируются. При этом значение этого параметра должно
        /// быть положительным и таким, что 1 - 4x > 0. При невыполнении этих
        /// условий генерируется исключение вида IncorrectScaleParameter.
        /// </remarks>
        public static new double[] DefaultScaleParameters
        {
            get
            {
                double[] result = new double[1];
                result[0] = defaultX;
                return result;
            }
            set
            {
                if (value.Length >= 1 && value[0] > 0)
                    defaultX = value[0];
                else
                    throw new IncorrectScaleParameter();
            }
        }

        /// <summary>
        /// Свойство для чтения и записи параметра для шкалы типа Саати.
        /// </summary>
        /// <remarks>В массиве должно быть по крайней мере одно значение, 
        /// которое интерпретируется как параметр масштаба шкалы, остальные
        /// значения игнорируются. При этом значение этого параметра должно
        /// быть положительным и таким, что 1 - 4x > 0. При невыполнении этих
        /// условий генерируется исключение вида IncorrectScaleParameter.
        /// </remarks>
        public override double[] CustomScaleParameters
        {
            get
            {
                double[] result = new double[1];
                result[0] = x;
                return result;
            }
            set
            {
                if (value.Length >= 1 && value[0] > 0)
                    x = value[0];
                else
                    throw new IncorrectScaleParameter();
            }
        }

        /// <summary>
        /// Флаг: используется ли параметр по умолчанию.
        /// </summary>
        /// <remarks>При присваивании значения true параметр
        /// шкалы приравнивается к значению по умолчанию.</remarks>
        public override bool UseDefaultParameters
        {
            get { return useDefaultParameter; }
            set
            {
                if (value) 
                    x = defaultX;
                useDefaultParameter = value;
            }
        }

        /// <summary>
        /// Конструктор по умолчанию, в качестве параметра
        /// шкалы используются значение по умолчанию.
        /// </summary>
        public SaatyScale()
        {
            useDefaultParameter = true;
        }

        /// <summary>
        /// Конструктор, позволяющий задать параметр шкалы.
        /// </summary>
        /// <param name="scale">Параметр масштаба.</param>
        /// <remarks>При указании некорректных параметров генерируется
        /// исключение вида IncorrectScaleParameter.</remarks>
        public SaatyScale(double scale)
        {
            // параметр масштаба должен быть положительным
            if (x > 0)
            {
                x = scale;
                useDefaultParameter = false;
            }
            else 
                throw new IncorrectScaleParameter();
        }

        /// <summary>
        /// Преобразует пользовательскую оценку в значение шкалы.
        /// </summary>
        public override double Convert(double userAppraisal)
        {
            return (!useDefaultParameter) ?
                Math.Pow((x * Math.Abs(userAppraisal) + 1), Math.Sign(userAppraisal)) :
                Math.Pow((defaultX * Math.Abs(userAppraisal) + 1), Math.Sign(userAppraisal));
        }
    }
}
