﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AHP
{
    /// <summary>
    /// Абстрактрый класс для описания методов получения массива относительных 
    /// приоритетов из заданных численных значений (весов). 
    /// </summary>
    public abstract class WeightsTransformationMethod
    {
        /// <summary>
        /// Возвращает массив относительных приоритетов, полученный из массива
        /// соответствующих сравниваемым объектам численных значений (весов).
        /// </summary>
        /// <param name="initialWeights">Массив численных значений 
        /// (весов).</param>
        /// <param name="parameters">Массив параметров метода.</param>
        public abstract double[] GetWeights(double[] initialWeights, 
            params object[] parameters);
    }

    /// <summary>
    /// Описывает метод получения относительных приоритетов из заданных
    /// численных значений, при котором большие значения весов соответствуют
    /// большим приоритетам.
    /// </summary>
    public class AscendingWeightsMethod : WeightsTransformationMethod
    {
        /// <summary>
        /// Возвращает массив относительных приоритетов, полученный из массива
        /// соответствующих сравниваемых объектам численных значений (весов).
        /// </summary>
        /// <param name="initialWeights">Массив численных значений
        /// (весов).</param>
        /// <param name="parameters">Массив параметров метода.</param>
        public override double[] GetWeights(double[] initialWeights, 
            params object[] parameters)
        {
            double[] result = initialWeights.Clone() as double[];

            /* Если все веса нулевые, то считаем приоритеты элементов равными. */
            if (initialWeights.All(weight => (weight == 0)))
            {
                result = result.Select(weight => 
                    1 / (double) initialWeights.Length).ToArray();
                return result;
            }
            /* Если все указанные пользователем веса положительные, то просто
             * их нормируем. Если среди них есть отрицательные значения, то 
             * прибавляем ко всем весам некую константу такую, чтобы веса стали
             * положительными. */
            if (result.Any(weight => weight < 0))
                /* Здесь в качестве константы, прибавляемой к весам, берется
                 * удвоенный модуль наименьшего из их. */
                result = result.Select(
                    weight => weight + 2 * Math.Abs(result.Min())).ToArray();
            /* Номируем. */
            result = result.Select(weight => weight / result.Sum()).ToArray();

            return result;
        }
    }

    /// <summary>
    /// Описывает метод получения относительных приоритетов из заданных
    /// численных значений, при котором меньшие значения весов соответствуют
    /// большим приоритетам.
    /// </summary>
    public class DescendingWeightsMethod : WeightsTransformationMethod
    {
        /// <summary>
        /// Возвращает массив относительных приоритетов, полученный из массива
        /// соответствующих сравниваемых объектам численных значений (весов).
        /// </summary>
        /// <param name="initialWeights">Массив численных значений 
        /// (весов).</param>
        /// <param name="parameters">Массив параметров метода.</param>
        public override double[] GetWeights(double[] initialWeights, 
            params object[] parameters)
        {
            double[] result = initialWeights.Clone() as double[];

            /* Если все веса нулевые, то считаем приоритеты элементов 
             * равными. */
            if (initialWeights.All(weight => (weight == 0)))
            {
                result = result.Select(weight => 
                    1 / (double)initialWeights.Length).ToArray();
                return result;
            }
            /* Если все указанные пользователем веса положительные, то
             * инвертируем их, а затем нормируем. Если среди них есть
             * отрицательные значения, то прибавляем ко всем весам некую
             * константу такую, чтобы веса стали положительными. */
            if (result.Any(weight => weight < 0))
                /* Здесь в качестве константы, прибавляемой к весам, берется
                 * удвоенный модуль наименьшего из их. */
                result = result.Select(
                    weight => weight + 2 * Math.Abs(result.Min())).ToArray();
            /* Возможно, после прибавления константы среди получившихся весов
             * остался нуль. При инвертировании он даст бесконечность, поэтому
             * дополнительно прибавим к весам наименьший положительный вес. */
            if (result.Any(weight => weight == 0))
            {
                // запрос на получение положительных весов
                var positiveWeights = from w in result  
                                      where w > 0
                                      select w;
                result = result.Select(
                    weight => weight + positiveWeights.Min()).ToArray();
            }
            /* Инвертируем и нормируем. */
            result = result.Select(weight => 1 / weight).ToArray();
            result = result.Select(weight => weight / result.Sum()).ToArray();

            return result;
        }
    }
}
