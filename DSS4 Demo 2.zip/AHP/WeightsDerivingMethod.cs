﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AHP
{
    /// <summary>
    /// Абстрактный класс для описания методов получения массива
    /// относительных приоритетов из матрицы попарных сравнений.
    /// </summary>
    public abstract class WeightsDerivingMethod
    {
        /// <summary>
        /// Возвращает массив относительных приоритетов, которые получены 
        /// из матрицы попарных сравнений.
        /// </summary>
        /// <param name="pairComparisonsMatrix">Матрица попарных сравнений.</param>
        public abstract double[] GetWeights(Matrix pairComparisonsMatrix);
    }

    /// <summary>
    /// Описывает метод собственного вектора для получения массива
    /// относительных приоритетов из матрицы попарных сравнений.
    /// </summary>
    public class EigenvectorMethod : WeightsDerivingMethod
    {
        /// <summary>
        /// Возвращает массив относительных приоритетов, полученный методом
        /// собственного вектора из матрицы попарных сравнений.
        /// </summary>
        /// <param name="pairComparisonsMatrix">Матрица попарных сравнений.</param>
        public override double[] GetWeights(Matrix pairComparisonsMatrix)
        {
            return pairComparisonsMatrix.GetEigenvector(20);
        }
    }
}
