﻿using System;

namespace AHP
{
    /// <summary>
    /// Класс исключений, генерирующихся при несовпадении размерностей
    /// матриц (например, при сложении или умножении).
    /// </summary>
    public class UnproperMatrixDimensions : Exception
    {
    }

    /// <summary>
    /// Класс исключений, генерирующихся при неправильном значении параметра
    /// шкалы.
    /// </summary>
    public class IncorrectScaleParameter : Exception
    {
    }
}