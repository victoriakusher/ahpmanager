﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AHP;

namespace AHP
{
    /// <summary>
    /// Описывает узел иерархической структуры задачи.
    /// </summary>
    public class Node
    {
        /// <summary>
        /// Описывает типы узлов иерархической структуры задачи
        /// (соответствуют типам критериев).
        /// </summary>
        public enum NodeTypes
        {
            quantitative,       // количественный критерий
            comparative         // сравнительный критерий
        }

        /// <summary>
        /// Тип узла (соответствует типу критерия).
        /// </summary>
        public NodeTypes type;
        /// <summary>
        /// Ссылка на экземпляр класса WeightsDerivingMethod для вычисления
        /// относительных приоритетов по матрице попарных сравнений.
        /// </summary>
        public WeightsDerivingMethod wdm;
        /// <summary>
        /// Ссылка на экземляр класса Scale, представляющего используемую в
        /// сравнительных критериях шкалу.
        /// </summary>
        public Scale scale;
        /// <summary>
        /// Ссылка на экземпляр класса WeightsTransformationMethod для вычисления
        /// относительных приоритетов по заданным пользователем числовым значаниям
        /// (весам).
        /// </summary>
        public WeightsTransformationMethod wtm;
        /// <summary>
        /// Ссылка на экземпляр класса AHP.Matrix, представляющий матрицу попарных
        /// сравнений в установленной шкале.
        /// </summary>
        public Matrix comparisonsMatrix;
        /// <summary>
        /// Ссылка на массив, представляющий выставленные пользователем числовые
        /// значения (веса) альтернатив.
        /// </summary>
        public double[] weights;
        /// <summary>
        /// Ссылка на массив, хранящий вычисленные локальные приоритеты.
        /// </summary>
        public double[] localPriorities;
        /// <summary>
        /// Ссылка на массив для временного хранения приоритетов при их синтезе.
        /// </summary>
        public double[] cachedPriorities;
        /// <summary>
        /// Флаг, указывающий на необходимость пересчета локальных приоритетов.
        /// </summary>
        public bool recalculationRequired;
        /// <summary>
        /// Количество альтернатив на лежащем ниже уровне иерархии. Свойство 
        /// только для чтения.
        /// </summary>
        public int Capacity
        {
            get
            {
                switch (type)
                {
                    case NodeTypes.quantitative:
                        return weights.Length;
                    case NodeTypes.comparative:
                        return comparisonsMatrix.Columns;
                }
                return 0;
            }
        }

        /// <summary>
        /// Конструктор класса. В качестве аргументов принимает количество узлов (элементов)
        /// на нижнем уровне и тип узла.
        /// </summary>
        /// <param name="alternativesCount">Количество узлов на нижнем уровне.</param>
        /// <param name="nodeType">Тип узла.</param>
        /// <param name="parameters">Дополнительные параметры: для узлов, представляющих
        /// количественные критерии  - ссылка на экземпляр класса, производного от
        /// WeightsTransformationMethod, для узлов, представляющих сравнительные критерии 
        ///  - ссылка на экземпляр класса, производного от WeightsDerivingMethod, и 
        /// ссылка на экземпляр класса, производного от Scale.
        /// </param>
        public Node(int alternativesCount, NodeTypes nodeType, params object[] parameters)
        {
            type = nodeType;
            // заполняем поля
            switch (type)
            {
                case NodeTypes.quantitative:
                    wtm = parameters[0] as WeightsTransformationMethod;
                    weights = new double[alternativesCount];
                    wdm = null;
                    scale = null;
                    comparisonsMatrix = null;
                    break;
                case NodeTypes.comparative:
                    wdm = parameters[0] as WeightsDerivingMethod;
                    scale = parameters[1] as Scale;
                    comparisonsMatrix = new Matrix(alternativesCount);
                    wtm = null;
                    weights = null;
                    break;
            }
            localPriorities = new double[alternativesCount];
            cachedPriorities = null;
            /* Так как после заполнения полей локальные приоритеты еще не вычислены, то
             * ставим recalculationRequired равным true. */
            recalculationRequired = true;
        }

        /// <summary>
        /// Возвращает матрицу - результат поэлементного применения указанной шкалы
        /// к указанной матрице попарных сравнений.
        /// </summary>
        /// <param name="M">Матрица попарных сравнений.</param>
        /// <param name="sc">Применяемая шкала.</param>
        public Matrix ApplyScale(Matrix M, Scale sc)
        {
            Matrix result = new Matrix(M.Rows, M.Columns);
            for (int i = 0; i < M.Rows; i++)
                for (int j = 0; j < M.Columns; j++)
                    result[i, j] = sc.Convert(M[i, j]);
            return result;
        }

        /// <summary>
        /// Вычисляет локальные приоритеты узлов на нижнем уровне в соответствии
        /// с типом узла.
        /// </summary>
        public void CalculateLocalPriorities()
        {
            if (recalculationRequired)
            {
                switch (type)
                {
                    case NodeTypes.quantitative:
                        localPriorities = wtm.GetWeights(weights);
                        break;
                    case NodeTypes.comparative:
                        localPriorities = wdm.GetWeights(ApplyScale(comparisonsMatrix, scale));
                        break;
                }
                recalculationRequired = false;
            }
        }
    }

    /// <summary>
    /// Описывает иерархическую структуру задачи.
    /// </summary>
    public class HierarchialStructure
    {
        /// <summary>
        /// Список элементов иерархии - экземпляров класса Node, составляющих
        /// иерархическую структуру задачи.
        /// </summary>
        public List<List<Node>> nodes;

        /// <summary>
        /// Конструктор класса по умолчанию.
        /// </summary>
        public HierarchialStructure()
        {
            nodes = new List<List<Node>>();
        }

        /// <summary>
        /// Вычисляет приоритеты альтернатив по отношению к элементу в фокусе
        /// иерархии.
        /// </summary>
        /// <returns>Вектор приоритетов альтернатив.</returns>
        public double[] GetPriorities()
        {
            // вычисляем локальные приоритеты узлов
            foreach (List<Node> nodeLevel in nodes)
                foreach (Node node in nodeLevel)
                   node.CalculateLocalPriorities();

            /* Возможно, в нашей иерархии всего два уровня - один уровень с альтернативами
             * и один уровень, содержащий только фокус иерархии. Тогда нет необходимости
             * запускать процесс синтеза приоритетов, достаточно просто выдать содержимое поля
             * localPriorities узла в фокусе иерархии. */
            if (nodes.Count == 1)
                return nodes[0][0].localPriorities;

            /* Примечание: в HierarchialStructure не заносится уровень альтернатив, поэтоу
             * если в исходной иерархии было два уровня, то в соответствующем экземпляре
             * HierarchialStructure будет один. */

            /* В иерархии больше двух уровней, поэтому копируем содержимое массивов 
             * localPriorities в массивы cachedPriorities для узлов нижнего уровня. */
            foreach (Node node in nodes[nodes.Count - 1])
                node.cachedPriorities = node.localPriorities;

            /* Если в иерархии больше двух уровней, то двигаемся по иерархии снизу вверх 
             * (от нижних уровней с большими номерами к высшим уровням с меньшими номерами). 
             * Начинаем с уровня nodes.Count - 1, так как синтезируем приоритеты узлов на 
             * нижнем (начальном) уровне относительно узлов уровнем выше. Номер этого уровня 
             * на единицу меньше номера нижележащего уровня. */ 
            for (int i = nodes.Count - 1; i > 0; i--)
            {
                foreach (Node node in nodes[i - 1])
                {
                    // формируем матрицу X = (X_1 | X_2 | ... | X_n)
                    Matrix X = new Matrix(nodes.Last()[0].localPriorities.Length, node.Capacity);
                    for (int j = 0; j < nodes.Last()[0].localPriorities.Length; j++)
                        // заполняем столбец X_j
                        for (int k = 0; k < node.Capacity; k++)
                            X[j, k] = nodes[i][k].cachedPriorities[j];
                    // формируем вектор Y
                    Matrix Y = (Matrix)node.localPriorities;
                    Y = Y.GetTransposed();
                    node.cachedPriorities = (double[])(X * Y);
                }
            }

            return nodes[0][0].cachedPriorities;
        }
    }
}
