﻿using System;
using System.Globalization;

namespace Document
{
    /// <summary>
    /// Описывает особые значения попарных оценок: значение для
    /// эквивалентности и значение, соответствующее невыставленной
    /// оценке.
    /// </summary>
    public static class Appraisals
    {
        public static readonly int equivalent = 0;
        public static readonly int undefined = 10;
    }

    /// <summary>
    /// Представляет матрицу для хранения попарных оценок.
    /// </summary>
    [Serializable()]
    public class ComparisonMatrix
    {
        /// <summary>
        /// Закрытое поле - содержимое матрицы.
        /// </summary>
        private int[,] matrixContents;
        /// <summary>
        /// Закрытое поле - размер матрицы. 
        /// </summary>
        /// <remarks>
        /// Матрица попарных сравнений всегда квадратная, поэтому ее
        /// размер задается одним числом.
        /// </remarks>
        private int matrixSize;

        /// <summary>
        /// Индексатор для доступа к содержимому матрицы.
        /// </summary>
        /// <param name="i">Номер строки.</param>
        /// <param name="j">Номер столбца.</param>
        /// <returns>Элемент матрицы, находящийся на пересечении
        /// выбранной строки и выборанног столбца.</returns>
        public int this[int i, int j]
        {
            get { return matrixContents[i, j]; }
            set { matrixContents[i, j] = value; }
        }

        /// <summary>
        /// Размер матрицы (свойство только для чтения).
        /// </summary>
        /// <remarks>
        /// Матрица попарных сравнений всегда квадратная, поэтому ее
        /// размер задается одним числом.
        /// </remarks>
        public int Size
        {
            get { return matrixSize; }
        }

        /// <summary>
        /// Конструктор класса.
        /// </summary>
        /// <param name="size">Размер создаваемой матрицы.</param>
        /// <remarks>
        /// Все элементы созданной матрицы, кроме диагональных, 
        /// инициалируются значением Appraisals.undefinded. Диагональные
        /// элементы матрицы инициализируются значением
        /// Appraisals.equivalent.
        /// </remarks>
        public ComparisonMatrix(int size)
        {
            matrixSize = size;
            matrixContents = new int[matrixSize, matrixSize];

            for (int i = 0; i < Size; i++)
                for (int j = 0; j < Size; j++)
                    this[i, j] = 
                        (i == j) ? Appraisals.equivalent : Appraisals.undefined;
        }

        /// <summary>
        /// Конструктор класса, восстанавливает матрицу попарных
        /// сравнений из строки.
        /// </summary>
        /// <param name="str">Строка, из которой восстанавливается матрица
        /// попарных сравнений.</param>
        /// <param name="size">Размер восстанавливаемой матрицы.</param>
        public ComparisonMatrix(string str, int size)
        {
            string[] matrixValues = str.Split('#');

            matrixSize = size;
            matrixContents = new int[matrixSize, matrixSize];

            for (int i = 0; i < Size; i++)
                for (int j = 0; j < Size; j++)
                    this[i, j] = int.Parse(matrixValues[i * Size + j]);
        }

        /// <summary>
        /// Перегруженный метод записи матрицы попарных сравнений в
        /// виде строки.
        /// </summary>
        public override string ToString()
        {
            string[] temp = new string[Size * Size];

            for (int i = 0; i < Size; i++)
                for (int j = 0; j < Size; j++)
                    temp[i * Size + j] = this[i, j].ToString();

            return String.Join("#", temp);
        }

        /// <summary>
        /// Перегруженный метод записи матрицы попарных сравнений в
        /// виде строки, принимает аргумент, описывающий стиль
        /// форматирования чисел.
        /// </summary>
        /// <param name="nfi">Описывает параметры форматирования
        /// чисел.</param>
        public string ToString(NumberFormatInfo nfi)
        {
            string[] temp = new string[Size * Size];

            for (int i = 0; i < Size; i++)
                for (int j = 0; j < Size; j++)
                    temp[i * Size + j] = this[i, j].ToString(nfi);

            return String.Join("#", temp);
        }

        /// <summary>
        /// Сбрасывает значения недиагональных элементов матрицы на
        /// Appraisals.undefined. Диагональным элементам присваивается
        /// значение Appraisals.equivalent.
        /// </summary>
        public void Reset()
        {
            for (int i = 0; i < Size; i++)
                for (int j = 0; j < Size; j++)
                    this[i, j] = 
                        (i == j) ? Appraisals.equivalent : Appraisals.undefined;
        }

        /// <summary>
        /// Расширяет матрицу, добавляя строку и столбец в указанную
        /// позицию.
        /// </summary>
        /// <param name="index">Позиции, в которые будут добавлены
        /// новые строка и столбец.</param>
        public void Expand(int index)
        {
            int[,] expanded = new int[Size + 1, Size + 1];

            // копируем значения из исходной матрицы в расширенную
            for (int i = 0; i < index; i++)
                for (int j = 0; j < index; j++)
                    expanded[i, j] = this[i, j];

            for (int i = 0; i < index; i++)
                for (int j = index; j < Size; j++)
                    expanded[i, j + 1] = this[i, j];

            for (int i = index; i < Size; i++)
                for (int j = 0; j < index; j++)
                    expanded[i + 1, j] = this[i, j];

            for (int i = index; i < Size; i++)
                for (int j = index; j < Size; j++)
                    expanded[i + 1, j + 1] = this[i, j];

            /* Все добавленные ячейки (кроме диагональных) инициализируются
             * значением Appraisals.undefined. */
            for (int i = 0; i < Size + 1; i++)
                expanded[i, index] = expanded[index, i] = Appraisals.undefined;
            expanded[index, index] = Appraisals.equivalent;
            matrixSize++;
            matrixContents = expanded;
        }

        /// <summary>
        /// Сужает матрицу, удаляя из нее строку и столбец на указанной
        /// позиции.
        /// </summary>
        /// <param name="index">Позиции удаляемых строки и стоблца.</param>
        public void Reduce(int index)
        {
            int[,] reduced = new int[Size - 1, Size - 1];

            for (int i = 0; i < index; i++)
                for (int j = 0; j < index; j++)
                    reduced[i, j] = this[i, j];

            for (int i = index + 1; i < Size; i++)
                for (int j = 0; j < index; j++)
                    reduced[i - 1, j] = this[i, j];

            for (int i = 0; i < index; i++)
                for (int j = index + 1; j < Size; j++)
                    reduced[i, j - 1] = this[i, j];

            for (int i = index + 1; i < Size; i++)
                for (int j = index + 1; j < Size; j++)
                    reduced[i - 1, j - 1] = this[i, j];

            matrixSize--;
            matrixContents = reduced;
        }
    }
}
