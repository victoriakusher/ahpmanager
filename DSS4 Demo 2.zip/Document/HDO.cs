﻿using System;

namespace Document
{
    /// <summary>
    /// HDO означает 'Human Discernible Object' - объект, распознаваемый
    /// человеком. В дальнейшем следует наследовать от этого класса вместо
    /// того, чтобы создавать поля и свойства для названия и описания.
    /// </summary>
    [Serializable()]
    public abstract class HDO
    {
        /// <summary>
        /// Закрытое поле - название.
        /// </summary>
        private string name;        
        /// <summary>
        /// Закрытое поле - описание.
        /// </summary>
        private string desctiption; 

        /// <summary>
        /// Название (свойство для чтения и записи).
        /// </summary>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        /// <summary>
        /// Описание (свойство для чтения и записи).
        /// </summary>
        public string Description
        {
            get { return desctiption; }
            set { desctiption = value; }
        }
    }
}
