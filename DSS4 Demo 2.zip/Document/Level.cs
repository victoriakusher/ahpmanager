﻿using System;
using System.Collections.Generic;

namespace Document
{
    /// <summary>
    /// Представляет уровень иерархии, построенной для решения 
    /// </summary>
    [Serializable()]
    public class Level : HDO
    {
        /// <summary>
        /// Внутреннее поле - список элементов, из которых состоит уровень.
        /// </summary>
        internal List<Element> elements;

        /// <summary>
        /// Список элементов, из которых состоит уровень (свойство только
        /// для чтения).
        /// </summary>
        public List<Element> Elements
        {
            get { return elements; }
        }

        /// <summary>
        /// Внутреннее поле - номер уровня в иерархической структуре.
        /// </summary>
        /// <remarks>
        /// Высшний уровень иерархии - уровень цели - имеет номер 0. Чем
        /// больше номер уровня, тем ниже он находится. Низший уровень
        /// иерархии имеет номер n - 1, где n - количество уровней в 
        /// иерархии.
        /// </remarks>
        internal int levelNumber;

        /// <summary>
        /// Внутренее поле - ссылка на иерархию, в которой содержится
        /// уровень.
        /// </summary>
        internal Hierarchy hr;

        /// <summary>
        /// Номер уровня в иерархи (свойство только для чтения).
        /// </summary>
        public int LevelNumber
        {
            get { return levelNumber; }
        }
        
        /// <summary>
        /// Конструктор класса по умолчанию.
        /// </summary>
        public Level()
        {
        }

        /// <summary>
        /// Количество элементов в уровне (свойство только для чтения).
        /// </summary>
        public int Count
        {
            get { return elements.Count; }
        }

        /// <summary>
        /// Равняется true, если уровень является низшим уровнем в 
        /// иерархии, false - в противном случае.
        /// </summary>
        public bool IsLowest
        {
            get { return levelNumber == hr.LevelsCount - 1; }
        }

        /// <summary>
        /// Равняется true, если уровень является высшим уровнем в
        /// иерархии (уровнем цели), false - в противном случае.
        /// </summary>
        public bool IsHighest
        {
            get { return levelNumber == 0; }
        }

        /// <summary>
        /// Возвращает ссылку на уровень ниже.
        /// </summary>
        public Level LowerLevel
        {
            get 
            {
                return (IsLowest) ? null : hr.levels[levelNumber + 1];
            }
        }

        /// <summary>
        /// Возвращает ссылку на уровень выше.
        /// </summary>
        public Level HigherLevel
        {
            get
            {
                return (IsHighest) ? null : hr.levels[levelNumber - 1];
            }
        }

        /// <summary>
        /// Конструктор класса.
        /// </summary>
        /// <param name="lvName">Название уровня.</param>
        /// <param name="lvDesc">Описание уровня.</param>
        /// <param name="newHr">Ссылка на иерархию (экземпляр класса 
        /// Hierarchy), в которой содержится элемент.</param>
        public Level(string lvName, string lvDesc, Hierarchy newHr)
        {
            Name = String.Copy(lvName);
            Description = String.Copy(lvDesc);
            hr = newHr;
            elements = new List<Element>();
        }

        /// <summary>
        /// Добавляет в уровень элемент с указанным названием и описанием.
        /// Возвращает ссылку на добавленный элемент.
        /// </summary>
        /// <param name="name">Название добавляемого элемента.</param>
        /// <param name="description">Описание добавляемого элемента.</param>
        /// <returns>Ссылка на добавленный элемент.</returns>
        public Element AddElement(string name, string description)
        {
            return null;
        }

        /// <summary>
        /// Удаляет из уровня элемент с указанным индексом.
        /// </summary>
        /// <param name="index">Индекс удаляемого элемента.</param>
        public void RemoveElement(int index)
        {
            ;
        }
    }
}
