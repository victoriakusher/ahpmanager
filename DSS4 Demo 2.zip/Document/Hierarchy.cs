﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Xml;

namespace Document
{
    /// <summary>
    /// Представляет иерархию, построенную для решения задачи методом
    /// анализа иерархий.
    /// </summary>
    [Serializable()]
    public class Hierarchy : HDO
    {
        /// <summary>
        /// Внутреннее поле - список уровней, из которых состоит иерархия.
        /// </summary>
        internal List<Level> levels;

        /// <summary>
        /// Двумерный список параметров по умолчанию для шкал.
        /// </summary>
        /// <remarks>Один список хранит параметры по умолчанию для одного
        /// вида шкал.</remarks>
        public List<List<double>> defaultScaleParameters;

        /// <summary>
        /// Список уровней, из которых состоит иерархия (свойство только
        /// для чтения).
        /// </summary>
        public List<Level> Levels
        {
            get { return levels; }
        }

        /// <summary>
        /// Количество уровней в иерархии.
        /// </summary>
        public int LevelsCount
        {
            get { return levels.Count; }
        }

        /// <summary>
        /// Количество элементов в иерархии.
        /// </summary>
        public int ElementsCount
        {
            get
            {
                int i = 0;
                foreach (Level lv in levels)
                    foreach (Element el in lv.elements) i++;
                return i;
            }
        }

        /// <summary>
        /// Конструктор класса.
        /// </summary>
        /// <param name="hrName">Название иерархии.</param>
        /// <param name="hrDesc">Описание иерархии.</param>
        /// <param name="newLevels">Начальное количество уровней в
        /// иерархии.</param>
        /// <param name="newElements">Начальное количество элементов
        /// в уровнях иерархии.</param>
        public Hierarchy(string hrName, string hrDesc, int newLevels, int newElements)
        {
            Name = hrName;
            Description = hrDesc;
            levels = new List<Level>();

            // инициализируем двойной список параметров по умолчанию
            defaultScaleParameters = new List<List<double>>(3);
            defaultScaleParameters.Add(new List<double>());
            defaultScaleParameters.Add(new List<double>());
            defaultScaleParameters.Add(new List<double>());
            defaultScaleParameters[0].Add(1); defaultScaleParameters[0].Add(0.1);
            defaultScaleParameters[1].Add(2);
            defaultScaleParameters[2].Add(2);

            // создаем уровни для иерархической структуры
            Level goalLevel = new Level("Уровень 1", "", this);
            levels.Add(goalLevel);
            for (int i = 1; i < newLevels; i++)
            {
                Level newLv = new Level("Уровень " + (i + 1), "", this);
                newLv.levelNumber = i;
                levels.Add(newLv);
            }

            // создаем элемент иерархии, представляющий цель
            Element goalElement = new Element("Цель", "Описание цели", this, goalLevel);
            goalLevel.elements.Add(goalElement);
            // создаем элементы на прочих уровнях иерархии
            for (int i = 1; i < LevelsCount; i++)
                for (int j = 0; j < newElements; j++)
                    levels[i].AddElement("Элемент " + (i + 1) + "-" + (j + 1), "");
        }

        /// <summary>
        /// Конструктор по умолчанию.
        /// </summary>
        public Hierarchy()
        {
        }

        /// <summary>
        /// Создает и добавляет в иерархию новый уровень.
        /// </summary>
        /// <param name="lvName">Название уровня.</param>
        /// <param name="lvDesc">Описание уровня.</param>
        /// <param name="index">Номер места, на которое будет поставлен
        /// уровень иерархии.</param>
        /// <param name="elementsNumber">Начальное количество элементов.
        /// </param>
        /// <returns>Ссылка на созданный и добавленный уровень иерархии.
        /// </returns>
        public Level InsertLevel(string lvName, string lvDesc, int index, 
            int elementsNumber)
        {
            return null;
        }

        /// <summary>
        /// Удаляет из иерархии уровень с указанным номером.
        /// </summary>
        /// <param name="index">Номер удаляемого уровня.</param>
        public void RemoveLevel(int index)
        {
            ;
        }

        /// <summary>
        /// Записывает иерархию в XML-формате в файл.
        /// </summary>
        /// <param name="filename">Название файла, в который записывается
        /// иерархия.</param>
        public void WriteToXML(string filename)
        {
            ;
        }

        /// <summary>
        /// Считывает иерархию в XML-формате из файла.
        /// </summary>
        /// <param name="filename">Название файла, из которого
        /// считывается иерархия.</param>
        public static Hierarchy ReadFromXML(string filename)
        {
            return null;
        }

        /// <summary>
        /// Удаляет из иерархии указанный элемент.
        /// </summary>
        /// <param name="element">Ссылка на удаляемый элемент.</param>
        public void RemoveElement(Element element)
        {
            ;
        }

        /// <summary>
        /// Создает элемент в уровене иерархии, в котором содержится
        /// указанный элемент.
        /// </summary>
        /// <param name="element">Элемент, в уровень которого добавляется
        /// новый элемент.</param>
        /// <returns>Ссылка на добавленный элемент.</returns>
        public Element AddNewElementInLevel(Element element)
        {
            return null;
        }
    }
}
