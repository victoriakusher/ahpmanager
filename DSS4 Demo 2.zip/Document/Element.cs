﻿using System;
using System.Collections.Generic;

namespace Document
{
    /// <summary>
    /// Описывает типы элементов иерархии.
    /// </summary>
    public enum Criterions
    {
        noncriterion,
        quantitative,
        comparative
    }

    /// <summary>
    /// Описывает типы шкал для сравнительных критериев.
    /// </summary>
    public enum Scales
    {
        Bruck,
        Saaty,
        logistic
    }

    /// <summary>
    /// Описывает типы количественных критериев
    /// </summary>
    public enum QuantCriterions
    {
        ascending,  // большие численные значения более предпочтительны
        descending  // меньшие численные значения менее предпочтительны
    }

    /// <summary>
    /// Представляет элемент иерархии, построенной для решения задачи.
    /// </summary>
    [Serializable()]
    public class Element : HDO
    {
        /// <summary>
        /// Внутреннее поле - тип элемента иерархии.
        /// </summary>
        internal Criterions criterionType;          
        /// <summary>
        /// Внутреннее поле - тип используемой шкалы для элемента как для
        /// сравнительного критерия.
        /// </summary>
        internal Scales scaleType; 
        /// <summary>
        /// Внутреннее поле - тип элемента как количественного критерия.
        /// </summary>
        internal QuantCriterions quantCriterionType;

        /// <summary>
        /// Внутреннее поле - ссылка на уровень иерархии (экземпляр класса
        /// Level), в котором содержится элемент.
        /// </summary>
        internal Level lv;
        /// <summary>
        /// Внутреннее поле - ссылка на иерархию (экземпляр класса 
        /// Hierarchy), в которой содержится элемент.
        /// </summary>
        internal Hierarchy hr;

        /// <summary>
        /// Внутреннее поле - матрица попарных сравнений элементов уровнем
        /// ниже.
        /// </summary>
        internal ComparisonMatrix pairComparisons;
        /// <summary>
        /// Внутреннее поле - массив численных значений (весов) элементов
        /// уровнем ниже.
        /// </summary>
        internal double[] elementValues;             
        /// <summary>
        /// Внутреннее поле - массив флагов, определяющих, было ли выставлено
        /// то или иное численное значение (вес) для элемента уровнем ниже.
        /// </summary>
        internal bool[] isDefined;                   

        /* Далее идут свойства, обеспечивающие доступ только для чтения к
         * внутренним полям класса. */

        /// <summary>
        /// Ссылка на уровень иерархии (экземпляр класса Level), в котором
        /// содержится элемент (свойство только для чтения).
        /// </summary>
        public Level Lv
        {
            get { return lv; }
        }

        /// <summary>
        /// Ссылка на иерархию (экземпляр класса Hierarchy), в которой
        /// содержится элемент (свойство только для чтения).
        /// </summary>
        public Hierarchy Hr
        {
            get { return hr; }
        }

        /// <summary>
        /// Матрица попарных сравнений элементов уровнем ниже (свойство для
        /// чтения).
        /// </summary>
        public ComparisonMatrix PairComparisons
        {
            get { return pairComparisons; }
        }

        /// <summary>
        /// Массив численных значений (весов) элементов уровнем ниже 
        /// (свойство только для чтения).
        /// </summary>
        public double[] ElementValues
        {
            get { return elementValues; }
        }

        /// <summary>
        /// Массив флагов, определяющих, было ли выставлено то или иное
        /// численное значение (вес) для элемента уровнем ниже.
        /// </summary>
        public bool[] IsDefined
        {
            get { return isDefined; }
        }

        /// <summary>
        /// Закрытое поле - флаг, использовать ли для шкалы параметры по
        /// умолчанию.
        /// </summary>
        private bool useDefaultScaleParameters;           
        /// <summary>
        /// Закрытое поле - массив специальных параметров для шкалы.
        /// </summary>
        private List<double> customScaleParameters;
        /// <summary>
        /// Закрытое поле - флаг, использовать ли для шкалы классические
        /// параметры.
        /// </summary>
        private bool useClassicScaleParameters;

        /// <summary>
        /// Конструктор класса.
        /// </summary>
        /// <param name="newName">Название элемента.</param>
        /// <param name="newDesc">Описание элемента.</param>
        /// <param name="newHr">Ссылка на иерархию, в которой содержится
        /// элемент.</param>
        /// <param name="newLv">Ссылка на уровень иерархии (экземпляр 
        /// класса Level), в котором содержится элемент.</param>
        public Element(string newName, string newDesc, Hierarchy newHr, 
            Level newLv)
        {
            Name = String.Copy(newName);
            Description = String.Copy(newDesc);
            hr = newHr;
            lv = newLv;

            if (lv.IsLowest)
                /* Если уровень, который содержит данный элемент, является
                 * низшим, то элемент не критерий. */
                criterionType = Criterions.noncriterion;
            else
            {
                /* По умолчанию считается, что критерий является 
                 * сравнительным и в нем используется шкала Саати с 
                 * параметрами по умолчанию. Тем не менее, поля для 
                 * хранения информации об элементе как количественном
                 * критерии (elementValues и isDefined) тоже 
                 * инициализуются. */
                criterionType = Criterions.comparative;
                scaleType = Scales.logistic;
                pairComparisons = new ComparisonMatrix(LowerLevelCount());
                elementValues = new double[LowerLevelCount()];
                isDefined = new Boolean[LowerLevelCount()];
            }

            UseDefaultScaleParameters = true;
        }

        /// <summary>
        /// Конструктор класса по умолчанию.
        /// </summary>
        public Element()
        {
            useDefaultScaleParameters = true;
        }

        /// <summary>
        /// Флаг: использовать ли для шкалы параметры по умолчанию.
        /// </summary>
        /// <remarks>При установке значения флага равным true, в поле
        /// специальных параметров шкалы CustomScaleParameters
        /// записываются значения параметров по умолчанию.
        /// </remarks>
        public bool UseDefaultScaleParameters
        {
            get { return useDefaultScaleParameters; }
            set
            {
                /* Если устанавливаем значение флага на true, то в поле
                 * customScaleParameters записываются значения параметров
                 * по умолчанию. */
                if (value)
                {
                    switch (scaleType)
                    {
                        case Scales.Bruck:
                            customScaleParameters = 
                                new List<double>(hr.defaultScaleParameters[0]);
                            break;
                        case Scales.logistic:
                            customScaleParameters = 
                                new List<double>(hr.defaultScaleParameters[1]);
                            break;
                        case Scales.Saaty:
                            customScaleParameters = 
                                new List<double>(hr.defaultScaleParameters[2]);
                            break;
                    }
                    UseClassicScaleParameters = false;
                }
                useDefaultScaleParameters = value;
            }
        }

        /// <summary>
        /// Флаг: использовать ли для шкалы классические значения параметров.
        /// </summary>
        /// <remarks>
        /// Для шкалы Брука классическими значениями параметров являются
        /// параметр центра, равный 1, параметр масштаба, равный 0.1. Для
        /// логистической шкалы классическое значение параметра резкости равно
        /// 2, для шкалы Саати классическое значение параметра масштаба равно
        /// 2.
        /// </remarks>
        public bool UseClassicScaleParameters
        {
            get { return useClassicScaleParameters; }
            set 
            {
                if (value)
                    UseDefaultScaleParameters = false;
                useClassicScaleParameters = value; 
            }
        }

        /// <summary>
        /// Массив специальных параметров для шкалы.
        /// </summary>
        public List<double> CustomScaleParameters
        {
            get { return customScaleParameters; }
            set { customScaleParameters = value; }
        }

        /// <summary>
        /// Возвращает количество элементов уровнем ниже, чем уровень, на
        /// котором лежит элемент.
        /// </summary>
        /// <remarks>
        /// Если элемент лежит на низшем уровне иерархии, то функция
        /// возвращает 0.
        /// </remarks>
        public int LowerLevelCount()
        {
            return (!lv.IsLowest) ? hr.levels[lv.levelNumber + 1].Count : 0;
        }

        /// <summary>
        /// Добавляет ячейки для хранения информации об элементе, который был
        /// добавлен на уровень ниже.
        /// </summary>
        public void ExpandAppraisalsStore()
        {
            ;
        }

        /// <summary>
        /// Удаляет ячейки для хранения информации об элементе, который был
        /// удален с уровня ниже.
        /// </summary>
        /// <param name="index">Индекс удаляемого элемента, лежащего уровнем
        /// ниже.</param>
        public void ReduceAppraisalsStore(int index)
        {
            ;
        }

        /// <summary>
        /// Тип элемента иерархии.
        /// </summary>
        public Criterions CriterionType
        {
            get { return criterionType; }
            set { criterionType = value; }
        }

        /// <summary>
        /// Тип используемой шкалы для элемента как для сравнительного
        /// критерия.
        /// </summary>
        public Scales ScaleType
        {
            get { return scaleType; }
            set { scaleType = value; }
        }

        /// <summary>
        /// Тип элемента как сравнительного критерия.
        /// </summary>
        public QuantCriterions QuantCriterionType
        {
            get { return quantCriterionType; }
            set { quantCriterionType = value; }
        }

        /// <summary>
        /// Сбрасывает оценки, выставленные относительно элемента как 
        /// критерия.
        /// </summary>
        public void ResetAppraisals()
        {
            switch (criterionType)
            {
                case Criterions.noncriterion:
                    break;
                case Criterions.quantitative:
                    for (int i = 0; i < isDefined.Length; i++) 
                        isDefined[i] = false;
                    break;
                case Criterions.comparative:
                    pairComparisons.Reset();
                    break;
            }
        }

        /// <summary>
        /// Проверяет, выставлены ли все оценки относительно элемента как
        /// критерия.
        /// </summary>
        /// <remarks>
        /// Если элемент не является критерием, то возвращается значение
        /// false.
        /// </remarks>
        public bool ComparisonsComplete
        {
            get 
            {
                switch (criterionType)
                {
                    case Criterions.noncriterion:
                        return false;
                    case Criterions.quantitative:
                        for (int i = 0; i < isDefined.Length; i++)
                            if (!isDefined[i]) return false;
                        return true;
                    case Criterions.comparative:
                        for (int i = 0; i < pairComparisons.Size; i++)
                            for (int j = 0; j < pairComparisons.Size; j++)
                                if (pairComparisons[i, j] ==
                                    Appraisals.undefined && i != j) 
                                    return false;
                        return true;
                }
                return true;
            }
        }

        /// <summary>
        /// Проверяет, были ли выставлены хоть какие-нибудь оценки
        /// относительно элемента как критерия.
        /// </summary>
        /// <remarks>
        /// Если элемент не является критерием, то возвращается значение
        /// false.
        /// </remarks>
        public bool AnyComparisons
        {
            get
            {
                switch (criterionType)
                {
                    case Criterions.noncriterion:
                        return false;
                    case Criterions.quantitative:
                        for (int i = 0; i < isDefined.Length; i++)
                            if (isDefined[i]) return true;
                        return false;
                    case Criterions.comparative:
                        for (int i = 0; i < pairComparisons.Size; i++)
                            for (int j = 0; j < pairComparisons.Size; j++)
                                if (pairComparisons[i, j] != 
                                    Appraisals.undefined && i != j) 
                                    return true;
                        return false;
                }
                return false;
            }
        }

        /// <summary>
        /// Свойство для привязки экземпляра класса к компоненту управления.
        /// </summary>
        public string Tag
        {
            get { return lv.levelNumber + " " + lv.elements.IndexOf(this); }
        }
    }
}
